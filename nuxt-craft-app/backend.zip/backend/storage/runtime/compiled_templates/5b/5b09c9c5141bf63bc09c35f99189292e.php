<?php

use Twig\Environment;
use Twig\Error\LoaderError;
use Twig\Error\RuntimeError;
use Twig\Extension\CoreExtension;
use Twig\Extension\SandboxExtension;
use Twig\Markup;
use Twig\Sandbox\SecurityError;
use Twig\Sandbox\SecurityNotAllowedTagError;
use Twig\Sandbox\SecurityNotAllowedFilterError;
use Twig\Sandbox\SecurityNotAllowedFunctionError;
use Twig\Source;
use Twig\Template;
use Twig\TemplateWrapper;

/* _special/login.twig */
class __TwigTemplate_3e0c0fc4c4a0644621e26f8a009789c5 extends Template
{
    private Source $source;
    /**
     * @var array<string, Template>
     */
    private array $macros = [];

    public function __construct(Environment $env)
    {
        parent::__construct($env);

        $this->source = $this->getSourceContext();

        $this->parent = false;

        $this->blocks = [
        ];
    }

    protected function doDisplay(array $context, array $blocks = []): iterable
    {
        $macros = $this->macros;
        craft\helpers\Template::beginProfile("template", "_special/login.twig");
        // line 1
        $macros["forms"] = $this->macros["forms"] = $this->loadTemplate("_includes/forms.twig", "_special/login.twig", 1)->unwrap();
        // line 2
        yield "
";
        // line 3
        $context["showResetPassword"] = (($context["showResetPassword"]) ?? (false));
        // line 4
        $context["showRememberMeCheckbox"] = (($context["showRememberMeCheckbox"]) ?? (false));
        // line 5
        $context["staticEmail"] = (($context["staticEmail"]) ?? (null));
        // line 6
        yield "
";
        // line 7
        $context["generalConfig"] = craft\helpers\Template::attribute($this->env, $this->source, craft\helpers\Template::attribute($this->env, $this->source, craft\helpers\Template::attribute($this->env, $this->source, (isset($context["craft"]) || array_key_exists("craft", $context) ? $context["craft"] : (function () { throw new RuntimeError('Variable "craft" does not exist.', 7, $this->source); })()), "app", [], "any", false, false, false, 7), "config", [], "any", false, false, false, 7), "general", [], "any", false, false, false, 7);
        // line 8
        $context["username"] = (($context["staticEmail"]) ?? (((craft\helpers\Template::attribute($this->env, $this->source, (isset($context["generalConfig"]) || array_key_exists("generalConfig", $context) ? $context["generalConfig"] : (function () { throw new RuntimeError('Variable "generalConfig" does not exist.', 8, $this->source); })()), "rememberUsernameDuration", [], "any", false, false, false, 8)) ? (craft\helpers\Template::attribute($this->env, $this->source, craft\helpers\Template::attribute($this->env, $this->source, craft\helpers\Template::attribute($this->env, $this->source, (isset($context["craft"]) || array_key_exists("craft", $context) ? $context["craft"] : (function () { throw new RuntimeError('Variable "craft" does not exist.', 8, $this->source); })()), "app", [], "any", false, false, false, 8), "user", [], "any", false, false, false, 8), "getRememberedUsername", [], "method", false, false, false, 8)) : (""))));
        // line 9
        yield "
";
        // line 10
        if (craft\helpers\Template::attribute($this->env, $this->source, (isset($context["generalConfig"]) || array_key_exists("generalConfig", $context) ? $context["generalConfig"] : (function () { throw new RuntimeError('Variable "generalConfig" does not exist.', 10, $this->source); })()), "useEmailAsUsername", [], "any", false, false, false, 10)) {
            // line 11
            yield "  ";
            $context["usernameLabel"] = $this->extensions['craft\web\twig\Extension']->translateFilter("Email", "app");
            // line 12
            yield "  ";
            $context["usernameType"] = "email";
        } else {
            // line 14
            yield "  ";
            $context["usernameLabel"] = $this->extensions['craft\web\twig\Extension']->translateFilter("Username or Email", "app");
            // line 15
            yield "  ";
            $context["usernameType"] = "text";
        }
        // line 17
        yield "
<div class=\"login-container\">
  <div class=\"pane secondary login-form-container\">
    ";
        // line 20
        ob_start();
        // line 28
        yield "      ";
        if ((isset($context["staticEmail"]) || array_key_exists("staticEmail", $context) ? $context["staticEmail"] : (function () { throw new RuntimeError('Variable "staticEmail" does not exist.', 28, $this->source); })())) {
            // line 29
            yield "        ";
            yield craft\helpers\Html::hiddenInput("username", (isset($context["staticEmail"]) || array_key_exists("staticEmail", $context) ? $context["staticEmail"] : (function () { throw new RuntimeError('Variable "staticEmail" does not exist.', 29, $this->source); })()), ["class" => "login-username"]);
            // line 31
            yield "
      ";
        } else {
            // line 33
            yield "        ";
            yield $macros["forms"]->getTemplateForMacro("macro_textField", $context, 33, $this->getSourceContext())->macro_textField(...[["label" =>             // line 34
(isset($context["usernameLabel"]) || array_key_exists("usernameLabel", $context) ? $context["usernameLabel"] : (function () { throw new RuntimeError('Variable "usernameLabel" does not exist.', 34, $this->source); })()), "class" => "login-username", "name" => "username", "value" =>             // line 37
(isset($context["username"]) || array_key_exists("username", $context) ? $context["username"] : (function () { throw new RuntimeError('Variable "username" does not exist.', 37, $this->source); })()), "autocomplete" => "username", "autocapitalize" => false, "type" =>             // line 40
(isset($context["usernameType"]) || array_key_exists("usernameType", $context) ? $context["usernameType"] : (function () { throw new RuntimeError('Variable "usernameType" does not exist.', 40, $this->source); })()), "inputAttributes" => ["aria" => ["required" => "true"]]]]);
            // line 46
            yield "
      ";
        }
        // line 48
        yield "
      <div>
        ";
        // line 50
        yield $macros["forms"]->getTemplateForMacro("macro_passwordField", $context, 50, $this->getSourceContext())->macro_passwordField(...[["label" => $this->extensions['craft\web\twig\Extension']->translateFilter("Password", "app"), "class" => "login-password", "name" => "password", "autocomplete" => "current-password", "inputAttributes" => ["aria" => ["required" => "true"]]]]);
        // line 60
        yield "
        ";
        // line 61
        if ((isset($context["showResetPassword"]) || array_key_exists("showResetPassword", $context) ? $context["showResetPassword"] : (function () { throw new RuntimeError('Variable "showResetPassword" does not exist.', 61, $this->source); })())) {
            // line 62
            yield "          <button type=\"button\" class=\"btn login-forgot-password chromeless\">";
            yield $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($this->extensions['craft\web\twig\Extension']->translateFilter("Forgot password?", "app"), "html", null, true);
            yield "</button>
        ";
        }
        // line 64
        yield "      </div>

      ";
        // line 66
        if (((isset($context["showRememberMeCheckbox"]) || array_key_exists("showRememberMeCheckbox", $context) ? $context["showRememberMeCheckbox"] : (function () { throw new RuntimeError('Variable "showRememberMeCheckbox" does not exist.', 66, $this->source); })()) && craft\helpers\Template::attribute($this->env, $this->source, (isset($context["generalConfig"]) || array_key_exists("generalConfig", $context) ? $context["generalConfig"] : (function () { throw new RuntimeError('Variable "generalConfig" does not exist.', 66, $this->source); })()), "rememberedUserSessionDuration", [], "any", false, false, false, 66))) {
            // line 67
            yield "        ";
            yield $macros["forms"]->getTemplateForMacro("macro_checkboxField", $context, 67, $this->getSourceContext())->macro_checkboxField(...[["label" => $this->extensions['craft\web\twig\Extension']->translateFilter("Stay signed in for {duration}", "app", ["duration" => craft\helpers\DateTimeHelper::humanDuration(craft\helpers\Template::attribute($this->env, $this->source,             // line 69
(isset($context["generalConfig"]) || array_key_exists("generalConfig", $context) ? $context["generalConfig"] : (function () { throw new RuntimeError('Variable "generalConfig" does not exist.', 69, $this->source); })()), "getRememberedUserSessionDuration", [], "method", false, false, false, 69))]), "class" => "login-remember-me"]]);
            // line 72
            yield "
      ";
        }
        // line 74
        yield "
      ";
        // line 75
        yield $macros["forms"]->getTemplateForMacro("macro_submitButton", $context, 75, $this->getSourceContext())->macro_submitButton(...[["class" => ["fullwidth", "last"], "label" => $this->extensions['craft\web\twig\Extension']->translateFilter("Sign in", "app"), "spinner" => true, "busyMessage" => $this->extensions['craft\web\twig\Extension']->translateFilter("Signing in", "app"), "successMessage" => $this->extensions['craft\web\twig\Extension']->translateFilter("Signed in", "app"), "failureMessage" => $this->extensions['craft\web\twig\Extension']->translateFilter("Sign in unsuccessful", "app"), "retryMessage" => $this->extensions['craft\web\twig\Extension']->translateFilter("Try again", "app")]]);
        // line 83
        yield "
    ";
        echo craft\helpers\Html::tag("form", ob_get_clean(), ["class" => Twig\Extension\CoreExtension::keys($this->extensions['craft\web\twig\Extension']->filterFilter($this->env, ["login-form" => true, "hidden" =>         // line 23
array_key_exists("authFormData", $context)])), "method" => "post", "accept-charset" => "UTF-8"]);
        // line 85
        yield "
    <div class=\"login-errors hidden\"></div>

    ";
        // line 88
        if ((isset($context["showResetPassword"]) || array_key_exists("showResetPassword", $context) ? $context["showResetPassword"] : (function () { throw new RuntimeError('Variable "showResetPassword" does not exist.', 88, $this->source); })())) {
            // line 89
            yield "      <form class=\"login-reset-password hidden\">
        ";
            // line 90
            yield $macros["forms"]->getTemplateForMacro("macro_textField", $context, 90, $this->getSourceContext())->macro_textField(...[["label" =>             // line 91
(isset($context["usernameLabel"]) || array_key_exists("usernameLabel", $context) ? $context["usernameLabel"] : (function () { throw new RuntimeError('Variable "usernameLabel" does not exist.', 91, $this->source); })()), "class" => "login-username", "name" => "username", "autocomplete" => "username", "autocapitalize" => false, "type" =>             // line 96
(isset($context["usernameType"]) || array_key_exists("usernameType", $context) ? $context["usernameType"] : (function () { throw new RuntimeError('Variable "usernameType" does not exist.', 96, $this->source); })()), "inputAttributes" => ["aria" => ["required" => "true"]]]]);
            // line 102
            yield "

        ";
            // line 104
            yield $macros["forms"]->getTemplateForMacro("macro_submitButton", $context, 104, $this->getSourceContext())->macro_submitButton(...[["class" => ["fullwidth", "last"], "label" => $this->extensions['craft\web\twig\Extension']->translateFilter("Reset password", "app"), "spinner" => true]]);
            // line 108
            yield "

        <div class=\"login-errors hidden\"></div>

        <hr>

        <div class=\"login-alt-container\">
          ";
            // line 115
            yield $macros["forms"]->getTemplateForMacro("macro_button", $context, 115, $this->getSourceContext())->macro_button(...[["label" => ((((craft\helpers\Template::attribute($this->env, $this->source, craft\helpers\Template::attribute($this->env, $this->source, craft\helpers\Template::attribute($this->env, $this->source,             // line 116
(isset($context["craft"]) || array_key_exists("craft", $context) ? $context["craft"] : (function () { throw new RuntimeError('Variable "craft" does not exist.', 116, $this->source); })()), "app", [], "any", false, false, false, 116), "locale", [], "any", false, false, false, 116), "getOrientation", [], "method", false, false, false, 116) == "ltr")) ? ("← ") : (" →")) . $this->extensions['craft\web\twig\Extension']->translateFilter("Back to sign in", "app")), "class" => ["login-reset-back-btn", "chromeless"], "spinner" => true]]);
            // line 120
            yield "
        </div>
      </form>
    ";
        }
        // line 124
        yield "  </div>

  <div class=\"flex alternative-login-methods hidden\">
    ";
        // line 127
        yield $macros["forms"]->getTemplateForMacro("macro_button", $context, 127, $this->getSourceContext())->macro_button(...[["id" => "webauthn-login", "class" => ["login-passkey-btn", "hidden"], "label" => $this->extensions['craft\web\twig\Extension']->translateFilter("Sign in with a passkey", "app"), "spinner" => true, "busyMessage" => $this->extensions['craft\web\twig\Extension']->translateFilter("Signing in", "app"), "successMessage" => $this->extensions['craft\web\twig\Extension']->translateFilter("Signed in", "app"), "failureMessage" => $this->extensions['craft\web\twig\Extension']->translateFilter("Sign in unsuccessful", "app"), "retryMessage" => $this->extensions['craft\web\twig\Extension']->translateFilter("Sign in with a passkey", "app")]]);
        // line 136
        yield "

    ";
        // line 138
        if (((isset($context["CraftEdition"]) || array_key_exists("CraftEdition", $context) ? $context["CraftEdition"] : (function () { throw new RuntimeError('Variable "CraftEdition" does not exist.', 138, $this->source); })()) == (isset($context["CraftEnterprise"]) || array_key_exists("CraftEnterprise", $context) ? $context["CraftEnterprise"] : (function () { throw new RuntimeError('Variable "CraftEnterprise" does not exist.', 138, $this->source); })()))) {
            // line 139
            yield "      ";
            $context['_parent'] = $context;
            $context['_seq'] = CoreExtension::ensureTraversable(craft\helpers\Template::attribute($this->env, $this->source, craft\helpers\Template::attribute($this->env, $this->source, craft\helpers\Template::attribute($this->env, $this->source, (isset($context["craft"]) || array_key_exists("craft", $context) ? $context["craft"] : (function () { throw new RuntimeError('Variable "craft" does not exist.', 139, $this->source); })()), "app", [], "any", false, false, false, 139), "sso", [], "any", false, false, false, 139), "providers", [], "any", false, false, false, 139));
            foreach ($context['_seq'] as $context["_key"] => $context["provider"]) {
                // line 140
                yield "        ";
                yield craft\helpers\Template::attribute($this->env, $this->source, $context["provider"], "getCpLoginHtml", [], "method", false, false, false, 140);
                yield "
      ";
            }
            $_parent = $context['_parent'];
            unset($context['_seq'], $context['_key'], $context['provider'], $context['_parent']);
            $context = array_intersect_key($context, $_parent) + $_parent;
            // line 142
            yield "    ";
        }
        // line 143
        yield "
    ";
        // line 144
        echo \Craft::$app->getView()->invokeHook("cp.login.alternative-login-methods", $context);

        // line 145
        yield "  </div>
</div>
";
        craft\helpers\Template::endProfile("template", "_special/login.twig");
        yield from [];
    }

    /**
     * @codeCoverageIgnore
     */
    public function getTemplateName(): string
    {
        return "_special/login.twig";
    }

    /**
     * @codeCoverageIgnore
     */
    public function isTraitable(): bool
    {
        return false;
    }

    /**
     * @codeCoverageIgnore
     */
    public function getDebugInfo(): array
    {
        return array (  222 => 145,  219 => 144,  216 => 143,  213 => 142,  204 => 140,  199 => 139,  197 => 138,  193 => 136,  191 => 127,  186 => 124,  180 => 120,  178 => 116,  177 => 115,  168 => 108,  166 => 104,  162 => 102,  160 => 96,  159 => 91,  158 => 90,  155 => 89,  153 => 88,  148 => 85,  146 => 23,  143 => 83,  141 => 75,  138 => 74,  134 => 72,  132 => 69,  130 => 67,  128 => 66,  124 => 64,  118 => 62,  116 => 61,  113 => 60,  111 => 50,  107 => 48,  103 => 46,  101 => 40,  100 => 37,  99 => 34,  97 => 33,  93 => 31,  90 => 29,  87 => 28,  85 => 20,  80 => 17,  76 => 15,  73 => 14,  69 => 12,  66 => 11,  64 => 10,  61 => 9,  59 => 8,  57 => 7,  54 => 6,  52 => 5,  50 => 4,  48 => 3,  45 => 2,  43 => 1,);
    }

    public function getSourceContext(): Source
    {
        return new Source("{% import '_includes/forms.twig' as forms %}

{% set showResetPassword = showResetPassword ?? false %}
{% set showRememberMeCheckbox = showRememberMeCheckbox ?? false %}
{% set staticEmail = staticEmail ?? null %}

{% set generalConfig = craft.app.config.general %}
{% set username = staticEmail ?? (generalConfig.rememberUsernameDuration ? craft.app.user.getRememberedUsername(): '') %}

{% if generalConfig.useEmailAsUsername %}
  {% set usernameLabel = 'Email'|t('app') %}
  {% set usernameType = 'email' %}
{% else %}
  {% set usernameLabel = 'Username or Email'|t('app') %}
  {% set usernameType = 'text' %}
{% endif %}

<div class=\"login-container\">
  <div class=\"pane secondary login-form-container\">
    {% tag 'form' with {
      class: {
        'login-form': true,
        'hidden': authFormData is defined,
      }|filter|keys,
      method: 'post',
      'accept-charset': 'UTF-8',
    } %}
      {% if staticEmail %}
        {{ hiddenInput('username', staticEmail, {
          class: 'login-username',
        }) }}
      {% else %}
        {{ forms.textField({
          label: usernameLabel,
          class: 'login-username',
          name: 'username',
          value: username,
          autocomplete: 'username',
          autocapitalize: false,
          type: usernameType,
          inputAttributes: {
            aria: {
              required: 'true',
            },
          },
        }) }}
      {% endif %}

      <div>
        {{ forms.passwordField({
          label: 'Password'|t('app'),
          class: 'login-password',
          name: 'password',
          autocomplete: 'current-password',
          inputAttributes: {
            aria: {
              required: 'true',
            },
          },
        }) }}
        {% if showResetPassword %}
          <button type=\"button\" class=\"btn login-forgot-password chromeless\">{{ 'Forgot password?'|t('app') }}</button>
        {% endif %}
      </div>

      {% if showRememberMeCheckbox and generalConfig.rememberedUserSessionDuration %}
        {{ forms.checkboxField({
          label: 'Stay signed in for {duration}'|t('app', {
            duration: generalConfig.getRememberedUserSessionDuration()|duration,
          }),
          class: 'login-remember-me',
        }) }}
      {% endif %}

      {{ forms.submitButton({
        class: ['fullwidth', 'last'],
        label: 'Sign in'|t('app'),
        spinner: true,
        busyMessage: 'Signing in'|t('app'),
        successMessage: 'Signed in'|t('app'),
        failureMessage: 'Sign in unsuccessful'|t('app'),
        retryMessage: 'Try again'|t('app'),
      }) }}
    {% endtag %}

    <div class=\"login-errors hidden\"></div>

    {% if showResetPassword %}
      <form class=\"login-reset-password hidden\">
        {{ forms.textField({
          label: usernameLabel,
          class: 'login-username',
          name: 'username',
          autocomplete: 'username',
          autocapitalize: false,
          type: usernameType,
          inputAttributes: {
            aria: {
              required: 'true',
            },
          },
        }) }}

        {{ forms.submitButton({
          class: ['fullwidth', 'last'],
          label: 'Reset password'|t('app'),
          spinner: true,
        }) }}

        <div class=\"login-errors hidden\"></div>

        <hr>

        <div class=\"login-alt-container\">
          {{ forms.button({
            label: (craft.app.locale.getOrientation() == 'ltr' ? '← ' : ' →') ~
              'Back to sign in'|t('app'),
            class: ['login-reset-back-btn', 'chromeless'],
            spinner: true,
          }) }}
        </div>
      </form>
    {% endif %}
  </div>

  <div class=\"flex alternative-login-methods hidden\">
    {{ forms.button({
      id: 'webauthn-login',
      class: ['login-passkey-btn', 'hidden'],
      label: 'Sign in with a passkey'|t('app'),
      spinner: true,
      busyMessage: 'Signing in'|t('app'),
      successMessage: 'Signed in'|t('app'),
      failureMessage: 'Sign in unsuccessful'|t('app'),
      retryMessage: 'Sign in with a passkey'|t('app'),
    }) }}

    {% if CraftEdition == CraftEnterprise %}
      {% for provider in craft.app.sso.providers %}
        {{ provider.getCpLoginHtml()|raw }}
      {% endfor %}
    {% endif %}

    {% hook 'cp.login.alternative-login-methods' %}
  </div>
</div>
", "_special/login.twig", "/var/www/html/backend/vendor/craftcms/cms/src/templates/_special/login.twig");
    }
}

<?php

use Twig\Environment;
use Twig\Error\LoaderError;
use Twig\Error\RuntimeError;
use Twig\Extension\CoreExtension;
use Twig\Extension\SandboxExtension;
use Twig\Markup;
use Twig\Sandbox\SecurityError;
use Twig\Sandbox\SecurityNotAllowedTagError;
use Twig\Sandbox\SecurityNotAllowedFilterError;
use Twig\Sandbox\SecurityNotAllowedFunctionError;
use Twig\Source;
use Twig\Template;
use Twig\TemplateWrapper;

/* _includes/forms/time */
class __TwigTemplate_07471ce39240ec115d9c44db6d72a252 extends Template
{
    private Source $source;
    /**
     * @var array<string, Template>
     */
    private array $macros = [];

    public function __construct(Environment $env)
    {
        parent::__construct($env);

        $this->source = $this->getSourceContext();

        $this->parent = false;

        $this->blocks = [
        ];
    }

    protected function doDisplay(array $context, array $blocks = []): iterable
    {
        $macros = $this->macros;
        craft\helpers\Template::beginProfile("template", "_includes/forms/time");
        // line 1
        $context["hasOuterContainer"] = (($context["hasOuterContainer"]) ?? (false));
        // line 2
        $context["id"] = ((($context["id"]) ?? (("time" . Twig\Extension\CoreExtension::random($this->env->getCharset())))) . "-time");
        // line 3
        $context["name"] = (($context["name"]) ?? (null));
        // line 4
        $context["value"] = (($context["value"]) ?? (null));
        // line 5
        $context["locale"] = craft\helpers\Template::attribute($this->env, $this->source, craft\helpers\Template::attribute($this->env, $this->source, (isset($context["craft"]) || array_key_exists("craft", $context) ? $context["craft"] : (function () { throw new RuntimeError('Variable "craft" does not exist.', 5, $this->source); })()), "app", [], "any", false, false, false, 5), "getFormattingLocale", [], "method", false, false, false, 5);
        // line 6
        $context["outputLocaleParam"] = (($context["outputLocaleParam"]) ?? (true));
        // line 7
        $context["timeZone"] = (($context["timeZone"]) ?? (null));
        // line 8
        $context["outputTzParam"] = (($context["outputTzParam"]) ?? (true));
        // line 9
        $context["isMobile"] = craft\helpers\Template::attribute($this->env, $this->source, craft\helpers\Template::attribute($this->env, $this->source, craft\helpers\Template::attribute($this->env, $this->source, (isset($context["craft"]) || array_key_exists("craft", $context) ? $context["craft"] : (function () { throw new RuntimeError('Variable "craft" does not exist.', 9, $this->source); })()), "app", [], "any", false, false, false, 9), "request", [], "any", false, false, false, 9), "isMobileBrowser", [], "any", false, false, false, 9);
        // line 10
        $context["isDateTime"] = (($context["isDateTime"]) ?? (false));
        // line 11
        yield "
";
        // line 12
        craft\helpers\Template::attribute($this->env, $this->source, (isset($context["view"]) || array_key_exists("view", $context) ? $context["view"] : (function () { throw new RuntimeError('Variable "view" does not exist.', 12, $this->source); })()), "registerAssetBundle", ["craft\\web\\assets\\timepicker\\TimepickerAsset"], "method", false, false, false, 12);
        // line 14
        $context["containerAttributes"] = $this->extensions['craft\web\twig\Extension']->mergeFilter(["class" => $this->extensions['craft\web\twig\Extension']->mergeFilter(["timewrapper"], craft\helpers\Html::explodeClass(((        // line 15
$context["class"]) ?? ([]))))], ((        // line 16
$context["containerAttributes"]) ?? ([])), true);
        // line 18
        if (        $this->unwrap()->hasBlock("attr", $context, $blocks)) {
            // line 19
            $context["containerAttributes"] = $this->extensions['craft\web\twig\Extension']->mergeFilter((isset($context["containerAttributes"]) || array_key_exists("containerAttributes", $context) ? $context["containerAttributes"] : (function () { throw new RuntimeError('Variable "containerAttributes" does not exist.', 19, $this->source); })()), $this->extensions['craft\web\twig\Extension']->parseAttrFilter((("<div " .             $this->unwrap()->renderBlock("attr", $context, $blocks)) . ">")), true);
        }
        // line 21
        yield "
";
        // line 22
        if ( !(isset($context["hasOuterContainer"]) || array_key_exists("hasOuterContainer", $context) ? $context["hasOuterContainer"] : (function () { throw new RuntimeError('Variable "hasOuterContainer" does not exist.', 22, $this->source); })())) {
            yield "<div class=\"datetimewrapper\">";
        }
        // line 23
        yield "
";
        // line 24
        ob_start();
        // line 25
        yield "    ";
        if ( !(isset($context["isMobile"]) || array_key_exists("isMobile", $context) ? $context["isMobile"] : (function () { throw new RuntimeError('Variable "isMobile" does not exist.', 25, $this->source); })())) {
            // line 26
            yield "        ";
            $context["formatRefId"] = ((isset($context["id"]) || array_key_exists("id", $context) ? $context["id"] : (function () { throw new RuntimeError('Variable "id" does not exist.', 26, $this->source); })()) . "-format");
            // line 27
            yield "        ";
            $context["describedBy"] = Twig\Extension\CoreExtension::join($this->extensions['craft\web\twig\Extension']->filterFilter($this->env, [(isset($context["formatRefId"]) || array_key_exists("formatRefId", $context) ? $context["formatRefId"] : (function () { throw new RuntimeError('Variable "formatRefId" does not exist.', 27, $this->source); })()), (($context["describedBy"]) ?? (null))]), " ");
            // line 28
            yield "        <span id=\"";
            yield $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape((isset($context["formatRefId"]) || array_key_exists("formatRefId", $context) ? $context["formatRefId"] : (function () { throw new RuntimeError('Variable "formatRefId" does not exist.', 28, $this->source); })()), "html", null, true);
            yield "\" class=\"visually-hidden\">
            ";
            // line 29
            yield $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape(craft\helpers\Template::attribute($this->env, $this->source, (isset($context["locale"]) || array_key_exists("locale", $context) ? $context["locale"] : (function () { throw new RuntimeError('Variable "locale" does not exist.', 29, $this->source); })()), "getTimeFormat", ["short", "human"], "method", false, false, false, 29), "html", null, true);
            yield "
        </span>
    ";
        }
        // line 32
        yield from $this->loadTemplate("_includes/forms/text", "_includes/forms/time", 32)->unwrap()->yield(CoreExtension::merge($context, ["type" => ((        // line 33
(isset($context["isMobile"]) || array_key_exists("isMobile", $context) ? $context["isMobile"] : (function () { throw new RuntimeError('Variable "isMobile" does not exist.', 33, $this->source); })())) ? ("time") : ("combobox")), "class" => (((        // line 34
(isset($context["isMobile"]) || array_key_exists("isMobile", $context) ? $context["isMobile"] : (function () { throw new RuntimeError('Variable "isMobile" does not exist.', 34, $this->source); })()) &&  !(isset($context["value"]) || array_key_exists("value", $context) ? $context["value"] : (function () { throw new RuntimeError('Variable "value" does not exist.', 34, $this->source); })()))) ? ("empty-value") : (false)), "name" => ((        // line 35
(isset($context["name"]) || array_key_exists("name", $context) ? $context["name"] : (function () { throw new RuntimeError('Variable "name" does not exist.', 35, $this->source); })())) ? (((isset($context["name"]) || array_key_exists("name", $context) ? $context["name"] : (function () { throw new RuntimeError('Variable "name" does not exist.', 35, $this->source); })()) . "[time]")) : (null)), "autocomplete" => false, "size" => 10, "placeholder" => " ", "value" => ((        // line 39
(isset($context["value"]) || array_key_exists("value", $context) ? $context["value"] : (function () { throw new RuntimeError('Variable "value" does not exist.', 39, $this->source); })())) ? ($this->extensions['craft\web\twig\Extension']->timeFilter($this->env, (isset($context["value"]) || array_key_exists("value", $context) ? $context["value"] : (function () { throw new RuntimeError('Variable "value" does not exist.', 39, $this->source); })()), (((isset($context["isMobile"]) || array_key_exists("isMobile", $context) ? $context["isMobile"] : (function () { throw new RuntimeError('Variable "isMobile" does not exist.', 39, $this->source); })())) ? ("H:i") : ("short")), (isset($context["timeZone"]) || array_key_exists("timeZone", $context) ? $context["timeZone"] : (function () { throw new RuntimeError('Variable "timeZone" does not exist.', 39, $this->source); })()))) : ("")), "inputAttributes" => ["aria" => ["label" => ((        // line 42
(isset($context["isDateTime"]) || array_key_exists("isDateTime", $context) ? $context["isDateTime"] : (function () { throw new RuntimeError('Variable "isDateTime" does not exist.', 42, $this->source); })())) ? ($this->extensions['craft\web\twig\Extension']->translateFilter("Time", "app")) : (false)), "expanded" => ((        // line 43
(isset($context["isMobile"]) || array_key_exists("isMobile", $context) ? $context["isMobile"] : (function () { throw new RuntimeError('Variable "isMobile" does not exist.', 43, $this->source); })())) ? (false) : ("false"))]]]));
        // line 47
        yield "<div data-icon=\"time\"></div>";
        // line 48
        if (((isset($context["name"]) || array_key_exists("name", $context) ? $context["name"] : (function () { throw new RuntimeError('Variable "name" does not exist.', 48, $this->source); })()) && (isset($context["outputLocaleParam"]) || array_key_exists("outputLocaleParam", $context) ? $context["outputLocaleParam"] : (function () { throw new RuntimeError('Variable "outputLocaleParam" does not exist.', 48, $this->source); })()))) {
            // line 49
            yield craft\helpers\Html::hiddenInput(((isset($context["name"]) || array_key_exists("name", $context) ? $context["name"] : (function () { throw new RuntimeError('Variable "name" does not exist.', 49, $this->source); })()) . "[locale]"), craft\helpers\Template::attribute($this->env, $this->source, (isset($context["locale"]) || array_key_exists("locale", $context) ? $context["locale"] : (function () { throw new RuntimeError('Variable "locale" does not exist.', 49, $this->source); })()), "id", [], "any", false, false, false, 49));
        }
        // line 51
        if (((isset($context["name"]) || array_key_exists("name", $context) ? $context["name"] : (function () { throw new RuntimeError('Variable "name" does not exist.', 51, $this->source); })()) && (isset($context["outputTzParam"]) || array_key_exists("outputTzParam", $context) ? $context["outputTzParam"] : (function () { throw new RuntimeError('Variable "outputTzParam" does not exist.', 51, $this->source); })()))) {
            // line 52
            yield craft\helpers\Html::hiddenInput(((isset($context["name"]) || array_key_exists("name", $context) ? $context["name"] : (function () { throw new RuntimeError('Variable "name" does not exist.', 52, $this->source); })()) . "[timezone]"), craft\helpers\Template::attribute($this->env, $this->source, craft\helpers\Template::attribute($this->env, $this->source, (isset($context["craft"]) || array_key_exists("craft", $context) ? $context["craft"] : (function () { throw new RuntimeError('Variable "craft" does not exist.', 52, $this->source); })()), "app", [], "any", false, false, false, 52), "getTimeZone", [], "method", false, false, false, 52));
        }
        echo craft\helpers\Html::tag("div", ob_get_clean(),         // line 24
(isset($context["containerAttributes"]) || array_key_exists("containerAttributes", $context) ? $context["containerAttributes"] : (function () { throw new RuntimeError('Variable "containerAttributes" does not exist.', 24, $this->source); })()));
        // line 56
        if ( !(isset($context["hasOuterContainer"]) || array_key_exists("hasOuterContainer", $context) ? $context["hasOuterContainer"] : (function () { throw new RuntimeError('Variable "hasOuterContainer" does not exist.', 56, $this->source); })())) {
            yield "</div>";
        }
        // line 58
        if ( !(isset($context["isMobile"]) || array_key_exists("isMobile", $context) ? $context["isMobile"] : (function () { throw new RuntimeError('Variable "isMobile" does not exist.', 58, $this->source); })())) {
            // line 59
            $context["options"] = $this->extensions['craft\web\twig\Extension']->filterFilter($this->env, ["minTime" => ((            // line 60
$context["minTime"]) ?? (null)), "maxTime" => ((            // line 61
$context["maxTime"]) ?? (null)), "disableTimeRanges" => ((            // line 62
$context["disableTimeRanges"]) ?? (null)), "step" => ((            // line 63
$context["minuteIncrement"]) ?? (null)), "forceRoundTime" => ((            // line 64
$context["forceRoundTime"]) ?? (false))]);
            // line 68
            $context["jsonOptions"] = (((Twig\Extension\CoreExtension::constant("JSON_HEX_TAG") | Twig\Extension\CoreExtension::constant("JSON_HEX_AMP")) | Twig\Extension\CoreExtension::constant("JSON_HEX_QUOT")) | Twig\Extension\CoreExtension::constant("JSON_FORCE_OBJECT"));
            // line 70
            ob_start();
            // line 71
            yield "var \$timePicker = \$('#";
            yield $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($this->env->getFilter('namespaceInputId')->getCallable()((isset($context["id"]) || array_key_exists("id", $context) ? $context["id"] : (function () { throw new RuntimeError('Variable "id" does not exist.', 71, $this->source); })())), "js"), "html", null, true);
            yield "');
        \$timePicker.timepicker(\$.extend(";
            // line 72
            yield $this->extensions['craft\web\twig\Extension']->jsonEncodeFilter((isset($context["options"]) || array_key_exists("options", $context) ? $context["options"] : (function () { throw new RuntimeError('Variable "options" does not exist.', 72, $this->source); })()), (isset($context["jsonOptions"]) || array_key_exists("jsonOptions", $context) ? $context["jsonOptions"] : (function () { throw new RuntimeError('Variable "jsonOptions" does not exist.', 72, $this->source); })()));
            yield ", Craft.timepickerOptions));
        Craft.ui.remediateTimepickerA11y(\$timePicker);";
            // line 75
            if (((isset($context["value"]) || array_key_exists("value", $context) ? $context["value"] : (function () { throw new RuntimeError('Variable "value" does not exist.', 75, $this->source); })()) && craft\helpers\Template::attribute($this->env, $this->source, ($context["value"] ?? null), "format", [], "any", true, true, false, 75))) {
                // line 76
                yield "\$timePicker.timepicker('setTime', ";
                yield $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape(craft\helpers\Template::attribute($this->env, $this->source, (isset($context["value"]) || array_key_exists("value", $context) ? $context["value"] : (function () { throw new RuntimeError('Variable "value" does not exist.', 76, $this->source); })()), "format", ["G"], "method", false, false, false, 76), "html", null, true);
                yield "*3600 + ";
                yield $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape(craft\helpers\Template::attribute($this->env, $this->source, (isset($context["value"]) || array_key_exists("value", $context) ? $context["value"] : (function () { throw new RuntimeError('Variable "value" does not exist.', 76, $this->source); })()), "format", ["i"], "method", false, false, false, 76), "html", null, true);
                yield "*60 + ";
                yield $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape(craft\helpers\Template::attribute($this->env, $this->source, (isset($context["value"]) || array_key_exists("value", $context) ? $context["value"] : (function () { throw new RuntimeError('Variable "value" does not exist.', 76, $this->source); })()), "format", ["s"], "method", false, false, false, 76), "html", null, true);
                yield ");";
            }
            craft\helpers\Template::js(ob_get_clean(), ['position' => 3]);
        }
        craft\helpers\Template::endProfile("template", "_includes/forms/time");
        yield from [];
    }

    /**
     * @codeCoverageIgnore
     */
    public function getTemplateName(): string
    {
        return "_includes/forms/time";
    }

    /**
     * @codeCoverageIgnore
     */
    public function isTraitable(): bool
    {
        return false;
    }

    /**
     * @codeCoverageIgnore
     */
    public function getDebugInfo(): array
    {
        return array (  159 => 76,  157 => 75,  153 => 72,  148 => 71,  146 => 70,  144 => 68,  142 => 64,  141 => 63,  140 => 62,  139 => 61,  138 => 60,  137 => 59,  135 => 58,  131 => 56,  129 => 24,  126 => 52,  124 => 51,  121 => 49,  119 => 48,  117 => 47,  115 => 43,  114 => 42,  113 => 39,  112 => 35,  111 => 34,  110 => 33,  109 => 32,  103 => 29,  98 => 28,  95 => 27,  92 => 26,  89 => 25,  87 => 24,  84 => 23,  80 => 22,  77 => 21,  74 => 19,  72 => 18,  70 => 16,  69 => 15,  68 => 14,  66 => 12,  63 => 11,  61 => 10,  59 => 9,  57 => 8,  55 => 7,  53 => 6,  51 => 5,  49 => 4,  47 => 3,  45 => 2,  43 => 1,);
    }

    public function getSourceContext(): Source
    {
        return new Source("{% set hasOuterContainer = hasOuterContainer ?? false %}
{% set id = (id ?? \"time#{random()}\") ~ '-time' -%}
{% set name = name ?? null -%}
{% set value = value ?? null -%}
{% set locale = craft.app.getFormattingLocale() %}
{% set outputLocaleParam = outputLocaleParam ?? true %}
{% set timeZone = timeZone ?? null %}
{% set outputTzParam = outputTzParam ?? true %}
{% set isMobile = craft.app.request.isMobileBrowser %}
{% set isDateTime = isDateTime ?? false %}

{% do view.registerAssetBundle('craft\\\\web\\\\assets\\\\timepicker\\\\TimepickerAsset') -%}

{% set containerAttributes = {
    class: ['timewrapper']|merge((class ?? [])|explodeClass),
}|merge(containerAttributes ?? [], recursive=true) %}

{%- if block('attr') is defined %}
    {%- set containerAttributes = containerAttributes|merge(('<div ' ~ block('attr') ~ '>')|parseAttr, recursive=true) %}
{% endif %}

{% if not hasOuterContainer %}<div class=\"datetimewrapper\">{% endif %}

{% tag 'div' with containerAttributes %}
    {% if not isMobile %}
        {% set formatRefId = \"#{id}-format\" %}
        {% set describedBy = [formatRefId, describedBy ?? null]|filter|join(' ') %}
        <span id=\"{{ formatRefId }}\" class=\"visually-hidden\">
            {{ locale.getTimeFormat('short', 'human') }}
        </span>
    {% endif %}
    {%- include \"_includes/forms/text\" with {
        type: isMobile ? 'time' : 'combobox',
        class: isMobile and not value ? 'empty-value' : false,
        name: name ? \"#{name}[time]\" : null,
        autocomplete: false,
        size: 10,
        placeholder: ' ',
        value: value ? value|time(isMobile ? 'H:i' : 'short', timeZone) : '',
        inputAttributes: {
            aria: {
                label: isDateTime ? 'Time'|t('app') : false,
                expanded: isMobile ? false : 'false',
            },
        },
    } -%}
    <div data-icon=\"time\"></div>
    {%- if name and outputLocaleParam -%}
        {{- hiddenInput(\"#{name}[locale]\", locale.id) -}}
    {%- endif -%}
    {%- if name and outputTzParam -%}
        {{- hiddenInput(\"#{name}[timezone]\", craft.app.getTimeZone()) -}}
    {%- endif -%}
{% endtag -%}

{% if not hasOuterContainer %}</div>{% endif %}

{%- if not isMobile -%}
    {% set options = {
        minTime: minTime ?? null,
        maxTime: maxTime ?? null,
        disableTimeRanges: disableTimeRanges ?? null,
        step: minuteIncrement ?? null,
        forceRoundTime: forceRoundTime ?? false,
    }|filter %}

    {#- include JSON_FORCE_OBJECT in the json_encode options -#}
    {%- set jsonOptions = constant('JSON_HEX_TAG') b-or constant('JSON_HEX_AMP') b-or constant('JSON_HEX_QUOT') b-or constant('JSON_FORCE_OBJECT') -%}

    {%- js -%}
        var \$timePicker = \$('#{{ id|namespaceInputId|e('js') }}');
        \$timePicker.timepicker(\$.extend({{ options|json_encode(jsonOptions)|raw }}, Craft.timepickerOptions));
        Craft.ui.remediateTimepickerA11y(\$timePicker);

        {%- if value and value.format is defined -%}
            \$timePicker.timepicker('setTime', {{ value.format('G') }}*3600 + {{ value.format('i') }}*60 + {{ value.format('s') }});
        {%- endif -%}
    {%- endjs -%}
{%- endif -%}
", "_includes/forms/time", "/var/www/html/backend/vendor/craftcms/cms/src/templates/_includes/forms/time.twig");
    }
}

<?php

use Twig\Environment;
use Twig\Error\LoaderError;
use Twig\Error\RuntimeError;
use Twig\Extension\CoreExtension;
use Twig\Extension\SandboxExtension;
use Twig\Markup;
use Twig\Sandbox\SecurityError;
use Twig\Sandbox\SecurityNotAllowedTagError;
use Twig\Sandbox\SecurityNotAllowedFilterError;
use Twig\Sandbox\SecurityNotAllowedFunctionError;
use Twig\Source;
use Twig\Template;
use Twig\TemplateWrapper;

/* _includes/forms/date */
class __TwigTemplate_db40b8c64dba0dd696486c94ff6dc2b1 extends Template
{
    private Source $source;
    /**
     * @var array<string, Template>
     */
    private array $macros = [];

    public function __construct(Environment $env)
    {
        parent::__construct($env);

        $this->source = $this->getSourceContext();

        $this->parent = false;

        $this->blocks = [
        ];
    }

    protected function doDisplay(array $context, array $blocks = []): iterable
    {
        $macros = $this->macros;
        craft\helpers\Template::beginProfile("template", "_includes/forms/date");
        // line 1
        $context["hasOuterContainer"] = (($context["hasOuterContainer"]) ?? (false));
        // line 2
        $context["id"] = ((($context["id"]) ?? (("date" . Twig\Extension\CoreExtension::random($this->env->getCharset())))) . "-date");
        // line 3
        $context["name"] = (($context["name"]) ?? (null));
        // line 4
        $context["value"] = (((($context["value"]) ?? (false))) ? ($this->extensions['craft\web\twig\Extension']->dateFunction($this->env, (isset($context["value"]) || array_key_exists("value", $context) ? $context["value"] : (function () { throw new RuntimeError('Variable "value" does not exist.', 4, $this->source); })()), false)) : (null));
        // line 5
        $context["locale"] = craft\helpers\Template::attribute($this->env, $this->source, craft\helpers\Template::attribute($this->env, $this->source, (isset($context["craft"]) || array_key_exists("craft", $context) ? $context["craft"] : (function () { throw new RuntimeError('Variable "craft" does not exist.', 5, $this->source); })()), "app", [], "any", false, false, false, 5), "getFormattingLocale", [], "method", false, false, false, 5);
        // line 6
        $context["outputLocaleParam"] = (($context["outputLocaleParam"]) ?? (true));
        // line 7
        $context["timeZone"] = (($context["timeZone"]) ?? (null));
        // line 8
        $context["outputTzParam"] = (($context["outputTzParam"]) ?? (true));
        // line 9
        $context["isMobile"] = craft\helpers\Template::attribute($this->env, $this->source, craft\helpers\Template::attribute($this->env, $this->source, craft\helpers\Template::attribute($this->env, $this->source, (isset($context["craft"]) || array_key_exists("craft", $context) ? $context["craft"] : (function () { throw new RuntimeError('Variable "craft" does not exist.', 9, $this->source); })()), "app", [], "any", false, false, false, 9), "request", [], "any", false, false, false, 9), "isMobileBrowser", [], "any", false, false, false, 9);
        // line 10
        $context["isDateTime"] = (($context["isDateTime"]) ?? (false));
        // line 11
        $context["disabled"] = (($context["disabled"]) ?? (false));
        // line 12
        yield "
";
        // line 13
        $context["containerAttributes"] = $this->extensions['craft\web\twig\Extension']->mergeFilter(["class" => $this->extensions['craft\web\twig\Extension']->mergeFilter(["datewrapper"], craft\helpers\Html::explodeClass(((        // line 14
$context["class"]) ?? ([]))))], ((        // line 15
$context["containerAttributes"]) ?? ([])), true);
        // line 17
        if (        $this->unwrap()->hasBlock("attr", $context, $blocks)) {
            // line 18
            $context["containerAttributes"] = $this->extensions['craft\web\twig\Extension']->mergeFilter((isset($context["containerAttributes"]) || array_key_exists("containerAttributes", $context) ? $context["containerAttributes"] : (function () { throw new RuntimeError('Variable "containerAttributes" does not exist.', 18, $this->source); })()), $this->extensions['craft\web\twig\Extension']->parseAttrFilter((("<div " .             $this->unwrap()->renderBlock("attr", $context, $blocks)) . ">")), true);
        }
        // line 20
        yield "
";
        // line 21
        if ( !(isset($context["hasOuterContainer"]) || array_key_exists("hasOuterContainer", $context) ? $context["hasOuterContainer"] : (function () { throw new RuntimeError('Variable "hasOuterContainer" does not exist.', 21, $this->source); })())) {
            yield "<div class=\"datetimewrapper\">";
        }
        // line 22
        yield "
";
        // line 23
        ob_start();
        // line 24
        yield "    ";
        if ( !(isset($context["isMobile"]) || array_key_exists("isMobile", $context) ? $context["isMobile"] : (function () { throw new RuntimeError('Variable "isMobile" does not exist.', 24, $this->source); })())) {
            // line 25
            yield "        ";
            $context["formatRefId"] = ((isset($context["id"]) || array_key_exists("id", $context) ? $context["id"] : (function () { throw new RuntimeError('Variable "id" does not exist.', 25, $this->source); })()) . "-format");
            // line 26
            yield "        ";
            $context["describedBy"] = Twig\Extension\CoreExtension::join($this->extensions['craft\web\twig\Extension']->filterFilter($this->env, [(isset($context["formatRefId"]) || array_key_exists("formatRefId", $context) ? $context["formatRefId"] : (function () { throw new RuntimeError('Variable "formatRefId" does not exist.', 26, $this->source); })()), (($context["describedBy"]) ?? (null))]), " ");
            // line 27
            yield "        <span id=\"";
            yield $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape((isset($context["formatRefId"]) || array_key_exists("formatRefId", $context) ? $context["formatRefId"] : (function () { throw new RuntimeError('Variable "formatRefId" does not exist.', 27, $this->source); })()), "html", null, true);
            yield "\" class=\"visually-hidden\">
            ";
            // line 28
            yield $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape(craft\helpers\Template::attribute($this->env, $this->source, (isset($context["locale"]) || array_key_exists("locale", $context) ? $context["locale"] : (function () { throw new RuntimeError('Variable "locale" does not exist.', 28, $this->source); })()), "getDateFormat", ["short", "human"], "method", false, false, false, 28), "html", null, true);
            yield "
        </span>
    ";
        }
        // line 31
        yield from $this->loadTemplate("_includes/forms/text", "_includes/forms/date", 31)->unwrap()->yield(CoreExtension::merge($context, ["type" => ((        // line 32
(isset($context["isMobile"]) || array_key_exists("isMobile", $context) ? $context["isMobile"] : (function () { throw new RuntimeError('Variable "isMobile" does not exist.', 32, $this->source); })())) ? ("date") : ("text")), "class" => (((        // line 33
(isset($context["isMobile"]) || array_key_exists("isMobile", $context) ? $context["isMobile"] : (function () { throw new RuntimeError('Variable "isMobile" does not exist.', 33, $this->source); })()) &&  !(isset($context["value"]) || array_key_exists("value", $context) ? $context["value"] : (function () { throw new RuntimeError('Variable "value" does not exist.', 33, $this->source); })()))) ? ("empty-value") : (false)), "name" => ((        // line 34
(isset($context["name"]) || array_key_exists("name", $context) ? $context["name"] : (function () { throw new RuntimeError('Variable "name" does not exist.', 34, $this->source); })())) ? (((isset($context["name"]) || array_key_exists("name", $context) ? $context["name"] : (function () { throw new RuntimeError('Variable "name" does not exist.', 34, $this->source); })()) . "[date]")) : (null)), "autocomplete" => false, "size" => 10, "placeholder" => " ", "value" => ((        // line 38
(isset($context["value"]) || array_key_exists("value", $context) ? $context["value"] : (function () { throw new RuntimeError('Variable "value" does not exist.', 38, $this->source); })())) ? ($this->extensions['craft\web\twig\Extension']->dateFilter($this->env, (isset($context["value"]) || array_key_exists("value", $context) ? $context["value"] : (function () { throw new RuntimeError('Variable "value" does not exist.', 38, $this->source); })()), (((isset($context["isMobile"]) || array_key_exists("isMobile", $context) ? $context["isMobile"] : (function () { throw new RuntimeError('Variable "isMobile" does not exist.', 38, $this->source); })())) ? ("Y-m-d") : ("short")), (isset($context["timeZone"]) || array_key_exists("timeZone", $context) ? $context["timeZone"] : (function () { throw new RuntimeError('Variable "timeZone" does not exist.', 38, $this->source); })()))) : ("")), "inputAttributes" => ["aria" => ["label" => ((        // line 41
(isset($context["isDateTime"]) || array_key_exists("isDateTime", $context) ? $context["isDateTime"] : (function () { throw new RuntimeError('Variable "isDateTime" does not exist.', 41, $this->source); })())) ? ($this->extensions['craft\web\twig\Extension']->translateFilter("Date", "app")) : (false))]]]));
        // line 45
        yield "<div data-icon=\"date\"></div>";
        // line 46
        if (((isset($context["name"]) || array_key_exists("name", $context) ? $context["name"] : (function () { throw new RuntimeError('Variable "name" does not exist.', 46, $this->source); })()) && (isset($context["outputLocaleParam"]) || array_key_exists("outputLocaleParam", $context) ? $context["outputLocaleParam"] : (function () { throw new RuntimeError('Variable "outputLocaleParam" does not exist.', 46, $this->source); })()))) {
            // line 47
            yield craft\helpers\Html::hiddenInput(((isset($context["name"]) || array_key_exists("name", $context) ? $context["name"] : (function () { throw new RuntimeError('Variable "name" does not exist.', 47, $this->source); })()) . "[locale]"), craft\helpers\Template::attribute($this->env, $this->source, (isset($context["locale"]) || array_key_exists("locale", $context) ? $context["locale"] : (function () { throw new RuntimeError('Variable "locale" does not exist.', 47, $this->source); })()), "id", [], "any", false, false, false, 47));
        }
        // line 49
        if (((isset($context["name"]) || array_key_exists("name", $context) ? $context["name"] : (function () { throw new RuntimeError('Variable "name" does not exist.', 49, $this->source); })()) && (isset($context["outputTzParam"]) || array_key_exists("outputTzParam", $context) ? $context["outputTzParam"] : (function () { throw new RuntimeError('Variable "outputTzParam" does not exist.', 49, $this->source); })()))) {
            // line 50
            yield craft\helpers\Html::hiddenInput(((isset($context["name"]) || array_key_exists("name", $context) ? $context["name"] : (function () { throw new RuntimeError('Variable "name" does not exist.', 50, $this->source); })()) . "[timezone]"), craft\helpers\Template::attribute($this->env, $this->source, craft\helpers\Template::attribute($this->env, $this->source, (isset($context["craft"]) || array_key_exists("craft", $context) ? $context["craft"] : (function () { throw new RuntimeError('Variable "craft" does not exist.', 50, $this->source); })()), "app", [], "any", false, false, false, 50), "getTimeZone", [], "method", false, false, false, 50));
        }
        echo craft\helpers\Html::tag("div", ob_get_clean(),         // line 23
(isset($context["containerAttributes"]) || array_key_exists("containerAttributes", $context) ? $context["containerAttributes"] : (function () { throw new RuntimeError('Variable "containerAttributes" does not exist.', 23, $this->source); })()));
        // line 53
        yield "
";
        // line 54
        if ( !(isset($context["hasOuterContainer"]) || array_key_exists("hasOuterContainer", $context) ? $context["hasOuterContainer"] : (function () { throw new RuntimeError('Variable "hasOuterContainer" does not exist.', 54, $this->source); })())) {
            yield "</div>";
        }
        // line 56
        if (( !(isset($context["isMobile"]) || array_key_exists("isMobile", $context) ? $context["isMobile"] : (function () { throw new RuntimeError('Variable "isMobile" does not exist.', 56, $this->source); })()) &&  !(isset($context["disabled"]) || array_key_exists("disabled", $context) ? $context["disabled"] : (function () { throw new RuntimeError('Variable "disabled" does not exist.', 56, $this->source); })()))) {
            // line 57
            ob_start();
            // line 58
            yield "\$('#";
            yield $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($this->env->getFilter('namespaceInputId')->getCallable()((isset($context["id"]) || array_key_exists("id", $context) ? $context["id"] : (function () { throw new RuntimeError('Variable "id" does not exist.', 58, $this->source); })())), "js"), "html", null, true);
            yield "').datepicker(\$.extend({
            defaultDate: new Date(";
            // line 59
            if ((isset($context["value"]) || array_key_exists("value", $context) ? $context["value"] : (function () { throw new RuntimeError('Variable "value" does not exist.', 59, $this->source); })())) {
                yield $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape(craft\helpers\Template::attribute($this->env, $this->source, (isset($context["value"]) || array_key_exists("value", $context) ? $context["value"] : (function () { throw new RuntimeError('Variable "value" does not exist.', 59, $this->source); })()), "format", ["Y"], "method", false, false, false, 59), "html", null, true);
                yield ", ";
                yield $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape((craft\helpers\Template::attribute($this->env, $this->source, (isset($context["value"]) || array_key_exists("value", $context) ? $context["value"] : (function () { throw new RuntimeError('Variable "value" does not exist.', 59, $this->source); })()), "format", ["n"], "method", false, false, false, 59) - 1), "html", null, true);
                yield ", ";
                yield $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape(craft\helpers\Template::attribute($this->env, $this->source, (isset($context["value"]) || array_key_exists("value", $context) ? $context["value"] : (function () { throw new RuntimeError('Variable "value" does not exist.', 59, $this->source); })()), "format", ["j"], "method", false, false, false, 59), "html", null, true);
            }
            yield ")
        }, Craft.datepickerOptions));";
            craft\helpers\Template::js(ob_get_clean(), ['position' => 3]);
        }
        craft\helpers\Template::endProfile("template", "_includes/forms/date");
        yield from [];
    }

    /**
     * @codeCoverageIgnore
     */
    public function getTemplateName(): string
    {
        return "_includes/forms/date";
    }

    /**
     * @codeCoverageIgnore
     */
    public function isTraitable(): bool
    {
        return false;
    }

    /**
     * @codeCoverageIgnore
     */
    public function getDebugInfo(): array
    {
        return array (  146 => 59,  141 => 58,  139 => 57,  137 => 56,  133 => 54,  130 => 53,  128 => 23,  125 => 50,  123 => 49,  120 => 47,  118 => 46,  116 => 45,  114 => 41,  113 => 38,  112 => 34,  111 => 33,  110 => 32,  109 => 31,  103 => 28,  98 => 27,  95 => 26,  92 => 25,  89 => 24,  87 => 23,  84 => 22,  80 => 21,  77 => 20,  74 => 18,  72 => 17,  70 => 15,  69 => 14,  68 => 13,  65 => 12,  63 => 11,  61 => 10,  59 => 9,  57 => 8,  55 => 7,  53 => 6,  51 => 5,  49 => 4,  47 => 3,  45 => 2,  43 => 1,);
    }

    public function getSourceContext(): Source
    {
        return new Source("{% set hasOuterContainer = hasOuterContainer ?? false %}
{% set id = (id ?? \"date#{random()}\") ~ '-date' -%}
{% set name = name ?? null -%}
{% set value = (value ?? false) ? date(value, false) : null -%}
{% set locale = craft.app.getFormattingLocale() %}
{% set outputLocaleParam = outputLocaleParam ?? true %}
{% set timeZone = timeZone ?? null %}
{% set outputTzParam = outputTzParam ?? true %}
{% set isMobile = craft.app.request.isMobileBrowser %}
{% set isDateTime = isDateTime ?? false %}
{% set disabled = disabled ?? false %}

{% set containerAttributes = {
    class: ['datewrapper']|merge((class ?? [])|explodeClass),
}|merge(containerAttributes ?? [], recursive=true) %}

{%- if block('attr') is defined %}
    {%- set containerAttributes = containerAttributes|merge(('<div ' ~ block('attr') ~ '>')|parseAttr, recursive=true) %}
{% endif %}

{% if not hasOuterContainer %}<div class=\"datetimewrapper\">{% endif %}

{% tag 'div' with containerAttributes %}
    {% if not isMobile %}
        {% set formatRefId = \"#{id}-format\" %}
        {% set describedBy = [formatRefId, describedBy ?? null]|filter|join(' ') %}
        <span id=\"{{ formatRefId }}\" class=\"visually-hidden\">
            {{ locale.getDateFormat('short', 'human') }}
        </span>
    {% endif %}
    {%- include \"_includes/forms/text\" with {
        type: isMobile ? 'date' : 'text',
        class: isMobile and not value ? 'empty-value' : false,
        name: name ? \"#{name}[date]\" : null,
        autocomplete: false,
        size: 10,
        placeholder: ' ',
        value: value ? value|date(isMobile ? 'Y-m-d' : 'short', timeZone) : '',
        inputAttributes: {
            aria: {
                label: isDateTime ? 'Date'|t('app') : false,
            },
        },
    } -%}
    <div data-icon=\"date\"></div>
    {%- if name and outputLocaleParam -%}
        {{- hiddenInput(\"#{name}[locale]\", locale.id) -}}
    {%- endif -%}
    {%- if name and outputTzParam -%}
        {{- hiddenInput(\"#{name}[timezone]\", craft.app.getTimeZone()) -}}
    {%- endif -%}
{% endtag %}

{% if not hasOuterContainer %}</div>{% endif %}

{%- if not isMobile and not disabled -%}
    {%- js -%}
        \$('#{{ id|namespaceInputId|e('js') }}').datepicker(\$.extend({
            defaultDate: new Date({% if value %}{{ value.format('Y') }}, {{ value.format('n')-1 }}, {{ value.format('j') }}{% endif %})
        }, Craft.datepickerOptions));
    {%- endjs -%}
{%- endif -%}
", "_includes/forms/date", "/var/www/html/backend/vendor/craftcms/cms/src/templates/_includes/forms/date.twig");
    }
}

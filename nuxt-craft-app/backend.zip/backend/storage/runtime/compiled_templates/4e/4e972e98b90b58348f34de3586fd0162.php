<?php

use Twig\Environment;
use Twig\Error\LoaderError;
use Twig\Error\RuntimeError;
use Twig\Extension\CoreExtension;
use Twig\Extension\SandboxExtension;
use Twig\Markup;
use Twig\Sandbox\SecurityError;
use Twig\Sandbox\SecurityNotAllowedTagError;
use Twig\Sandbox\SecurityNotAllowedFilterError;
use Twig\Sandbox\SecurityNotAllowedFunctionError;
use Twig\Source;
use Twig\Template;
use Twig\TemplateWrapper;

/* graphql/schemas/_index.twig */
class __TwigTemplate_7478fadc6d35663a7c587a2b77118e1e extends Template
{
    private Source $source;
    /**
     * @var array<string, Template>
     */
    private array $macros = [];

    public function __construct(Environment $env)
    {
        parent::__construct($env);

        $this->source = $this->getSourceContext();

        $this->blocks = [
            'actionButton' => [$this, 'block_actionButton'],
            'content' => [$this, 'block_content'],
        ];
    }

    protected function doGetParent(array $context): bool|string|Template|TemplateWrapper
    {
        // line 1
        return "_layouts/cp";
    }

    protected function doDisplay(array $context, array $blocks = []): iterable
    {
        $macros = $this->macros;
        craft\helpers\Template::beginProfile("template", "graphql/schemas/_index.twig");
        // line 2
        $context["title"] = $this->extensions['craft\web\twig\Extension']->translateFilter("GraphQL Schemas", "app");
        // line 4
        craft\helpers\Template::attribute($this->env, $this->source, (isset($context["view"]) || array_key_exists("view", $context) ? $context["view"] : (function () { throw new RuntimeError('Variable "view" does not exist.', 4, $this->source); })()), "registerAssetBundle", ["craft\\web\\assets\\admintable\\AdminTableAsset"], "method", false, false, false, 4);
        // line 6
        $context["selectedSubnavItem"] = "schemas";
        // line 16
        $context["tableData"] = [];
        // line 17
        $context['_parent'] = $context;
        $context['_seq'] = CoreExtension::ensureTraversable(craft\helpers\Template::attribute($this->env, $this->source, craft\helpers\Template::attribute($this->env, $this->source, craft\helpers\Template::attribute($this->env, $this->source, (isset($context["craft"]) || array_key_exists("craft", $context) ? $context["craft"] : (function () { throw new RuntimeError('Variable "craft" does not exist.', 17, $this->source); })()), "app", [], "any", false, false, false, 17), "gql", [], "any", false, false, false, 17), "schemas", [], "any", false, false, false, 17));
        foreach ($context['_seq'] as $context["_key"] => $context["schema"]) {
            // line 18
            $context["tableData"] = $this->extensions['craft\web\twig\Extension']->mergeFilter((isset($context["tableData"]) || array_key_exists("tableData", $context) ? $context["tableData"] : (function () { throw new RuntimeError('Variable "tableData" does not exist.', 18, $this->source); })()), [["id" => craft\helpers\Template::attribute($this->env, $this->source,             // line 19
$context["schema"], "id", [], "any", false, false, false, 19), "title" => ((craft\helpers\Template::attribute($this->env, $this->source,             // line 20
$context["schema"], "isPublic", [], "any", false, false, false, 20)) ? ($this->extensions['craft\web\twig\Extension']->translateFilter("Public Schema", "app")) : ($this->extensions['craft\web\twig\Extension']->translateFilter(craft\helpers\Template::attribute($this->env, $this->source, $context["schema"], "name", [], "any", false, false, false, 20), "site"))), "url" => ((craft\helpers\Template::attribute($this->env, $this->source,             // line 21
$context["schema"], "isPublic", [], "any", false, false, false, 21)) ? (craft\helpers\UrlHelper::url("graphql/schemas/public")) : (craft\helpers\UrlHelper::url(("graphql/schemas/" . craft\helpers\Template::attribute($this->env, $this->source, $context["schema"], "id", [], "any", false, false, false, 21))))), "_showDelete" =>  !craft\helpers\Template::attribute($this->env, $this->source,             // line 22
$context["schema"], "isPublic", [], "any", false, false, false, 22)]]);
        }
        $_parent = $context['_parent'];
        unset($context['_seq'], $context['_key'], $context['schema'], $context['_parent']);
        $context = array_intersect_key($context, $_parent) + $_parent;
        // line 26
        ob_start();
        // line 27
        yield "var columns = [
    { name: '__slot:title', title: Craft.t('app', 'Name') },
];

new Craft.VueAdminTable({
    columns: columns,
    container: '#schemas-vue-admin-table',
    deleteAction: 'graphql/delete-schema',
    tableData: ";
        // line 35
        yield $this->extensions['craft\web\twig\Extension']->jsonEncodeFilter((isset($context["tableData"]) || array_key_exists("tableData", $context) ? $context["tableData"] : (function () { throw new RuntimeError('Variable "tableData" does not exist.', 35, $this->source); })()));
        yield "
});
";
        craft\helpers\Template::js(ob_get_clean(), ['position' => 3]);
        // line 1
        $this->parent = $this->loadTemplate("_layouts/cp", "graphql/schemas/_index.twig", 1);
        yield from $this->parent->unwrap()->yield($context, array_merge($this->blocks, $blocks));
        craft\helpers\Template::endProfile("template", "graphql/schemas/_index.twig");
    }

    // line 8
    /**
     * @return iterable<null|scalar|\Stringable>
     */
    public function block_actionButton(array $context, array $blocks = []): iterable
    {
        $macros = $this->macros;
        craft\helpers\Template::beginProfile("block", "actionButton");
        // line 9
        yield "    <a class=\"btn submit add icon\" href=\"";
        yield $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape(craft\helpers\UrlHelper::url("graphql/schemas/new"), "html", null, true);
        yield "\">";
        yield $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($this->extensions['craft\web\twig\Extension']->translateFilter("New schema", "app"), "html", null, true);
        yield "</a>
";
        craft\helpers\Template::endProfile("block", "actionButton");
        yield from [];
    }

    // line 12
    /**
     * @return iterable<null|scalar|\Stringable>
     */
    public function block_content(array $context, array $blocks = []): iterable
    {
        $macros = $this->macros;
        craft\helpers\Template::beginProfile("block", "content");
        // line 13
        yield "    <div id=\"schemas-vue-admin-table\"></div>
";
        craft\helpers\Template::endProfile("block", "content");
        yield from [];
    }

    /**
     * @codeCoverageIgnore
     */
    public function getTemplateName(): string
    {
        return "graphql/schemas/_index.twig";
    }

    /**
     * @codeCoverageIgnore
     */
    public function isTraitable(): bool
    {
        return false;
    }

    /**
     * @codeCoverageIgnore
     */
    public function getDebugInfo(): array
    {
        return array (  122 => 13,  114 => 12,  103 => 9,  95 => 8,  89 => 1,  83 => 35,  73 => 27,  71 => 26,  65 => 22,  64 => 21,  63 => 20,  62 => 19,  61 => 18,  57 => 17,  55 => 16,  53 => 6,  51 => 4,  49 => 2,  41 => 1,);
    }

    public function getSourceContext(): Source
    {
        return new Source("{% extends \"_layouts/cp\" %}
{% set title = \"GraphQL Schemas\"|t('app') %}

{% do view.registerAssetBundle('craft\\\\web\\\\assets\\\\admintable\\\\AdminTableAsset') -%}

{% set selectedSubnavItem = 'schemas' %}

{% block actionButton %}
    <a class=\"btn submit add icon\" href=\"{{ url('graphql/schemas/new') }}\">{{ \"New schema\"|t('app') }}</a>
{% endblock %}

{% block content %}
    <div id=\"schemas-vue-admin-table\"></div>
{% endblock %}

{% set tableData = [] %}
{% for schema in craft.app.gql.schemas %}
\t{% set tableData = tableData|merge([{
        id: schema.id,
        title: schema.isPublic ? 'Public Schema'|t('app') : schema.name|t('site'),
        url: schema.isPublic ? url('graphql/schemas/public') : url(\"graphql/schemas/#{schema.id}\"),
        _showDelete: not schema.isPublic
    }]) %}
{% endfor %}

{% js %}
var columns = [
    { name: '__slot:title', title: Craft.t('app', 'Name') },
];

new Craft.VueAdminTable({
    columns: columns,
    container: '#schemas-vue-admin-table',
    deleteAction: 'graphql/delete-schema',
    tableData: {{ tableData|json_encode|raw }}
});
{% endjs %}
", "graphql/schemas/_index.twig", "/var/www/html/backend/vendor/craftcms/cms/src/templates/graphql/schemas/_index.twig");
    }
}

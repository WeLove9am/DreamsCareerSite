<?php

use Twig\Environment;
use Twig\Error\LoaderError;
use Twig\Error\RuntimeError;
use Twig\Extension\CoreExtension;
use Twig\Extension\SandboxExtension;
use Twig\Markup;
use Twig\Sandbox\SecurityError;
use Twig\Sandbox\SecurityNotAllowedTagError;
use Twig\Sandbox\SecurityNotAllowedFilterError;
use Twig\Sandbox\SecurityNotAllowedFunctionError;
use Twig\Source;
use Twig\Template;
use Twig\TemplateWrapper;

/* graphql/schemas/_edit.twig */
class __TwigTemplate_dc00bab56feed6e62f78e44e84011364 extends Template
{
    private Source $source;
    /**
     * @var array<string, Template>
     */
    private array $macros = [];

    public function __construct(Environment $env)
    {
        parent::__construct($env);

        $this->source = $this->getSourceContext();

        $this->blocks = [
            'content' => [$this, 'block_content'],
            'details' => [$this, 'block_details'],
        ];
    }

    protected function doGetParent(array $context): bool|string|Template|TemplateWrapper
    {
        // line 1
        return "_layouts/cp";
    }

    protected function doDisplay(array $context, array $blocks = []): iterable
    {
        $macros = $this->macros;
        craft\helpers\Template::beginProfile("template", "graphql/schemas/_edit.twig");
        // line 3
        $context["selectedSubnavItem"] = "schemas";
        // line 5
        $context["fullPageForm"] = true;
        // line 7
        $context["formActions"] = [["label" => $this->extensions['craft\web\twig\Extension']->translateFilter("Save and continue editing", "app"), "redirect" => $this->env->getFilter('hash')->getCallable()(((craft\helpers\Template::attribute($this->env, $this->source,         // line 10
(isset($context["schema"]) || array_key_exists("schema", $context) ? $context["schema"] : (function () { throw new RuntimeError('Variable "schema" does not exist.', 10, $this->source); })()), "isPublic", [], "any", false, false, false, 10)) ? ("graphql/schemas/public") : ("graphql/schemas/{id}"))), "shortcut" => true, "retainScroll" => true]];
        // line 16
        $context["crumbs"] = [["label" => $this->extensions['craft\web\twig\Extension']->translateFilter("GraphQL Schemas", "app"), "url" => craft\helpers\UrlHelper::url("graphql/schemas")]];
        // line 20
        $macros["forms"] = $this->macros["forms"] = $this->loadTemplate("_includes/forms", "graphql/schemas/_edit.twig", 20)->unwrap();
        // line 61
        $macros["_v0"] = $this->macros["_v0"] = $this;
        // line 63
        craft\helpers\Template::attribute($this->env, $this->source, (isset($context["view"]) || array_key_exists("view", $context) ? $context["view"] : (function () { throw new RuntimeError('Variable "view" does not exist.', 63, $this->source); })()), "registerTranslations", ["app", ["Select All", "Deselect All"]], "method", false, false, false, 63);
        // line 68
        craft\helpers\Template::attribute($this->env, $this->source, (isset($context["view"]) || array_key_exists("view", $context) ? $context["view"] : (function () { throw new RuntimeError('Variable "view" does not exist.', 68, $this->source); })()), "registerAssetBundle", ["craft\\web\\assets\\userpermissions\\UserPermissionsAsset"], "method", false, false, false, 68);
        // line 140
        ob_start();
        // line 141
        yield "    new Craft.ElevatedSessionForm('#main-form');
";
        craft\helpers\Template::js(ob_get_clean(), ['position' => 3]);
        // line 1
        $this->parent = $this->loadTemplate("_layouts/cp", "graphql/schemas/_edit.twig", 1);
        yield from $this->parent->unwrap()->yield($context, array_merge($this->blocks, $blocks));
        craft\helpers\Template::endProfile("template", "graphql/schemas/_edit.twig");
    }

    // line 70
    /**
     * @return iterable<null|scalar|\Stringable>
     */
    public function block_content(array $context, array $blocks = []): iterable
    {
        $macros = $this->macros;
        craft\helpers\Template::beginProfile("block", "content");
        // line 71
        yield "    ";
        yield craft\helpers\Html::actionInput(((craft\helpers\Template::attribute($this->env, $this->source, (isset($context["schema"]) || array_key_exists("schema", $context) ? $context["schema"] : (function () { throw new RuntimeError('Variable "schema" does not exist.', 71, $this->source); })()), "isPublic", [], "any", false, false, false, 71)) ? ("graphql/save-public-schema") : ("graphql/save-schema")));
        yield "
    ";
        // line 72
        yield craft\helpers\Html::redirectInput("graphql/schemas");
        yield "
    ";
        // line 73
        if (craft\helpers\Template::attribute($this->env, $this->source, (isset($context["schema"]) || array_key_exists("schema", $context) ? $context["schema"] : (function () { throw new RuntimeError('Variable "schema" does not exist.', 73, $this->source); })()), "id", [], "any", false, false, false, 73)) {
            yield craft\helpers\Html::hiddenInput("schemaId", craft\helpers\Template::attribute($this->env, $this->source, (isset($context["schema"]) || array_key_exists("schema", $context) ? $context["schema"] : (function () { throw new RuntimeError('Variable "schema" does not exist.', 73, $this->source); })()), "id", [], "any", false, false, false, 73));
        }
        // line 74
        yield "
    ";
        // line 75
        if ( !craft\helpers\Template::attribute($this->env, $this->source, (isset($context["schema"]) || array_key_exists("schema", $context) ? $context["schema"] : (function () { throw new RuntimeError('Variable "schema" does not exist.', 75, $this->source); })()), "isPublic", [], "any", false, false, false, 75)) {
            // line 76
            yield "        ";
            yield $macros["forms"]->getTemplateForMacro("macro_textField", $context, 76, $this->getSourceContext())->macro_textField(...[["first" => true, "label" => $this->extensions['craft\web\twig\Extension']->translateFilter("Name", "app"), "instructions" => $this->extensions['craft\web\twig\Extension']->translateFilter("What this schema will be called in the control panel.", "app"), "id" => "name", "name" => "name", "value" => craft\helpers\Template::attribute($this->env, $this->source,             // line 82
(isset($context["schema"]) || array_key_exists("schema", $context) ? $context["schema"] : (function () { throw new RuntimeError('Variable "schema" does not exist.', 82, $this->source); })()), "name", [], "any", false, false, false, 82), "errors" => craft\helpers\Template::attribute($this->env, $this->source,             // line 83
(isset($context["schema"]) || array_key_exists("schema", $context) ? $context["schema"] : (function () { throw new RuntimeError('Variable "schema" does not exist.', 83, $this->source); })()), "getErrors", ["name"], "method", false, false, false, 83), "autofocus" => true, "required" => true]]);
            // line 86
            yield "

        <hr>
    ";
        }
        // line 90
        yield "
    <h2>";
        // line 91
        yield $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($this->extensions['craft\web\twig\Extension']->translateFilter("Choose the available content for querying with this schema:", "app"), "html", null, true);
        yield "</h2>

    ";
        // line 93
        $context["schemaComponents"] = craft\helpers\Template::attribute($this->env, $this->source, craft\helpers\Template::attribute($this->env, $this->source, craft\helpers\Template::attribute($this->env, $this->source, (isset($context["craft"]) || array_key_exists("craft", $context) ? $context["craft"] : (function () { throw new RuntimeError('Variable "craft" does not exist.', 93, $this->source); })()), "app", [], "any", false, false, false, 93), "gql", [], "any", false, false, false, 93), "getAllSchemaComponents", [], "any", false, false, false, 93);
        // line 94
        yield "
    ";
        // line 95
        $context['_parent'] = $context;
        $context['_seq'] = CoreExtension::ensureTraversable($this->extensions['craft\web\twig\Extension']->filterFilter($this->env, craft\helpers\Template::attribute($this->env, $this->source, (isset($context["schemaComponents"]) || array_key_exists("schemaComponents", $context) ? $context["schemaComponents"] : (function () { throw new RuntimeError('Variable "schemaComponents" does not exist.', 95, $this->source); })()), "queries", [], "any", false, false, false, 95)));
        foreach ($context['_seq'] as $context["category"] => $context["catPermissions"]) {
            // line 96
            yield "        <div class=\"user-permissions\">
            <h3>";
            // line 97
            yield $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($context["category"], "html", null, true);
            yield "</h3>
            <div class=\"select-all\"></div>

            ";
            // line 100
            yield $macros["_v0"]->getTemplateForMacro("macro_permissionList", $context, 100, $this->getSourceContext())->macro_permissionList(...[(isset($context["schema"]) || array_key_exists("schema", $context) ? $context["schema"] : (function () { throw new RuntimeError('Variable "schema" does not exist.', 100, $this->source); })()), $context["catPermissions"]]);
            yield "
        </div>
    ";
        }
        $_parent = $context['_parent'];
        unset($context['_seq'], $context['category'], $context['catPermissions'], $context['_parent']);
        $context = array_intersect_key($context, $_parent) + $_parent;
        // line 103
        yield "
    <hr/>
    <h2>";
        // line 105
        yield $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($this->extensions['craft\web\twig\Extension']->translateFilter("Choose the available mutations for this schema:", "app"), "html", null, true);
        yield "</h2>

    ";
        // line 107
        $context['_parent'] = $context;
        $context['_seq'] = CoreExtension::ensureTraversable($this->extensions['craft\web\twig\Extension']->filterFilter($this->env, craft\helpers\Template::attribute($this->env, $this->source, (isset($context["schemaComponents"]) || array_key_exists("schemaComponents", $context) ? $context["schemaComponents"] : (function () { throw new RuntimeError('Variable "schemaComponents" does not exist.', 107, $this->source); })()), "mutations", [], "any", false, false, false, 107)));
        foreach ($context['_seq'] as $context["category"] => $context["catPermissions"]) {
            // line 108
            yield "        <div class=\"user-permissions\">
            <h3>";
            // line 109
            yield $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($context["category"], "html", null, true);
            yield "</h3>
            <div class=\"select-all\"></div>

            ";
            // line 112
            yield $macros["_v0"]->getTemplateForMacro("macro_permissionList", $context, 112, $this->getSourceContext())->macro_permissionList(...[(isset($context["schema"]) || array_key_exists("schema", $context) ? $context["schema"] : (function () { throw new RuntimeError('Variable "schema" does not exist.', 112, $this->source); })()), $context["catPermissions"]]);
            yield "
        </div>
    ";
        }
        $_parent = $context['_parent'];
        unset($context['_seq'], $context['category'], $context['catPermissions'], $context['_parent']);
        $context = array_intersect_key($context, $_parent) + $_parent;
        // line 115
        yield "

";
        craft\helpers\Template::endProfile("block", "content");
        yield from [];
    }

    // line 119
    /**
     * @return iterable<null|scalar|\Stringable>
     */
    public function block_details(array $context, array $blocks = []): iterable
    {
        $macros = $this->macros;
        craft\helpers\Template::beginProfile("block", "details");
        // line 120
        yield "    ";
        if (craft\helpers\Template::attribute($this->env, $this->source, (isset($context["schema"]) || array_key_exists("schema", $context) ? $context["schema"] : (function () { throw new RuntimeError('Variable "schema" does not exist.', 120, $this->source); })()), "isPublic", [], "any", false, false, false, 120)) {
            // line 121
            yield "        <div class=\"meta\">
            ";
            // line 122
            yield $macros["forms"]->getTemplateForMacro("macro_lightswitchField", $context, 122, $this->getSourceContext())->macro_lightswitchField(...[["label" => $this->extensions['craft\web\twig\Extension']->translateFilter("Enabled", "app"), "id" => "enabled", "name" => "enabled", "on" => craft\helpers\Template::attribute($this->env, $this->source,             // line 126
(isset($context["token"]) || array_key_exists("token", $context) ? $context["token"] : (function () { throw new RuntimeError('Variable "token" does not exist.', 126, $this->source); })()), "enabled", [], "any", false, false, false, 126)]]);
            // line 127
            yield "

            ";
            // line 129
            yield $macros["forms"]->getTemplateForMacro("macro_dateTimeField", $context, 129, $this->getSourceContext())->macro_dateTimeField(...[["label" => $this->extensions['craft\web\twig\Extension']->translateFilter("Expiry Date", "app"), "id" => "expiryDate", "name" => "expiryDate", "value" => ((craft\helpers\Template::attribute($this->env, $this->source,             // line 133
(isset($context["token"]) || array_key_exists("token", $context) ? $context["token"] : (function () { throw new RuntimeError('Variable "token" does not exist.', 133, $this->source); })()), "expiryDate", [], "any", false, false, false, 133)) ? (craft\helpers\Template::attribute($this->env, $this->source, (isset($context["token"]) || array_key_exists("token", $context) ? $context["token"] : (function () { throw new RuntimeError('Variable "token" does not exist.', 133, $this->source); })()), "expiryDate", [], "any", false, false, false, 133)) : (null)), "errors" => craft\helpers\Template::attribute($this->env, $this->source,             // line 134
(isset($context["token"]) || array_key_exists("token", $context) ? $context["token"] : (function () { throw new RuntimeError('Variable "token" does not exist.', 134, $this->source); })()), "getErrors", ["expiryDate"], "method", false, false, false, 134)]]);
            // line 135
            yield "
        </div>
    ";
        }
        craft\helpers\Template::endProfile("block", "details");
        yield from [];
    }

    // line 22
    public function macro_permissionList($schema = null, $permissions = null, $id = null, $disabled = null, ...$varargs): string|Markup
    {
        $macros = $this->macros;
        $context = [
            "schema" => $schema,
            "permissions" => $permissions,
            "id" => $id,
            "disabled" => $disabled,
            "varargs" => $varargs,
        ] + $this->env->getGlobals();

        $blocks = [];

        return ('' === $tmp = \Twig\Extension\CoreExtension::captureOutput((function () use (&$context, $macros, $blocks) {
            craft\helpers\Template::beginProfile("macro", "permissionList");
            // line 23
            yield "
    ";
            // line 24
            $macros["_v1"] = $this->loadTemplate("_includes/forms", "graphql/schemas/_edit.twig", 24)->unwrap();
            // line 25
            yield "    ";
            $macros["_v2"] = $this;
            // line 26
            yield "
    <ul";
            // line 27
            if ((isset($context["id"]) || array_key_exists("id", $context) ? $context["id"] : (function () { throw new RuntimeError('Variable "id" does not exist.', 27, $this->source); })())) {
                yield " id=\"";
                yield $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($this->extensions['craft\web\twig\Extension']->replaceFilter((isset($context["id"]) || array_key_exists("id", $context) ? $context["id"] : (function () { throw new RuntimeError('Variable "id" does not exist.', 27, $this->source); })()), ":", "-"), "html", null, true);
                yield "\"";
            }
            yield ">

        ";
            // line 29
            $context['_parent'] = $context;
            $context['_seq'] = CoreExtension::ensureTraversable((isset($context["permissions"]) || array_key_exists("permissions", $context) ? $context["permissions"] : (function () { throw new RuntimeError('Variable "permissions" does not exist.', 29, $this->source); })()));
            foreach ($context['_seq'] as $context["permissionName"] => $context["props"]) {
                // line 30
                yield "            ";
                if (craft\helpers\Template::attribute($this->env, $this->source, (isset($context["schema"]) || array_key_exists("schema", $context) ? $context["schema"] : (function () { throw new RuntimeError('Variable "schema" does not exist.', 30, $this->source); })()), "has", [$context["permissionName"]], "method", false, false, false, 30)) {
                    // line 31
                    yield "                ";
                    $context["checked"] = true;
                    // line 32
                    yield "            ";
                } else {
                    // line 33
                    yield "                ";
                    $context["checked"] = false;
                    // line 34
                    yield "            ";
                }
                // line 35
                yield "
            <li>
                ";
                // line 37
                yield $macros["_v1"]->getTemplateForMacro("macro_checkbox", $context, 37, $this->getSourceContext())->macro_checkbox(...[["label" => craft\helpers\Template::attribute($this->env, $this->source,                 // line 38
$context["props"], "label", [], "any", false, false, false, 38), "name" => "permissions[]", "value" =>                 // line 40
$context["permissionName"], "checked" =>                 // line 41
(isset($context["checked"]) || array_key_exists("checked", $context) ? $context["checked"] : (function () { throw new RuntimeError('Variable "checked" does not exist.', 41, $this->source); })()), "disabled" =>                 // line 42
(isset($context["disabled"]) || array_key_exists("disabled", $context) ? $context["disabled"] : (function () { throw new RuntimeError('Variable "disabled" does not exist.', 42, $this->source); })())]]);
                // line 43
                yield "

                ";
                // line 45
                if ((((craft\helpers\Template::attribute($this->env, $this->source, $context["props"], "info", [], "any", true, true, false, 45) &&  !(null === craft\helpers\Template::attribute($this->env, $this->source, $context["props"], "info", [], "any", false, false, false, 45)))) ? (craft\helpers\Template::attribute($this->env, $this->source, $context["props"], "info", [], "any", false, false, false, 45)) : (false))) {
                    // line 46
                    yield "                    <div class=\"info\">";
                    yield $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape(craft\helpers\Template::attribute($this->env, $this->source, $context["props"], "info", [], "any", false, false, false, 46), "html", null, true);
                    yield "</div>
                ";
                }
                // line 48
                yield "
                ";
                // line 49
                if ((((craft\helpers\Template::attribute($this->env, $this->source, $context["props"], "warning", [], "any", true, true, false, 49) &&  !(null === craft\helpers\Template::attribute($this->env, $this->source, $context["props"], "warning", [], "any", false, false, false, 49)))) ? (craft\helpers\Template::attribute($this->env, $this->source, $context["props"], "warning", [], "any", false, false, false, 49)) : (false))) {
                    // line 50
                    yield "                    <div class=\"info warning\">";
                    yield $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape(craft\helpers\Template::attribute($this->env, $this->source, $context["props"], "warning", [], "any", false, false, false, 50), "html", null, true);
                    yield "</div>
                ";
                }
                // line 52
                yield "
                ";
                // line 53
                if ((((craft\helpers\Template::attribute($this->env, $this->source, $context["props"], "nested", [], "any", true, true, false, 53) &&  !(null === craft\helpers\Template::attribute($this->env, $this->source, $context["props"], "nested", [], "any", false, false, false, 53)))) ? (craft\helpers\Template::attribute($this->env, $this->source, $context["props"], "nested", [], "any", false, false, false, 53)) : (false))) {
                    // line 54
                    yield "                    ";
                    yield $macros["_v2"]->getTemplateForMacro("macro_permissionList", $context, 54, $this->getSourceContext())->macro_permissionList(...[(isset($context["schema"]) || array_key_exists("schema", $context) ? $context["schema"] : (function () { throw new RuntimeError('Variable "schema" does not exist.', 54, $this->source); })()), craft\helpers\Template::attribute($this->env, $this->source, $context["props"], "nested", [], "any", false, false, false, 54), ($context["permissionName"] . "-nested"),  !(isset($context["checked"]) || array_key_exists("checked", $context) ? $context["checked"] : (function () { throw new RuntimeError('Variable "checked" does not exist.', 54, $this->source); })())]);
                    yield "
                ";
                }
                // line 56
                yield "            </li>
        ";
            }
            $_parent = $context['_parent'];
            unset($context['_seq'], $context['permissionName'], $context['props'], $context['_parent']);
            $context = array_intersect_key($context, $_parent) + $_parent;
            // line 58
            yield "    </ul>
";
            craft\helpers\Template::endProfile("macro", "permissionList");
            yield from [];
        })())) ? '' : new Markup($tmp, $this->env->getCharset());
    }

    /**
     * @codeCoverageIgnore
     */
    public function getTemplateName(): string
    {
        return "graphql/schemas/_edit.twig";
    }

    /**
     * @codeCoverageIgnore
     */
    public function isTraitable(): bool
    {
        return false;
    }

    /**
     * @codeCoverageIgnore
     */
    public function getDebugInfo(): array
    {
        return array (  329 => 58,  322 => 56,  316 => 54,  314 => 53,  311 => 52,  305 => 50,  303 => 49,  300 => 48,  294 => 46,  292 => 45,  288 => 43,  286 => 42,  285 => 41,  284 => 40,  283 => 38,  282 => 37,  278 => 35,  275 => 34,  272 => 33,  269 => 32,  266 => 31,  263 => 30,  259 => 29,  250 => 27,  247 => 26,  244 => 25,  242 => 24,  239 => 23,  223 => 22,  214 => 135,  212 => 134,  211 => 133,  210 => 129,  206 => 127,  204 => 126,  203 => 122,  200 => 121,  197 => 120,  189 => 119,  181 => 115,  172 => 112,  166 => 109,  163 => 108,  159 => 107,  154 => 105,  150 => 103,  141 => 100,  135 => 97,  132 => 96,  128 => 95,  125 => 94,  123 => 93,  118 => 91,  115 => 90,  109 => 86,  107 => 83,  106 => 82,  104 => 76,  102 => 75,  99 => 74,  95 => 73,  91 => 72,  86 => 71,  78 => 70,  72 => 1,  68 => 141,  66 => 140,  64 => 68,  62 => 63,  60 => 61,  58 => 20,  56 => 16,  54 => 10,  53 => 7,  51 => 5,  49 => 3,  41 => 1,);
    }

    public function getSourceContext(): Source
    {
        return new Source("{% extends \"_layouts/cp\" %}

{% set selectedSubnavItem = 'schemas' %}

{% set fullPageForm = true %}

{% set formActions = [
    {
        label: 'Save and continue editing'|t('app'),
        redirect: (schema.isPublic ? 'graphql/schemas/public' : 'graphql/schemas/{id}')|hash,
        shortcut: true,
        retainScroll: true,
    },
] %}

{% set crumbs = [
    { label: \"GraphQL Schemas\"|t('app'), url: url('graphql/schemas') }
] %}

{% import \"_includes/forms\" as forms %}

{% macro permissionList(schema, permissions, id, disabled) %}

    {% from \"_includes/forms\" import checkbox %}
    {% from _self import permissionList %}

    <ul{% if id %} id=\"{{ id|replace(':', '-') }}\"{% endif %}>

        {% for permissionName, props in permissions %}
            {% if schema.has(permissionName) %}
                {% set checked = true %}
            {% else %}
                {% set checked = false %}
            {% endif %}

            <li>
                {{ checkbox({
                    label: props.label,
                    name: 'permissions[]',
                    value: permissionName,
                    checked: checked,
                    disabled: disabled
                }) }}

                {% if props.info ?? false %}
                    <div class=\"info\">{{ props.info }}</div>
                {% endif %}

                {% if props.warning ?? false %}
                    <div class=\"info warning\">{{ props.warning }}</div>
                {% endif %}

                {% if props.nested ?? false %}
                    {{ permissionList(schema, props.nested, permissionName~'-nested', not checked) }}
                {% endif %}
            </li>
        {% endfor %}
    </ul>
{% endmacro %}

{% from _self import permissionList %}

{% do view.registerTranslations('app', [
    \"Select All\",
    \"Deselect All\",
]) %}

{% do view.registerAssetBundle(\"craft\\\\web\\\\assets\\\\userpermissions\\\\UserPermissionsAsset\") %}

{% block content %}
    {{ actionInput(schema.isPublic ? 'graphql/save-public-schema' : 'graphql/save-schema') }}
    {{ redirectInput('graphql/schemas') }}
    {% if schema.id %}{{ hiddenInput('schemaId', schema.id) }}{% endif %}

    {% if not schema.isPublic %}
        {{ forms.textField({
            first: true,
            label: \"Name\"|t('app'),
            instructions: \"What this schema will be called in the control panel.\"|t('app'),
            id: 'name',
            name: 'name',
            value: schema.name,
            errors: schema.getErrors('name'),
            autofocus: true,
            required: true
        }) }}

        <hr>
    {% endif %}

    <h2>{{ 'Choose the available content for querying with this schema:'|t('app') }}</h2>

    {% set schemaComponents = craft.app.gql.getAllSchemaComponents %}

    {% for category, catPermissions in schemaComponents.queries|filter %}
        <div class=\"user-permissions\">
            <h3>{{ category }}</h3>
            <div class=\"select-all\"></div>

            {{ permissionList(schema, catPermissions) }}
        </div>
    {% endfor %}

    <hr/>
    <h2>{{ 'Choose the available mutations for this schema:'|t('app') }}</h2>

    {% for category, catPermissions in schemaComponents.mutations|filter %}
        <div class=\"user-permissions\">
            <h3>{{ category }}</h3>
            <div class=\"select-all\"></div>

            {{ permissionList(schema, catPermissions) }}
        </div>
    {% endfor %}


{% endblock %}

{% block details %}
    {% if schema.isPublic %}
        <div class=\"meta\">
            {{ forms.lightswitchField({
                label: 'Enabled'|t('app'),
                id: 'enabled',
                name: 'enabled',
                on: token.enabled,
            }) }}

            {{ forms.dateTimeField({
                label: \"Expiry Date\"|t('app'),
                id: 'expiryDate',
                name: 'expiryDate',
                value: (token.expiryDate ? token.expiryDate : null),
                errors: token.getErrors('expiryDate')
            }) }}
        </div>
    {% endif %}
{% endblock %}

{% js %}
    new Craft.ElevatedSessionForm('#main-form');
{% endjs %}
", "graphql/schemas/_edit.twig", "/var/www/html/backend/vendor/craftcms/cms/src/templates/graphql/schemas/_edit.twig");
    }
}

<?php

use Twig\Environment;
use Twig\Error\LoaderError;
use Twig\Error\RuntimeError;
use Twig\Extension\CoreExtension;
use Twig\Extension\SandboxExtension;
use Twig\Markup;
use Twig\Sandbox\SecurityError;
use Twig\Sandbox\SecurityNotAllowedTagError;
use Twig\Sandbox\SecurityNotAllowedFilterError;
use Twig\Sandbox\SecurityNotAllowedFunctionError;
use Twig\Source;
use Twig\Template;
use Twig\TemplateWrapper;

/* _includes/forms/datetime */
class __TwigTemplate_fd868119aba0580098c74102826b2958 extends Template
{
    private Source $source;
    /**
     * @var array<string, Template>
     */
    private array $macros = [];

    public function __construct(Environment $env)
    {
        parent::__construct($env);

        $this->source = $this->getSourceContext();

        $this->parent = false;

        $this->blocks = [
        ];
    }

    protected function doDisplay(array $context, array $blocks = []): iterable
    {
        $macros = $this->macros;
        craft\helpers\Template::beginProfile("template", "_includes/forms/datetime");
        // line 1
        yield "<div class=\"datetimewrapper\">
    ";
        // line 2
        yield from $this->loadTemplate("_includes/forms/date", "_includes/forms/datetime", 2)->unwrap()->yield(CoreExtension::merge($context, ["hasOuterContainer" => true, "isDateTime" => true]));
        // line 6
        yield "    ";
        yield from $this->loadTemplate("_includes/forms/time", "_includes/forms/datetime", 6)->unwrap()->yield(CoreExtension::merge($context, ["hasOuterContainer" => true, "isDateTime" => true, "outputLocaleParam" => false, "outputTzParam" => false]));
        // line 12
        yield "</div>
";
        craft\helpers\Template::endProfile("template", "_includes/forms/datetime");
        yield from [];
    }

    /**
     * @codeCoverageIgnore
     */
    public function getTemplateName(): string
    {
        return "_includes/forms/datetime";
    }

    /**
     * @codeCoverageIgnore
     */
    public function isTraitable(): bool
    {
        return false;
    }

    /**
     * @codeCoverageIgnore
     */
    public function getDebugInfo(): array
    {
        return array (  51 => 12,  48 => 6,  46 => 2,  43 => 1,);
    }

    public function getSourceContext(): Source
    {
        return new Source("<div class=\"datetimewrapper\">
    {% include '_includes/forms/date' with {
        hasOuterContainer: true,
        isDateTime: true,
    } %}
    {% include '_includes/forms/time' with {
        hasOuterContainer: true,
        isDateTime: true,
        outputLocaleParam: false,
        outputTzParam: false,
    } %}
</div>
", "_includes/forms/datetime", "/var/www/html/backend/vendor/craftcms/cms/src/templates/_includes/forms/datetime.twig");
    }
}

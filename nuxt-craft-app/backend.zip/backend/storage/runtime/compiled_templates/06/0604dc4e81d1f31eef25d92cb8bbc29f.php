<?php

use Twig\Environment;
use Twig\Error\LoaderError;
use Twig\Error\RuntimeError;
use Twig\Extension\CoreExtension;
use Twig\Extension\SandboxExtension;
use Twig\Markup;
use Twig\Sandbox\SecurityError;
use Twig\Sandbox\SecurityNotAllowedTagError;
use Twig\Sandbox\SecurityNotAllowedFilterError;
use Twig\Sandbox\SecurityNotAllowedFunctionError;
use Twig\Source;
use Twig\Template;
use Twig\TemplateWrapper;

/* settings/sections/_edit.twig */
class __TwigTemplate_fb7ce96c82e8c6bfb7fd85a692faac70 extends Template
{
    private Source $source;
    /**
     * @var array<string, Template>
     */
    private array $macros = [];

    public function __construct(Environment $env)
    {
        parent::__construct($env);

        $this->source = $this->getSourceContext();

        $this->parent = false;

        $this->blocks = [
        ];
    }

    protected function doDisplay(array $context, array $blocks = []): iterable
    {
        $macros = $this->macros;
        craft\helpers\Template::beginProfile("template", "settings/sections/_edit.twig");
        // line 1
        $context["readOnly"] = (($context["readOnly"]) ?? (false));
        // line 2
        yield "
";
        // line 3
        $macros["forms"] = $this->macros["forms"] = $this->loadTemplate("_includes/forms.twig", "settings/sections/_edit.twig", 3)->unwrap();
        // line 4
        yield "
";
        // line 5
        $context["headlessMode"] = craft\helpers\Template::attribute($this->env, $this->source, craft\helpers\Template::attribute($this->env, $this->source, craft\helpers\Template::attribute($this->env, $this->source, craft\helpers\Template::attribute($this->env, $this->source, (isset($context["craft"]) || array_key_exists("craft", $context) ? $context["craft"] : (function () { throw new RuntimeError('Variable "craft" does not exist.', 5, $this->source); })()), "app", [], "any", false, false, false, 5), "config", [], "any", false, false, false, 5), "general", [], "any", false, false, false, 5), "headlessMode", [], "any", false, false, false, 5);
        // line 6
        yield "
";
        // line 7
        if ( !(isset($context["readOnly"]) || array_key_exists("readOnly", $context) ? $context["readOnly"] : (function () { throw new RuntimeError('Variable "readOnly" does not exist.', 7, $this->source); })())) {
            // line 8
            yield "    ";
            yield craft\helpers\Html::actionInput("sections/save-section");
            yield "
    ";
            // line 9
            yield craft\helpers\Html::redirectInput("settings/sections");
            yield "

    ";
            // line 11
            if (craft\helpers\Template::attribute($this->env, $this->source, (isset($context["section"]) || array_key_exists("section", $context) ? $context["section"] : (function () { throw new RuntimeError('Variable "section" does not exist.', 11, $this->source); })()), "id", [], "any", false, false, false, 11)) {
                yield craft\helpers\Html::hiddenInput("sectionId", craft\helpers\Template::attribute($this->env, $this->source, (isset($context["section"]) || array_key_exists("section", $context) ? $context["section"] : (function () { throw new RuntimeError('Variable "section" does not exist.', 11, $this->source); })()), "id", [], "any", false, false, false, 11));
            }
        }
        // line 13
        yield "
";
        // line 14
        yield $macros["forms"]->getTemplateForMacro("macro_textField", $context, 14, $this->getSourceContext())->macro_textField(...[["first" => true, "label" => $this->extensions['craft\web\twig\Extension']->translateFilter("Name", "app"), "instructions" => $this->extensions['craft\web\twig\Extension']->translateFilter("What this section will be called in the control panel.", "app"), "id" => "name", "name" => "name", "value" => craft\helpers\Template::attribute($this->env, $this->source,         // line 20
(isset($context["section"]) || array_key_exists("section", $context) ? $context["section"] : (function () { throw new RuntimeError('Variable "section" does not exist.', 20, $this->source); })()), "name", [], "any", false, false, false, 20), "errors" => craft\helpers\Template::attribute($this->env, $this->source,         // line 21
(isset($context["section"]) || array_key_exists("section", $context) ? $context["section"] : (function () { throw new RuntimeError('Variable "section" does not exist.', 21, $this->source); })()), "getErrors", ["name"], "method", false, false, false, 21), "data" => ["error-key" => "name"], "autofocus" => true, "required" => true, "disabled" =>         // line 25
(isset($context["readOnly"]) || array_key_exists("readOnly", $context) ? $context["readOnly"] : (function () { throw new RuntimeError('Variable "readOnly" does not exist.', 25, $this->source); })())]]);
        // line 26
        yield "

";
        // line 28
        yield $macros["forms"]->getTemplateForMacro("macro_textField", $context, 28, $this->getSourceContext())->macro_textField(...[["label" => $this->extensions['craft\web\twig\Extension']->translateFilter("Handle", "app"), "instructions" => $this->extensions['craft\web\twig\Extension']->translateFilter("How you’ll refer to this section in the templates.", "app"), "id" => "handle", "name" => "handle", "class" => "code", "autocorrect" => false, "autocapitalize" => false, "value" => craft\helpers\Template::attribute($this->env, $this->source,         // line 36
(isset($context["section"]) || array_key_exists("section", $context) ? $context["section"] : (function () { throw new RuntimeError('Variable "section" does not exist.', 36, $this->source); })()), "handle", [], "any", false, false, false, 36), "errors" => craft\helpers\Template::attribute($this->env, $this->source,         // line 37
(isset($context["section"]) || array_key_exists("section", $context) ? $context["section"] : (function () { throw new RuntimeError('Variable "section" does not exist.', 37, $this->source); })()), "getErrors", ["handle"], "method", false, false, false, 37), "data" => ["error-key" => "handle"], "required" => true, "disabled" =>         // line 40
(isset($context["readOnly"]) || array_key_exists("readOnly", $context) ? $context["readOnly"] : (function () { throw new RuntimeError('Variable "readOnly" does not exist.', 40, $this->source); })())]]);
        // line 41
        yield "

";
        // line 43
        yield $macros["forms"]->getTemplateForMacro("macro_lightswitchField", $context, 43, $this->getSourceContext())->macro_lightswitchField(...[["label" => $this->extensions['craft\web\twig\Extension']->translateFilter("Enable versioning for entries in this section", "app"), "id" => "enableVersioning", "name" => "enableVersioning", "on" => craft\helpers\Template::attribute($this->env, $this->source,         // line 47
(isset($context["section"]) || array_key_exists("section", $context) ? $context["section"] : (function () { throw new RuntimeError('Variable "section" does not exist.', 47, $this->source); })()), "enableVersioning", [], "any", false, false, false, 47), "disabled" =>         // line 48
(isset($context["readOnly"]) || array_key_exists("readOnly", $context) ? $context["readOnly"] : (function () { throw new RuntimeError('Variable "readOnly" does not exist.', 48, $this->source); })())]]);
        // line 49
        yield "

";
        // line 51
        yield $macros["forms"]->getTemplateForMacro("macro_selectField", $context, 51, $this->getSourceContext())->macro_selectField(...[["label" => $this->extensions['craft\web\twig\Extension']->translateFilter("Section Type", "app"), "instructions" => $this->extensions['craft\web\twig\Extension']->translateFilter("What type of section is this?", "app"), "warning" => (((craft\helpers\Template::attribute($this->env, $this->source,         // line 54
(isset($context["section"]) || array_key_exists("section", $context) ? $context["section"] : (function () { throw new RuntimeError('Variable "section" does not exist.', 54, $this->source); })()), "id", [], "any", false, false, false, 54) && (craft\helpers\Template::attribute($this->env, $this->source, (isset($context["section"]) || array_key_exists("section", $context) ? $context["section"] : (function () { throw new RuntimeError('Variable "section" does not exist.', 54, $this->source); })()), "type", [], "any", false, false, false, 54) != "single"))) ? ($this->extensions['craft\web\twig\Extension']->translateFilter("Changing this may result in data loss.", "app")) : ("")), "id" => "type", "name" => "type", "options" =>         // line 57
(isset($context["typeOptions"]) || array_key_exists("typeOptions", $context) ? $context["typeOptions"] : (function () { throw new RuntimeError('Variable "typeOptions" does not exist.', 57, $this->source); })()), "value" => craft\helpers\Template::attribute($this->env, $this->source,         // line 58
(isset($context["section"]) || array_key_exists("section", $context) ? $context["section"] : (function () { throw new RuntimeError('Variable "section" does not exist.', 58, $this->source); })()), "type", [], "any", false, false, false, 58), "toggle" => true, "targetPrefix" => ".type-", "errors" => craft\helpers\Template::attribute($this->env, $this->source,         // line 61
(isset($context["section"]) || array_key_exists("section", $context) ? $context["section"] : (function () { throw new RuntimeError('Variable "section" does not exist.', 61, $this->source); })()), "getErrors", ["type"], "method", false, false, false, 61), "data" => ["error-key" => "type"], "disabled" =>         // line 63
(isset($context["readOnly"]) || array_key_exists("readOnly", $context) ? $context["readOnly"] : (function () { throw new RuntimeError('Variable "readOnly" does not exist.', 63, $this->source); })())]]);
        // line 64
        yield "

<hr>

";
        // line 68
        yield $macros["forms"]->getTemplateForMacro("macro_entryTypeSelectField", $context, 68, $this->getSourceContext())->macro_entryTypeSelectField(...[["label" => $this->extensions['craft\web\twig\Extension']->translateFilter("Entry Types", "app"), "instructions" => $this->extensions['craft\web\twig\Extension']->translateFilter("Choose the types of entries that can be included in this section.", "app"), "id" => "entry-types", "name" => "entryTypes[]", "values" => craft\helpers\Template::attribute($this->env, $this->source,         // line 73
(isset($context["section"]) || array_key_exists("section", $context) ? $context["section"] : (function () { throw new RuntimeError('Variable "section" does not exist.', 73, $this->source); })()), "getEntryTypes", [], "method", false, false, false, 73), "allowOverrides" => true, "errors" => craft\helpers\Template::attribute($this->env, $this->source,         // line 75
(isset($context["section"]) || array_key_exists("section", $context) ? $context["section"] : (function () { throw new RuntimeError('Variable "section" does not exist.', 75, $this->source); })()), "getErrors", ["entryTypes"], "method", false, false, false, 75), "data" => ["error-key" => "entryTypes"], "create" =>  !        // line 77
(isset($context["readOnly"]) || array_key_exists("readOnly", $context) ? $context["readOnly"] : (function () { throw new RuntimeError('Variable "readOnly" does not exist.', 77, $this->source); })()), "disabled" =>         // line 78
(isset($context["readOnly"]) || array_key_exists("readOnly", $context) ? $context["readOnly"] : (function () { throw new RuntimeError('Variable "readOnly" does not exist.', 78, $this->source); })())]]);
        // line 79
        yield "

";
        // line 81
        $context["siteRows"] = [];
        // line 82
        $context["siteErrors"] = craft\helpers\Template::attribute($this->env, $this->source, (isset($context["section"]) || array_key_exists("section", $context) ? $context["section"] : (function () { throw new RuntimeError('Variable "section" does not exist.', 82, $this->source); })()), "getErrors", ["siteSettings"], "method", false, false, false, 82);
        // line 83
        yield "
";
        // line 84
        $context['_parent'] = $context;
        $context['_seq'] = CoreExtension::ensureTraversable(craft\helpers\Template::attribute($this->env, $this->source, craft\helpers\Template::attribute($this->env, $this->source, craft\helpers\Template::attribute($this->env, $this->source, (isset($context["craft"]) || array_key_exists("craft", $context) ? $context["craft"] : (function () { throw new RuntimeError('Variable "craft" does not exist.', 84, $this->source); })()), "app", [], "any", false, false, false, 84), "sites", [], "any", false, false, false, 84), "getAllSites", [], "method", false, false, false, 84));
        $context['loop'] = [
          'parent' => $context['_parent'],
          'index0' => 0,
          'index'  => 1,
          'first'  => true,
        ];
        if (is_array($context['_seq']) || (is_object($context['_seq']) && $context['_seq'] instanceof \Countable)) {
            $length = count($context['_seq']);
            $context['loop']['revindex0'] = $length - 1;
            $context['loop']['revindex'] = $length;
            $context['loop']['length'] = $length;
            $context['loop']['last'] = 1 === $length;
        }
        foreach ($context['_seq'] as $context["_key"] => $context["site"]) {
            // line 85
            yield "    ";
            $context["siteSettings"] = (((craft\helpers\Template::attribute($this->env, $this->source, craft\helpers\Template::attribute($this->env, $this->source, ($context["section"] ?? null), "siteSettings", [], "any", false, true, false, 85), craft\helpers\Template::attribute($this->env, $this->source, $context["site"], "id", [], "any", false, false, false, 85), [], "array", true, true, false, 85) &&  !(null === craft\helpers\Template::attribute($this->env, $this->source, craft\helpers\Template::attribute($this->env, $this->source, ($context["section"] ?? null), "siteSettings", [], "any", false, true, false, 85), craft\helpers\Template::attribute($this->env, $this->source, $context["site"], "id", [], "any", false, false, false, 85), [], "array", false, false, false, 85)))) ? (craft\helpers\Template::attribute($this->env, $this->source, craft\helpers\Template::attribute($this->env, $this->source, ($context["section"] ?? null), "siteSettings", [], "any", false, true, false, 85), craft\helpers\Template::attribute($this->env, $this->source, $context["site"], "id", [], "any", false, false, false, 85), [], "array", false, false, false, 85)) : (null));
            // line 86
            yield "    ";
            if ((isset($context["siteSettings"]) || array_key_exists("siteSettings", $context) ? $context["siteSettings"] : (function () { throw new RuntimeError('Variable "siteSettings" does not exist.', 86, $this->source); })())) {
                // line 87
                yield "        ";
                $context['_parent'] = $context;
                $context['_seq'] = CoreExtension::ensureTraversable(craft\helpers\Template::attribute($this->env, $this->source, (isset($context["siteSettings"]) || array_key_exists("siteSettings", $context) ? $context["siteSettings"] : (function () { throw new RuntimeError('Variable "siteSettings" does not exist.', 87, $this->source); })()), "getErrors", [], "method", false, false, false, 87));
                foreach ($context['_seq'] as $context["attribute"] => $context["errors"]) {
                    // line 88
                    yield "            ";
                    $context["siteErrors"] = $this->extensions['craft\web\twig\Extension']->mergeFilter((isset($context["siteErrors"]) || array_key_exists("siteErrors", $context) ? $context["siteErrors"] : (function () { throw new RuntimeError('Variable "siteErrors" does not exist.', 88, $this->source); })()), $context["errors"]);
                    // line 89
                    yield "        ";
                }
                $_parent = $context['_parent'];
                unset($context['_seq'], $context['attribute'], $context['errors'], $context['_parent']);
                $context = array_intersect_key($context, $_parent) + $_parent;
                // line 90
                yield "    ";
            }
            // line 91
            yield "    ";
            $context["siteRows"] = $this->extensions['craft\web\twig\Extension']->mergeFilter((isset($context["siteRows"]) || array_key_exists("siteRows", $context) ? $context["siteRows"] : (function () { throw new RuntimeError('Variable "siteRows" does not exist.', 91, $this->source); })()), [craft\helpers\Template::attribute($this->env, $this->source,             // line 92
$context["site"], "handle", [], "any", false, false, false, 92) => $this->extensions['craft\web\twig\Extension']->filterFilter($this->env, ["heading" => $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($this->extensions['craft\web\twig\Extension']->translateFilter(craft\helpers\Template::attribute($this->env, $this->source,             // line 93
$context["site"], "name", [], "any", false, false, false, 93), "site")), "enabled" => Twig\Extension\CoreExtension::include($this->env, $context, "_includes/forms/lightswitch.twig", ["name" => (("sites[" . craft\helpers\Template::attribute($this->env, $this->source,             // line 95
$context["site"], "handle", [], "any", false, false, false, 95)) . "][enabled]"), "on" => (            // line 96
(isset($context["brandNewSection"]) || array_key_exists("brandNewSection", $context) ? $context["brandNewSection"] : (function () { throw new RuntimeError('Variable "brandNewSection" does not exist.', 96, $this->source); })()) || (isset($context["siteSettings"]) || array_key_exists("siteSettings", $context) ? $context["siteSettings"] : (function () { throw new RuntimeError('Variable "siteSettings" does not exist.', 96, $this->source); })())), "value" => craft\helpers\Template::attribute($this->env, $this->source,             // line 97
$context["site"], "id", [], "any", false, false, false, 97), "small" => true, "disabled" =>             // line 99
(isset($context["readOnly"]) || array_key_exists("readOnly", $context) ? $context["readOnly"] : (function () { throw new RuntimeError('Variable "readOnly" does not exist.', 99, $this->source); })())]), "singleHomepage" => ["value" => (((craft\helpers\Template::attribute($this->env, $this->source,             // line 102
(isset($context["section"]) || array_key_exists("section", $context) ? $context["section"] : (function () { throw new RuntimeError('Variable "section" does not exist.', 102, $this->source); })()), "type", [], "any", false, false, false, 102) == "single") && (isset($context["siteSettings"]) || array_key_exists("siteSettings", $context) ? $context["siteSettings"] : (function () { throw new RuntimeError('Variable "siteSettings" does not exist.', 102, $this->source); })())) && (craft\helpers\Template::attribute($this->env, $this->source, (isset($context["siteSettings"]) || array_key_exists("siteSettings", $context) ? $context["siteSettings"] : (function () { throw new RuntimeError('Variable "siteSettings" does not exist.', 102, $this->source); })()), "uriFormat", [], "any", false, false, false, 102) == "__home__"))], "singleUri" => ["value" => (((((craft\helpers\Template::attribute($this->env, $this->source,             // line 105
(isset($context["section"]) || array_key_exists("section", $context) ? $context["section"] : (function () { throw new RuntimeError('Variable "section" does not exist.', 105, $this->source); })()), "type", [], "any", false, false, false, 105) == "single") && (isset($context["siteSettings"]) || array_key_exists("siteSettings", $context) ? $context["siteSettings"] : (function () { throw new RuntimeError('Variable "siteSettings" does not exist.', 105, $this->source); })())) && (craft\helpers\Template::attribute($this->env, $this->source, (isset($context["siteSettings"]) || array_key_exists("siteSettings", $context) ? $context["siteSettings"] : (function () { throw new RuntimeError('Variable "siteSettings" does not exist.', 105, $this->source); })()), "uriFormat", [], "any", false, false, false, 105) != "__home__"))) ? (craft\helpers\Template::attribute($this->env, $this->source, (isset($context["siteSettings"]) || array_key_exists("siteSettings", $context) ? $context["siteSettings"] : (function () { throw new RuntimeError('Variable "siteSettings" does not exist.', 105, $this->source); })()), "uriFormat", [], "any", false, false, false, 105)) : ("")), "hasErrors" => ((((craft\helpers\Template::attribute($this->env, $this->source,             // line 106
(isset($context["section"]) || array_key_exists("section", $context) ? $context["section"] : (function () { throw new RuntimeError('Variable "section" does not exist.', 106, $this->source); })()), "type", [], "any", false, false, false, 106) == "single") && (isset($context["siteSettings"]) || array_key_exists("siteSettings", $context) ? $context["siteSettings"] : (function () { throw new RuntimeError('Variable "siteSettings" does not exist.', 106, $this->source); })()))) ? (craft\helpers\Template::attribute($this->env, $this->source, (isset($context["siteSettings"]) || array_key_exists("siteSettings", $context) ? $context["siteSettings"] : (function () { throw new RuntimeError('Variable "siteSettings" does not exist.', 106, $this->source); })()), "hasErrors", ["uriFormat"], "method", false, false, false, 106)) : (""))], "uriFormat" => ["value" => ((            // line 109
(isset($context["siteSettings"]) || array_key_exists("siteSettings", $context) ? $context["siteSettings"] : (function () { throw new RuntimeError('Variable "siteSettings" does not exist.', 109, $this->source); })())) ? (craft\helpers\Template::attribute($this->env, $this->source, (isset($context["siteSettings"]) || array_key_exists("siteSettings", $context) ? $context["siteSettings"] : (function () { throw new RuntimeError('Variable "siteSettings" does not exist.', 109, $this->source); })()), "uriFormat", [], "any", false, false, false, 109)) : ("")), "hasErrors" => ((((craft\helpers\Template::attribute($this->env, $this->source,             // line 110
(isset($context["section"]) || array_key_exists("section", $context) ? $context["section"] : (function () { throw new RuntimeError('Variable "section" does not exist.', 110, $this->source); })()), "type", [], "any", false, false, false, 110) != "single") && (isset($context["siteSettings"]) || array_key_exists("siteSettings", $context) ? $context["siteSettings"] : (function () { throw new RuntimeError('Variable "siteSettings" does not exist.', 110, $this->source); })()))) ? (craft\helpers\Template::attribute($this->env, $this->source, (isset($context["siteSettings"]) || array_key_exists("siteSettings", $context) ? $context["siteSettings"] : (function () { throw new RuntimeError('Variable "siteSettings" does not exist.', 110, $this->source); })()), "hasErrors", ["uriFormat"], "method", false, false, false, 110)) : (""))], "template" => (( !            // line 112
(isset($context["headlessMode"]) || array_key_exists("headlessMode", $context) ? $context["headlessMode"] : (function () { throw new RuntimeError('Variable "headlessMode" does not exist.', 112, $this->source); })())) ? (["value" => ((            // line 113
(isset($context["siteSettings"]) || array_key_exists("siteSettings", $context) ? $context["siteSettings"] : (function () { throw new RuntimeError('Variable "siteSettings" does not exist.', 113, $this->source); })())) ? (craft\helpers\Template::attribute($this->env, $this->source, (isset($context["siteSettings"]) || array_key_exists("siteSettings", $context) ? $context["siteSettings"] : (function () { throw new RuntimeError('Variable "siteSettings" does not exist.', 113, $this->source); })()), "template", [], "any", false, false, false, 113)) : ("")), "hasErrors" => ((            // line 114
(isset($context["siteSettings"]) || array_key_exists("siteSettings", $context) ? $context["siteSettings"] : (function () { throw new RuntimeError('Variable "siteSettings" does not exist.', 114, $this->source); })())) ? (craft\helpers\Template::attribute($this->env, $this->source, (isset($context["siteSettings"]) || array_key_exists("siteSettings", $context) ? $context["siteSettings"] : (function () { throw new RuntimeError('Variable "siteSettings" does not exist.', 114, $this->source); })()), "hasErrors", ["template"], "method", false, false, false, 114)) : (""))]) : ("")), "enabledByDefault" => ((            // line 116
(isset($context["siteSettings"]) || array_key_exists("siteSettings", $context) ? $context["siteSettings"] : (function () { throw new RuntimeError('Variable "siteSettings" does not exist.', 116, $this->source); })())) ? (craft\helpers\Template::attribute($this->env, $this->source, (isset($context["siteSettings"]) || array_key_exists("siteSettings", $context) ? $context["siteSettings"] : (function () { throw new RuntimeError('Variable "siteSettings" does not exist.', 116, $this->source); })()), "enabledByDefault", [], "any", false, false, false, 116)) : (true))])]);
            ++$context['loop']['index0'];
            ++$context['loop']['index'];
            $context['loop']['first'] = false;
            if (isset($context['loop']['revindex0'], $context['loop']['revindex'])) {
                --$context['loop']['revindex0'];
                --$context['loop']['revindex'];
                $context['loop']['last'] = 0 === $context['loop']['revindex0'];
            }
        }
        $_parent = $context['_parent'];
        unset($context['_seq'], $context['_key'], $context['site'], $context['_parent'], $context['loop']);
        $context = array_intersect_key($context, $_parent) + $_parent;
        // line 120
        yield "
";
        // line 121
        yield $macros["forms"]->getTemplateForMacro("macro_editableTableField", $context, 121, $this->getSourceContext())->macro_editableTableField(...[["label" => $this->extensions['craft\web\twig\Extension']->translateFilter("Site Settings", "app"), "instructions" => $this->extensions['craft\web\twig\Extension']->translateFilter("Choose which sites this section should be available in, and configure the site-specific settings.", "app"), "id" => "sites", "name" => "sites", "cols" => $this->extensions['craft\web\twig\Extension']->filterFilter($this->env, ["heading" => ["type" => "heading", "heading" => $this->extensions['craft\web\twig\Extension']->translateFilter("Site", "app"), "thin" => true], "enabled" => ["type" => "heading", "thin" => true, "class" => (( !craft\helpers\Template::attribute($this->env, $this->source, craft\helpers\Template::attribute($this->env, $this->source,         // line 135
(isset($context["craft"]) || array_key_exists("craft", $context) ? $context["craft"] : (function () { throw new RuntimeError('Variable "craft" does not exist.', 135, $this->source); })()), "app", [], "any", false, false, false, 135), "getIsMultiSite", [], "method", false, false, false, 135)) ? ("hidden") : (""))], "singleHomepage" => ["type" => "checkbox", "headingHtml" => $this->extensions['craft\web\twig\Extension']->tagFunction("div", ["data" => ["icon" => "home"], "title" => $this->extensions['craft\web\twig\Extension']->translateFilter("Homepage", "app")]), "thin" => true, "class" => $this->extensions['craft\web\twig\Extension']->filterFilter($this->env, ["single-homepage", "type-single", (((craft\helpers\Template::attribute($this->env, $this->source,         // line 144
(isset($context["section"]) || array_key_exists("section", $context) ? $context["section"] : (function () { throw new RuntimeError('Variable "section" does not exist.', 144, $this->source); })()), "type", [], "any", false, false, false, 144) != "single")) ? ("hidden") : (""))])], "singleUri" => ["type" => "singleline", "heading" => $this->extensions['craft\web\twig\Extension']->translateFilter("URI", "app"), "info" => $this->extensions['craft\web\twig\Extension']->translateFilter("What the entry URI should be for the site. Leave blank if the entry doesn’t have a URL.", "app"), "placeholder" => $this->extensions['craft\web\twig\Extension']->translateFilter("Leave blank if the entry doesn’t have a URL", "app"), "code" => true, "width" => ((        // line 152
(isset($context["headlessMode"]) || array_key_exists("headlessMode", $context) ? $context["headlessMode"] : (function () { throw new RuntimeError('Variable "headlessMode" does not exist.', 152, $this->source); })())) ? (500) : ("")), "class" => $this->extensions['craft\web\twig\Extension']->filterFilter($this->env, ["single-uri", "type-single", (((craft\helpers\Template::attribute($this->env, $this->source,         // line 153
(isset($context["section"]) || array_key_exists("section", $context) ? $context["section"] : (function () { throw new RuntimeError('Variable "section" does not exist.', 153, $this->source); })()), "type", [], "any", false, false, false, 153) != "single")) ? ("hidden") : (""))])], "uriFormat" => ["type" => "singleline", "heading" => $this->extensions['craft\web\twig\Extension']->translateFilter("Entry URI Format", "app"), "info" => $this->extensions['craft\web\twig\Extension']->translateFilter("What entry URIs should look like for the site. Leave blank if entries don’t have URLs.", "app"), "placeholder" => $this->extensions['craft\web\twig\Extension']->translateFilter("Leave blank if entries don’t have URLs", "app"), "code" => true, "width" => ((        // line 161
(isset($context["headlessMode"]) || array_key_exists("headlessMode", $context) ? $context["headlessMode"] : (function () { throw new RuntimeError('Variable "headlessMode" does not exist.', 161, $this->source); })())) ? (500) : ("")), "class" => $this->extensions['craft\web\twig\Extension']->filterFilter($this->env, ["type-channel", "type-structure", (((craft\helpers\Template::attribute($this->env, $this->source,         // line 162
(isset($context["section"]) || array_key_exists("section", $context) ? $context["section"] : (function () { throw new RuntimeError('Variable "section" does not exist.', 162, $this->source); })()), "type", [], "any", false, false, false, 162) == "single")) ? (" hidden") : (""))])], "template" => (( !        // line 164
(isset($context["headlessMode"]) || array_key_exists("headlessMode", $context) ? $context["headlessMode"] : (function () { throw new RuntimeError('Variable "headlessMode" does not exist.', 164, $this->source); })())) ? (["type" => "template", "heading" => $this->extensions['craft\web\twig\Extension']->translateFilter("Template", "app"), "info" => $this->extensions['craft\web\twig\Extension']->translateFilter("Which template should be loaded when an entry’s URL is requested.", "app"), "code" => true]) : ("")), "enabledByDefault" => ["type" => "lightswitch", "heading" => $this->extensions['craft\web\twig\Extension']->translateFilter("Default Status", "app"), "thin" => true, "class" => $this->extensions['craft\web\twig\Extension']->filterFilter($this->env, ["type-channel", "type-structure", (((craft\helpers\Template::attribute($this->env, $this->source,         // line 174
(isset($context["section"]) || array_key_exists("section", $context) ? $context["section"] : (function () { throw new RuntimeError('Variable "section" does not exist.', 174, $this->source); })()), "type", [], "any", false, false, false, 174) == "single")) ? (" hidden") : (""))])]]), "rows" =>         // line 177
(isset($context["siteRows"]) || array_key_exists("siteRows", $context) ? $context["siteRows"] : (function () { throw new RuntimeError('Variable "siteRows" does not exist.', 177, $this->source); })()), "fullWidth" => true, "allowAdd" => false, "allowDelete" => false, "allowReorder" => false, "errors" => array_unique(        // line 182
(isset($context["siteErrors"]) || array_key_exists("siteErrors", $context) ? $context["siteErrors"] : (function () { throw new RuntimeError('Variable "siteErrors" does not exist.', 182, $this->source); })())), "data" => ["error-key" => "siteSettings"], "static" =>         // line 184
(isset($context["readOnly"]) || array_key_exists("readOnly", $context) ? $context["readOnly"] : (function () { throw new RuntimeError('Variable "readOnly" does not exist.', 184, $this->source); })())]]);
        // line 185
        yield "

";
        // line 187
        if (craft\helpers\Template::attribute($this->env, $this->source, craft\helpers\Template::attribute($this->env, $this->source, (isset($context["craft"]) || array_key_exists("craft", $context) ? $context["craft"] : (function () { throw new RuntimeError('Variable "craft" does not exist.', 187, $this->source); })()), "app", [], "any", false, false, false, 187), "getIsMultiSite", [], "method", false, false, false, 187)) {
            // line 188
            yield "    <div class=\"field type-channel type-structure ";
            if ((craft\helpers\Template::attribute($this->env, $this->source, (isset($context["section"]) || array_key_exists("section", $context) ? $context["section"] : (function () { throw new RuntimeError('Variable "section" does not exist.', 188, $this->source); })()), "type", [], "any", false, false, false, 188) == "single")) {
                yield "hidden";
            }
            yield "\">
        ";
            // line 189
            yield $macros["forms"]->getTemplateForMacro("macro_selectField", $context, 189, $this->getSourceContext())->macro_selectField(...[["label" => $this->extensions['craft\web\twig\Extension']->translateFilter("Propagation Method", "app"), "instructions" => $this->extensions['craft\web\twig\Extension']->translateFilter("Of the enabled sites above, which sites should entries in this section be saved to?", "app"), "warning" => ((((craft\helpers\Template::attribute($this->env, $this->source,             // line 192
(isset($context["section"]) || array_key_exists("section", $context) ? $context["section"] : (function () { throw new RuntimeError('Variable "section" does not exist.', 192, $this->source); })()), "id", [], "any", false, false, false, 192) && (craft\helpers\Template::attribute($this->env, $this->source, craft\helpers\Template::attribute($this->env, $this->source, (isset($context["section"]) || array_key_exists("section", $context) ? $context["section"] : (function () { throw new RuntimeError('Variable "section" does not exist.', 192, $this->source); })()), "propagationMethod", [], "any", false, false, false, 192), "value", [], "any", false, false, false, 192) != "none")) && ($this->extensions['craft\web\twig\Extension']->lengthFilter($this->env, craft\helpers\Template::attribute($this->env, $this->source, (isset($context["section"]) || array_key_exists("section", $context) ? $context["section"] : (function () { throw new RuntimeError('Variable "section" does not exist.', 192, $this->source); })()), "siteSettings", [], "any", false, false, false, 192)) > 1))) ? ($this->extensions['craft\web\twig\Extension']->translateFilter("Changing this may result in data loss.", "app")) : ("")), "id" => "propagationMethod", "name" => "propagationMethod", "options" => [["value" => "none", "label" => $this->extensions['craft\web\twig\Extension']->translateFilter("Only save entries to the site they were created in", "app")], ["value" => "siteGroup", "label" => $this->extensions['craft\web\twig\Extension']->translateFilter("Save entries to other sites in the same site group", "app")], ["value" => "language", "label" => $this->extensions['craft\web\twig\Extension']->translateFilter("Save entries to other sites with the same language", "app")], ["value" => "all", "label" => $this->extensions['craft\web\twig\Extension']->translateFilter("Save entries to all sites enabled for this section", "app")], ["value" => "custom", "label" => $this->extensions['craft\web\twig\Extension']->translateFilter("Let each entry choose which sites it should be saved to", "app")]], "value" => craft\helpers\Template::attribute($this->env, $this->source, craft\helpers\Template::attribute($this->env, $this->source,             // line 202
(isset($context["section"]) || array_key_exists("section", $context) ? $context["section"] : (function () { throw new RuntimeError('Variable "section" does not exist.', 202, $this->source); })()), "propagationMethod", [], "any", false, false, false, 202), "value", [], "any", false, false, false, 202), "disabled" =>             // line 203
(isset($context["readOnly"]) || array_key_exists("readOnly", $context) ? $context["readOnly"] : (function () { throw new RuntimeError('Variable "readOnly" does not exist.', 203, $this->source); })())]]);
            // line 204
            yield "
    </div>
";
        }
        // line 207
        yield "
<div class=\"field type-structure ";
        // line 208
        if ((craft\helpers\Template::attribute($this->env, $this->source, (isset($context["section"]) || array_key_exists("section", $context) ? $context["section"] : (function () { throw new RuntimeError('Variable "section" does not exist.', 208, $this->source); })()), "type", [], "any", false, false, false, 208) != "structure")) {
            yield "hidden";
        }
        yield "\">
    ";
        // line 209
        yield $macros["forms"]->getTemplateForMacro("macro_textField", $context, 209, $this->getSourceContext())->macro_textField(...[["label" => $this->extensions['craft\web\twig\Extension']->translateFilter("Max Levels", "app"), "instructions" => $this->extensions['craft\web\twig\Extension']->translateFilter("The maximum number of levels this section can have.", "app"), "id" => "maxLevels", "name" => "maxLevels", "value" => craft\helpers\Template::attribute($this->env, $this->source,         // line 214
(isset($context["section"]) || array_key_exists("section", $context) ? $context["section"] : (function () { throw new RuntimeError('Variable "section" does not exist.', 214, $this->source); })()), "maxLevels", [], "any", false, false, false, 214), "size" => 5, "errors" => craft\helpers\Template::attribute($this->env, $this->source,         // line 216
(isset($context["section"]) || array_key_exists("section", $context) ? $context["section"] : (function () { throw new RuntimeError('Variable "section" does not exist.', 216, $this->source); })()), "getErrors", ["maxLevels"], "method", false, false, false, 216), "data" => ["error-key" => "maxLevels"], "disabled" =>         // line 218
(isset($context["readOnly"]) || array_key_exists("readOnly", $context) ? $context["readOnly"] : (function () { throw new RuntimeError('Variable "readOnly" does not exist.', 218, $this->source); })())]]);
        // line 219
        yield "

    ";
        // line 221
        yield $macros["forms"]->getTemplateForMacro("macro_selectField", $context, 221, $this->getSourceContext())->macro_selectField(...[["label" => $this->extensions['craft\web\twig\Extension']->translateFilter("Default {type} Placement", "app", ["type" => $this->extensions['craft\web\twig\Extension']->translateFilter("Entry", "app")]), "instructions" => $this->extensions['craft\web\twig\Extension']->translateFilter("Where new {type} should be placed by default in the structure.", "app", ["type" => $this->extensions['craft\web\twig\Extension']->translateFilter("entries", "app")]), "id" => "default-placement", "name" => "defaultPlacement", "options" => [["label" => $this->extensions['craft\web\twig\Extension']->translateFilter("Before other {type}", "app", ["type" => $this->extensions['craft\web\twig\Extension']->translateFilter("entries", "app")]), "value" => "beginning"], ["label" => $this->extensions['craft\web\twig\Extension']->translateFilter("After other {type}", "app", ["type" => $this->extensions['craft\web\twig\Extension']->translateFilter("entries", "app")]), "value" => "end"]], "value" => craft\helpers\Template::attribute($this->env, $this->source,         // line 230
(isset($context["section"]) || array_key_exists("section", $context) ? $context["section"] : (function () { throw new RuntimeError('Variable "section" does not exist.', 230, $this->source); })()), "defaultPlacement", [], "any", false, false, false, 230), "disabled" =>         // line 231
(isset($context["readOnly"]) || array_key_exists("readOnly", $context) ? $context["readOnly"] : (function () { throw new RuntimeError('Variable "readOnly" does not exist.', 231, $this->source); })())]]);
        // line 232
        yield "
</div>

";
        // line 235
        yield $macros["forms"]->getTemplateForMacro("macro_editableTableField", $context, 235, $this->getSourceContext())->macro_editableTableField(...[["label" => $this->extensions['craft\web\twig\Extension']->translateFilter("Preview Targets", "app"), "instructions" => $this->extensions['craft\web\twig\Extension']->translateFilter("Locations that should be available for previewing entries in this section.", "app"), "id" => "previewTargets", "name" => "previewTargets", "cols" => ["label" => ["type" => "singleline", "heading" => $this->extensions['craft\web\twig\Extension']->translateFilter("Label", "app")], "urlFormat" => ["type" => "singleline", "heading" => $this->extensions['craft\web\twig\Extension']->translateFilter("URL Format", "app"), "info" => $this->extensions['craft\web\twig\Extension']->translateFilter("The URL/URI to use for this target.", "app"), "code" => true], "refresh" => ["type" => "checkbox", "heading" => $this->extensions['craft\web\twig\Extension']->translateFilter("Auto-refresh", "app"), "info" => $this->extensions['craft\web\twig\Extension']->translateFilter("Whether preview frames should be automatically refreshed when content changes.", "app"), "thin" => true]], "defaultValues" => ["refresh" => true], "allowAdd" => true, "allowReorder" => true, "allowDelete" => true, "rows" => craft\helpers\Template::attribute($this->env, $this->source,         // line 264
(isset($context["section"]) || array_key_exists("section", $context) ? $context["section"] : (function () { throw new RuntimeError('Variable "section" does not exist.', 264, $this->source); })()), "previewTargets", [], "any", false, false, false, 264), "errors" => craft\helpers\Template::attribute($this->env, $this->source,         // line 265
(isset($context["section"]) || array_key_exists("section", $context) ? $context["section"] : (function () { throw new RuntimeError('Variable "section" does not exist.', 265, $this->source); })()), "getErrors", ["previewTargets"], "method", false, false, false, 265), "data" => ["error-key" => "previewTargets"], "static" =>         // line 267
(isset($context["readOnly"]) || array_key_exists("readOnly", $context) ? $context["readOnly"] : (function () { throw new RuntimeError('Variable "readOnly" does not exist.', 267, $this->source); })())]]);
        // line 268
        yield "

";
        // line 270
        yield $macros["forms"]->getTemplateForMacro("macro_textField", $context, 270, $this->getSourceContext())->macro_textField(...[["label" => $this->extensions['craft\web\twig\Extension']->translateFilter("Max Authors", "app"), "instructions" => $this->extensions['craft\web\twig\Extension']->translateFilter("The maximum number of authors that entries in this section can have.", "app"), "id" => "maxAuthors", "name" => "maxAuthors", "autocorrect" => false, "autocapitalize" => false, "default" => 1, "value" => craft\helpers\Template::attribute($this->env, $this->source,         // line 278
(isset($context["section"]) || array_key_exists("section", $context) ? $context["section"] : (function () { throw new RuntimeError('Variable "section" does not exist.', 278, $this->source); })()), "maxAuthors", [], "any", false, false, false, 278), "errors" => craft\helpers\Template::attribute($this->env, $this->source,         // line 279
(isset($context["section"]) || array_key_exists("section", $context) ? $context["section"] : (function () { throw new RuntimeError('Variable "section" does not exist.', 279, $this->source); })()), "getErrors", ["maxAuthors"], "method", false, false, false, 279), "data" => ["error-key" => "maxAuthors"], "size" => 5, "disabled" =>         // line 282
(isset($context["readOnly"]) || array_key_exists("readOnly", $context) ? $context["readOnly"] : (function () { throw new RuntimeError('Variable "readOnly" does not exist.', 282, $this->source); })())]]);
        // line 283
        yield "

";
        // line 285
        if ((isset($context["brandNewSection"]) || array_key_exists("brandNewSection", $context) ? $context["brandNewSection"] : (function () { throw new RuntimeError('Variable "brandNewSection" does not exist.', 285, $this->source); })())) {
            // line 286
            yield "    ";
            ob_start();
            // line 287
            yield "        new Craft.HandleGenerator('#name', '#handle');

        ";
            // line 289
            $context['_parent'] = $context;
            $context['_seq'] = CoreExtension::ensureTraversable(craft\helpers\Template::attribute($this->env, $this->source, craft\helpers\Template::attribute($this->env, $this->source, craft\helpers\Template::attribute($this->env, $this->source, (isset($context["craft"]) || array_key_exists("craft", $context) ? $context["craft"] : (function () { throw new RuntimeError('Variable "craft" does not exist.', 289, $this->source); })()), "app", [], "any", false, false, false, 289), "sites", [], "any", false, false, false, 289), "getAllSites", [], "method", false, false, false, 289));
            foreach ($context['_seq'] as $context["_key"] => $context["site"]) {
                // line 290
                yield "            new Craft.UriFormatGenerator(
                '#name',
                '#sites tr[data-id=\"";
                // line 292
                yield $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape(craft\helpers\Template::attribute($this->env, $this->source, $context["site"], "handle", [], "any", false, false, false, 292), "html", null, true);
                yield "\"] textarea[name\$=\"[singleUri]\"]',
                { updateWhenHidden: true }
            );
            new Craft.UriFormatGenerator(
                '#name',
                '#sites tr[data-id=\"";
                // line 297
                yield $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape(craft\helpers\Template::attribute($this->env, $this->source, $context["site"], "handle", [], "any", false, false, false, 297), "html", null, true);
                yield "\"] textarea[name\$=\"[uriFormat]\"]',
                { suffix: '/{slug}', updateWhenHidden: true }
            );
            new Craft.UriFormatGenerator(
                '#name',
                '#sites tr[data-id=\"";
                // line 302
                yield $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape(craft\helpers\Template::attribute($this->env, $this->source, $context["site"], "handle", [], "any", false, false, false, 302), "html", null, true);
                yield "\"] input[name\$=\"[template]\"]',
                { suffix: '/_entry.twig', updateWhenHidden: true }
            );
        ";
            }
            $_parent = $context['_parent'];
            unset($context['_seq'], $context['_key'], $context['site'], $context['_parent']);
            $context = array_intersect_key($context, $_parent) + $_parent;
            // line 306
            yield "    ";
            craft\helpers\Template::js(ob_get_clean(), ['position' => 4]);
        }
        craft\helpers\Template::endProfile("template", "settings/sections/_edit.twig");
        yield from [];
    }

    /**
     * @codeCoverageIgnore
     */
    public function getTemplateName(): string
    {
        return "settings/sections/_edit.twig";
    }

    /**
     * @codeCoverageIgnore
     */
    public function isTraitable(): bool
    {
        return false;
    }

    /**
     * @codeCoverageIgnore
     */
    public function getDebugInfo(): array
    {
        return array (  331 => 306,  321 => 302,  313 => 297,  305 => 292,  301 => 290,  297 => 289,  293 => 287,  290 => 286,  288 => 285,  284 => 283,  282 => 282,  281 => 279,  280 => 278,  279 => 270,  275 => 268,  273 => 267,  272 => 265,  271 => 264,  270 => 235,  265 => 232,  263 => 231,  262 => 230,  261 => 221,  257 => 219,  255 => 218,  254 => 216,  253 => 214,  252 => 209,  246 => 208,  243 => 207,  238 => 204,  236 => 203,  235 => 202,  234 => 192,  233 => 189,  226 => 188,  224 => 187,  220 => 185,  218 => 184,  217 => 182,  216 => 177,  215 => 174,  214 => 164,  213 => 162,  212 => 161,  211 => 153,  210 => 152,  209 => 144,  208 => 135,  207 => 121,  204 => 120,  190 => 116,  189 => 114,  188 => 113,  187 => 112,  186 => 110,  185 => 109,  184 => 106,  183 => 105,  182 => 102,  181 => 99,  180 => 97,  179 => 96,  178 => 95,  177 => 93,  176 => 92,  174 => 91,  171 => 90,  165 => 89,  162 => 88,  157 => 87,  154 => 86,  151 => 85,  134 => 84,  131 => 83,  129 => 82,  127 => 81,  123 => 79,  121 => 78,  120 => 77,  119 => 75,  118 => 73,  117 => 68,  111 => 64,  109 => 63,  108 => 61,  107 => 58,  106 => 57,  105 => 54,  104 => 51,  100 => 49,  98 => 48,  97 => 47,  96 => 43,  92 => 41,  90 => 40,  89 => 37,  88 => 36,  87 => 28,  83 => 26,  81 => 25,  80 => 21,  79 => 20,  78 => 14,  75 => 13,  70 => 11,  65 => 9,  60 => 8,  58 => 7,  55 => 6,  53 => 5,  50 => 4,  48 => 3,  45 => 2,  43 => 1,);
    }

    public function getSourceContext(): Source
    {
        return new Source("{% set readOnly = readOnly ?? false %}

{% import '_includes/forms.twig' as forms %}

{% set headlessMode = craft.app.config.general.headlessMode %}

{% if not readOnly %}
    {{ actionInput('sections/save-section') }}
    {{ redirectInput('settings/sections') }}

    {% if section.id %}{{ hiddenInput('sectionId', section.id) }}{% endif %}
{% endif %}

{{ forms.textField({
    first: true,
    label: \"Name\"|t('app'),
    instructions: \"What this section will be called in the control panel.\"|t('app'),
    id: 'name',
    name: 'name',
    value: section.name,
    errors: section.getErrors('name'),
    data: {'error-key': 'name'},
    autofocus: true,
    required: true,
    disabled: readOnly,
}) }}

{{ forms.textField({
    label: \"Handle\"|t('app'),
    instructions: \"How you’ll refer to this section in the templates.\"|t('app'),
    id: 'handle',
    name: 'handle',
    class: 'code',
    autocorrect: false,
    autocapitalize: false,
    value: section.handle,
    errors: section.getErrors('handle'),
    data: {'error-key': 'handle'},
    required: true,
    disabled: readOnly,
}) }}

{{ forms.lightswitchField({
    label: 'Enable versioning for entries in this section'|t('app'),
    id: 'enableVersioning',
    name: 'enableVersioning',
    on: section.enableVersioning,
    disabled: readOnly,
}) }}

{{ forms.selectField({
    label: \"Section Type\"|t('app'),
    instructions: \"What type of section is this?\"|t('app'),
    warning: section.id and section.type != 'single' ? 'Changing this may result in data loss.'|t('app'),
    id: 'type',
    name: 'type',
    options: typeOptions,
    value: section.type,
    toggle: true,
    targetPrefix: '.type-',
    errors: section.getErrors('type'),
    data: {'error-key': 'type'},
    disabled: readOnly,
}) }}

<hr>

{{ forms.entryTypeSelectField({
    label: 'Entry Types'|t('app'),
    instructions: 'Choose the types of entries that can be included in this section.'|t('app'),
    id: 'entry-types',
    name: 'entryTypes[]',
    values: section.getEntryTypes(),
    allowOverrides: true,
    errors: section.getErrors('entryTypes'),
    data: {'error-key': 'entryTypes'},
    create: not readOnly,
    disabled: readOnly,
}) }}

{% set siteRows = [] %}
{% set siteErrors = section.getErrors('siteSettings') %}

{% for site in craft.app.sites.getAllSites() %}
    {% set siteSettings = section.siteSettings[site.id] ?? null %}
    {% if siteSettings %}
        {% for attribute, errors in siteSettings.getErrors() %}
            {% set siteErrors = siteErrors|merge(errors) %}
        {% endfor %}
    {% endif %}
    {% set siteRows = siteRows|merge({
        (site.handle): {
            heading: site.name|t('site')|e,
            enabled: include('_includes/forms/lightswitch.twig', {
                name: 'sites['~site.handle~'][enabled]',
                on: brandNewSection or siteSettings,
                value: site.id,
                small: true,
                disabled: readOnly,
            }),
            singleHomepage: {
                value: (section.type == 'single' and siteSettings and siteSettings.uriFormat == '__home__'),
            },
            singleUri: {
                value: (section.type == 'single' and siteSettings and siteSettings.uriFormat != '__home__') ? siteSettings.uriFormat,
                hasErrors: (section.type == 'single' and siteSettings ? siteSettings.hasErrors('uriFormat')),
            },
            uriFormat: {
                value: siteSettings ? siteSettings.uriFormat,
                hasErrors: (section.type != 'single' and siteSettings ? siteSettings.hasErrors('uriFormat')),
            },
            template: not headlessMode ? {
                value: siteSettings ? siteSettings.template,
                hasErrors: siteSettings ? siteSettings.hasErrors('template'),
            },
            enabledByDefault: siteSettings ? siteSettings.enabledByDefault : true,
        }|filter
    }) %}
{% endfor %}

{{ forms.editableTableField({
    label: \"Site Settings\"|t('app'),
    instructions: \"Choose which sites this section should be available in, and configure the site-specific settings.\"|t('app'),
    id: 'sites',
    name: 'sites',
    cols: {
        heading: {
            type: 'heading',
            heading: \"Site\"|t('app'),
            thin: true
        },
        enabled: {
            type: 'heading',
            thin: true,
            class: not craft.app.getIsMultiSite() ? 'hidden'
        },
        singleHomepage: {
            type: 'checkbox',
            headingHtml: tag('div', {
                data: {icon: 'home'},
                title: 'Homepage'|t('app')
            }),
            thin: true,
            class: ['single-homepage', 'type-single', section.type != 'single' ? 'hidden']|filter
        },
        singleUri: {
            type: 'singleline',
            heading: \"URI\"|t('app'),
            info: \"What the entry URI should be for the site. Leave blank if the entry doesn’t have a URL.\"|t('app'),
            placeholder: 'Leave blank if the entry doesn’t have a URL'|t('app'),
            code: true,
            width: headlessMode ? 500,
            class: ['single-uri', 'type-single', section.type != 'single' ? 'hidden']|filter
        },
        uriFormat: {
            type: 'singleline',
            heading: \"Entry URI Format\"|t('app'),
            info: \"What entry URIs should look like for the site. Leave blank if entries don’t have URLs.\"|t('app'),
            placeholder: 'Leave blank if entries don’t have URLs'|t('app'),
            code: true,
            width: headlessMode ? 500,
            class: ['type-channel', 'type-structure', section.type == 'single' ? ' hidden']|filter
        },
        template: not headlessMode ? {
            type: 'template',
            heading: \"Template\"|t('app'),
            info: \"Which template should be loaded when an entry’s URL is requested.\"|t('app'),
            code: true
        },
        enabledByDefault: {
            type: 'lightswitch',
            heading: \"Default Status\"|t('app'),
            thin: true,
            class: ['type-channel', 'type-structure', section.type == 'single' ? ' hidden']|filter
        }
    }|filter,
    rows: siteRows,
    fullWidth: true,
    allowAdd: false,
    allowDelete: false,
    allowReorder: false,
    errors: siteErrors|unique,
    data: {'error-key': 'siteSettings'},
    static: readOnly,
}) }}

{% if craft.app.getIsMultiSite() %}
    <div class=\"field type-channel type-structure {% if section.type == 'single' %}hidden{% endif %}\">
        {{ forms.selectField({
            label: 'Propagation Method'|t('app'),
            instructions: 'Of the enabled sites above, which sites should entries in this section be saved to?'|t('app'),
            warning: section.id and section.propagationMethod.value != 'none' and section.siteSettings|length > 1 ? 'Changing this may result in data loss.'|t('app'),
            id: 'propagationMethod',
            name: 'propagationMethod',
            options: [
                { value: 'none', label: 'Only save entries to the site they were created in'|t('app') },
                { value: 'siteGroup', label: 'Save entries to other sites in the same site group'|t('app') },
                { value: 'language', label: 'Save entries to other sites with the same language'|t('app') },
                { value: 'all', label: 'Save entries to all sites enabled for this section'|t('app') },
                { value: 'custom', label: 'Let each entry choose which sites it should be saved to'|t('app') },
            ],
            value: section.propagationMethod.value,
            disabled: readOnly,
        }) }}
    </div>
{% endif %}

<div class=\"field type-structure {% if section.type != 'structure' %}hidden{% endif %}\">
    {{ forms.textField({
        label: \"Max Levels\"|t('app'),
        instructions: 'The maximum number of levels this section can have.'|t('app'),
        id: 'maxLevels',
        name: 'maxLevels',
        value: section.maxLevels,
        size: 5,
        errors: section.getErrors('maxLevels'),
        data: {'error-key': 'maxLevels'},
        disabled: readOnly,
    }) }}

    {{ forms.selectField({
        label: 'Default {type} Placement'|t('app', {type: 'Entry'|t('app')}),
        instructions: 'Where new {type} should be placed by default in the structure.'|t('app', {type: 'entries'|t('app')}),
        id: 'default-placement',
        name: 'defaultPlacement',
        options: [
            {label: 'Before other {type}'|t('app', {type: 'entries'|t('app')}), value: 'beginning'},
            {label: 'After other {type}'|t('app', {type: 'entries'|t('app')}), value: 'end'},
        ],
        value: section.defaultPlacement,
        disabled: readOnly,
    }) }}
</div>

{{ forms.editableTableField({
    label: 'Preview Targets'|t('app'),
    instructions: 'Locations that should be available for previewing entries in this section.'|t('app'),
    id: 'previewTargets',
    name: 'previewTargets',
    cols: {
        label: {
            type: 'singleline',
            heading: 'Label'|t('app'),
        },
        urlFormat: {
            type: 'singleline',
            heading: 'URL Format'|t('app'),
            info: 'The URL/URI to use for this target.'|t('app'),
            code: true,
        },
        refresh: {
            type: 'checkbox',
            heading: 'Auto-refresh'|t('app'),
            info: 'Whether preview frames should be automatically refreshed when content changes.'|t('app'),
            thin: true,
        }
    },
    defaultValues: {
        refresh: true,
    },
    allowAdd: true,
    allowReorder: true,
    allowDelete: true,
    rows: section.previewTargets,
    errors: section.getErrors('previewTargets'),
    data: {'error-key': 'previewTargets'},
    static: readOnly,
}) }}

{{ forms.textField({
    label: 'Max Authors'|t('app'),
    instructions: 'The maximum number of authors that entries in this section can have.'|t('app'),
    id: 'maxAuthors',
    name: 'maxAuthors',
    autocorrect: false,
    autocapitalize: false,
    default: 1,
    value: section.maxAuthors,
    errors: section.getErrors('maxAuthors'),
    data: {'error-key': 'maxAuthors'},
    size: 5,
    disabled: readOnly,
}) }}

{% if brandNewSection %}
    {% js on ready %}
        new Craft.HandleGenerator('#name', '#handle');

        {% for site in craft.app.sites.getAllSites() %}
            new Craft.UriFormatGenerator(
                '#name',
                '#sites tr[data-id=\"{{ site.handle }}\"] textarea[name\$=\"[singleUri]\"]',
                { updateWhenHidden: true }
            );
            new Craft.UriFormatGenerator(
                '#name',
                '#sites tr[data-id=\"{{ site.handle }}\"] textarea[name\$=\"[uriFormat]\"]',
                { suffix: '/{slug}', updateWhenHidden: true }
            );
            new Craft.UriFormatGenerator(
                '#name',
                '#sites tr[data-id=\"{{ site.handle }}\"] input[name\$=\"[template]\"]',
                { suffix: '/_entry.twig', updateWhenHidden: true }
            );
        {% endfor %}
    {% endjs %}
{% endif %}
", "settings/sections/_edit.twig", "/var/www/html/backend/vendor/craftcms/cms/src/templates/settings/sections/_edit.twig");
    }
}

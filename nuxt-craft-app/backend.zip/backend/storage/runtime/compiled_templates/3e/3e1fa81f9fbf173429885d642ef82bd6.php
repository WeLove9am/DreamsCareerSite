<?php

use Twig\Environment;
use Twig\Error\LoaderError;
use Twig\Error\RuntimeError;
use Twig\Extension\CoreExtension;
use Twig\Extension\SandboxExtension;
use Twig\Markup;
use Twig\Sandbox\SecurityError;
use Twig\Sandbox\SecurityNotAllowedTagError;
use Twig\Sandbox\SecurityNotAllowedFilterError;
use Twig\Sandbox\SecurityNotAllowedFunctionError;
use Twig\Source;
use Twig\Template;
use Twig\TemplateWrapper;

/* _layouts/base */
class __TwigTemplate_7c5fa405dc30f9c718ff433cd0129d4a extends Template
{
    private Source $source;
    /**
     * @var array<string, Template>
     */
    private array $macros = [];

    public function __construct(Environment $env)
    {
        parent::__construct($env);

        $this->source = $this->getSourceContext();

        $this->parent = false;

        $this->blocks = [
            'head' => [$this, 'block_head'],
            'body' => [$this, 'block_body'],
            'foot' => [$this, 'block_foot'],
        ];
    }

    protected function doDisplay(array $context, array $blocks = []): iterable
    {
        $macros = $this->macros;
        craft\helpers\Template::beginProfile("template", "_layouts/base");
        // line 1
        $context["systemName"] = $this->extensions['craft\web\twig\Extension']->translateFilter(craft\helpers\Template::attribute($this->env, $this->source, craft\helpers\Template::attribute($this->env, $this->source, (isset($context["craft"]) || array_key_exists("craft", $context) ? $context["craft"] : (function () { throw new RuntimeError('Variable "craft" does not exist.', 1, $this->source); })()), "app", [], "any", false, false, false, 1), "getSystemName", [], "method", false, false, false, 1), "site");
        // line 2
        $context["docTitle"] = ((array_key_exists("docTitle", $context)) ? ((isset($context["docTitle"]) || array_key_exists("docTitle", $context) ? $context["docTitle"] : (function () { throw new RuntimeError('Variable "docTitle" does not exist.', 2, $this->source); })())) : (Twig\Extension\CoreExtension::striptags((isset($context["title"]) || array_key_exists("title", $context) ? $context["title"] : (function () { throw new RuntimeError('Variable "title" does not exist.', 2, $this->source); })()))));
        // line 3
        $context["orientation"] = craft\helpers\Template::attribute($this->env, $this->source, craft\helpers\Template::attribute($this->env, $this->source, craft\helpers\Template::attribute($this->env, $this->source, (isset($context["craft"]) || array_key_exists("craft", $context) ? $context["craft"] : (function () { throw new RuntimeError('Variable "craft" does not exist.', 3, $this->source); })()), "app", [], "any", false, false, false, 3), "locale", [], "any", false, false, false, 3), "getOrientation", [], "method", false, false, false, 3);
        // line 4
        $context["a11yDefaults"] = craft\helpers\Template::attribute($this->env, $this->source, craft\helpers\Template::attribute($this->env, $this->source, craft\helpers\Template::attribute($this->env, $this->source, craft\helpers\Template::attribute($this->env, $this->source, (isset($context["craft"]) || array_key_exists("craft", $context) ? $context["craft"] : (function () { throw new RuntimeError('Variable "craft" does not exist.', 4, $this->source); })()), "app", [], "any", false, false, false, 4), "config", [], "any", false, false, false, 4), "general", [], "any", false, false, false, 4), "accessibilityDefaults", [], "any", false, false, false, 4);
        // line 5
        $context["requestedSite"] = craft\helpers\Template::attribute($this->env, $this->source, craft\helpers\Template::attribute($this->env, $this->source, (isset($context["craft"]) || array_key_exists("craft", $context) ? $context["craft"] : (function () { throw new RuntimeError('Variable "craft" does not exist.', 5, $this->source); })()), "cp", [], "any", false, false, false, 5), "requestedSite", [], "any", false, false, false, 5);
        // line 6
        yield "
";
        // line 7
        $context["bodyClass"] = $this->extensions['craft\web\twig\Extension']->filterFilter($this->env, $this->extensions['craft\web\twig\Extension']->mergeFilter(craft\helpers\Html::explodeClass((($context["bodyClass"]) ?? ([]))), [        // line 8
(isset($context["orientation"]) || array_key_exists("orientation", $context) ? $context["orientation"] : (function () { throw new RuntimeError('Variable "orientation" does not exist.', 8, $this->source); })()), (((((craft\helpers\Template::attribute($this->env, $this->source,         // line 9
($context["currentUser"] ?? null), "getPreference", ["useShapes"], "method", true, true, false, 9) &&  !(null === craft\helpers\Template::attribute($this->env, $this->source, ($context["currentUser"] ?? null), "getPreference", ["useShapes"], "method", false, false, false, 9)))) ? (craft\helpers\Template::attribute($this->env, $this->source, ($context["currentUser"] ?? null), "getPreference", ["useShapes"], "method", false, false, false, 9)) : ((((craft\helpers\Template::attribute($this->env, $this->source, ($context["a11yDefaults"] ?? null), "useShapes", [], "array", true, true, false, 9) &&  !(null === craft\helpers\Template::attribute($this->env, $this->source, ($context["a11yDefaults"] ?? null), "useShapes", [], "array", false, false, false, 9)))) ? (craft\helpers\Template::attribute($this->env, $this->source, ($context["a11yDefaults"] ?? null), "useShapes", [], "array", false, false, false, 9)) : (false))))) ? ("use-shapes") : ("")), (((((craft\helpers\Template::attribute($this->env, $this->source,         // line 10
($context["currentUser"] ?? null), "getPreference", ["underlineLinks"], "method", true, true, false, 10) &&  !(null === craft\helpers\Template::attribute($this->env, $this->source, ($context["currentUser"] ?? null), "getPreference", ["underlineLinks"], "method", false, false, false, 10)))) ? (craft\helpers\Template::attribute($this->env, $this->source, ($context["currentUser"] ?? null), "getPreference", ["underlineLinks"], "method", false, false, false, 10)) : ((((craft\helpers\Template::attribute($this->env, $this->source, ($context["a11yDefaults"] ?? null), "underlineLinks", [], "array", true, true, false, 10) &&  !(null === craft\helpers\Template::attribute($this->env, $this->source, ($context["a11yDefaults"] ?? null), "underlineLinks", [], "array", false, false, false, 10)))) ? (craft\helpers\Template::attribute($this->env, $this->source, ($context["a11yDefaults"] ?? null), "underlineLinks", [], "array", false, false, false, 10)) : (false))))) ? ("underline-links") : ("")), ("notifications--" . (((craft\helpers\Template::attribute($this->env, $this->source,         // line 11
($context["currentUser"] ?? null), "getPreference", ["notificationPosition"], "method", true, true, false, 11) &&  !(null === craft\helpers\Template::attribute($this->env, $this->source, ($context["currentUser"] ?? null), "getPreference", ["notificationPosition"], "method", false, false, false, 11)))) ? (craft\helpers\Template::attribute($this->env, $this->source, ($context["currentUser"] ?? null), "getPreference", ["notificationPosition"], "method", false, false, false, 11)) : ((((craft\helpers\Template::attribute($this->env, $this->source, ($context["a11yDefaults"] ?? null), "notificationPosition", [], "array", true, true, false, 11) &&  !(null === craft\helpers\Template::attribute($this->env, $this->source, ($context["a11yDefaults"] ?? null), "notificationPosition", [], "array", false, false, false, 11)))) ? (craft\helpers\Template::attribute($this->env, $this->source, ($context["a11yDefaults"] ?? null), "notificationPosition", [], "array", false, false, false, 11)) : ("end-start"))))), ((        // line 12
(isset($context["requestedSite"]) || array_key_exists("requestedSite", $context) ? $context["requestedSite"] : (function () { throw new RuntimeError('Variable "requestedSite" does not exist.', 12, $this->source); })())) ? (("site--" . craft\helpers\Template::attribute($this->env, $this->source, (isset($context["requestedSite"]) || array_key_exists("requestedSite", $context) ? $context["requestedSite"] : (function () { throw new RuntimeError('Variable "requestedSite" does not exist.', 12, $this->source); })()), "handle", [], "any", false, false, false, 12))) : (""))]));
        // line 15
        $context["bodyAttributes"] = $this->extensions['craft\web\twig\Extension']->mergeFilter(["class" =>         // line 16
(isset($context["bodyClass"]) || array_key_exists("bodyClass", $context) ? $context["bodyClass"] : (function () { throw new RuntimeError('Variable "bodyClass" does not exist.', 16, $this->source); })()), "dir" =>         // line 17
(isset($context["orientation"]) || array_key_exists("orientation", $context) ? $context["orientation"] : (function () { throw new RuntimeError('Variable "orientation" does not exist.', 17, $this->source); })())], ((        // line 18
$context["bodyAttributes"]) ?? ([])), true);
        // line 20
        craft\helpers\Template::attribute($this->env, $this->source, (isset($context["view"]) || array_key_exists("view", $context) ? $context["view"] : (function () { throw new RuntimeError('Variable "view" does not exist.', 20, $this->source); })()), "registerAssetBundle", ["craft\\web\\assets\\cp\\CpAsset"], "method", false, false, false, 20);
        // line 21
        $context["cpAssetUrl"] = craft\helpers\Template::attribute($this->env, $this->source, craft\helpers\Template::attribute($this->env, $this->source, (isset($context["view"]) || array_key_exists("view", $context) ? $context["view"] : (function () { throw new RuntimeError('Variable "view" does not exist.', 21, $this->source); })()), "getAssetManager", [], "method", false, false, false, 21), "getPublishedUrl", ["@app/web/assets/cp/dist", true], "method", false, false, false, 21);
        // line 23
        echo \Craft::$app->getView()->invokeHook("cp.layouts.base", $context);

        // line 25
        yield "<!DOCTYPE html>
<html xmlns=\"http://www.w3.org/1999/xhtml\" lang=\"";
        // line 26
        yield $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape(craft\helpers\Template::attribute($this->env, $this->source, craft\helpers\Template::attribute($this->env, $this->source, (isset($context["craft"]) || array_key_exists("craft", $context) ? $context["craft"] : (function () { throw new RuntimeError('Variable "craft" does not exist.', 26, $this->source); })()), "app", [], "any", false, false, false, 26), "language", [], "any", false, false, false, 26), "html", null, true);
        yield "\">
<head>
    ";
        // line 28
        yield from $this->unwrap()->yieldBlock('head', $context, $blocks);
        // line 55
        yield "</head>
<body ";
        // line 56
        yield craft\helpers\Html::renderTagAttributes((isset($context["bodyAttributes"]) || array_key_exists("bodyAttributes", $context) ? $context["bodyAttributes"] : (function () { throw new RuntimeError('Variable "bodyAttributes" does not exist.', 56, $this->source); })()));
        yield ">
    ";
        // line 57
        $this->env->getFunction('beginBody')->getCallable()();
        yield "
    ";
        // line 58
        yield from $this->loadTemplate("_layouts/components/global-live-region", "_layouts/base", 58)->unwrap()->yield($context);
        // line 59
        yield "    ";
        yield from $this->unwrap()->yieldBlock('body', $context, $blocks);
        // line 60
        yield "    ";
        yield from $this->loadTemplate("_layouts/components/notifications", "_layouts/base", 60)->unwrap()->yield($context);
        // line 61
        yield "    ";
        yield from $this->unwrap()->yieldBlock('foot', $context, $blocks);
        // line 62
        yield "    ";
        $this->env->getFunction('endBody')->getCallable()();
        yield "
</body>
</html>
";
        craft\helpers\Template::endProfile("template", "_layouts/base");
        yield from [];
    }

    // line 28
    /**
     * @return iterable<null|scalar|\Stringable>
     */
    public function block_head(array $context, array $blocks = []): iterable
    {
        $macros = $this->macros;
        craft\helpers\Template::beginProfile("block", "head");
        // line 29
        yield "    <meta http-equiv=\"X-UA-Compatible\" content=\"IE=edge\">
    <meta charset=\"utf-8\">
    <title>";
        // line 31
        yield $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape((((isset($context["docTitle"]) || array_key_exists("docTitle", $context) ? $context["docTitle"] : (function () { throw new RuntimeError('Variable "docTitle" does not exist.', 31, $this->source); })()) . ((($this->extensions['craft\web\twig\Extension']->lengthFilter($this->env, (isset($context["docTitle"]) || array_key_exists("docTitle", $context) ? $context["docTitle"] : (function () { throw new RuntimeError('Variable "docTitle" does not exist.', 31, $this->source); })())) && $this->extensions['craft\web\twig\Extension']->lengthFilter($this->env, (isset($context["systemName"]) || array_key_exists("systemName", $context) ? $context["systemName"] : (function () { throw new RuntimeError('Variable "systemName" does not exist.', 31, $this->source); })())))) ? (" - ") : (""))) . (isset($context["systemName"]) || array_key_exists("systemName", $context) ? $context["systemName"] : (function () { throw new RuntimeError('Variable "systemName" does not exist.', 31, $this->source); })())), "html", null, true);
        yield "</title>
    ";
        // line 32
        $this->env->getFunction('head')->getCallable()();
        yield "
    <meta name=\"referrer\" content=\"origin-when-cross-origin\">
    <meta name=\"viewport\" content=\"width=device-width, initial-scale=1\">

    ";
        // line 36
        $context["hasCustomIcon"] = false;
        // line 37
        yield "    ";
        $context['_parent'] = $context;
        $context['_seq'] = CoreExtension::ensureTraversable(craft\helpers\Template::attribute($this->env, $this->source, craft\helpers\Template::attribute($this->env, $this->source, craft\helpers\Template::attribute($this->env, $this->source, craft\helpers\Template::attribute($this->env, $this->source, (isset($context["craft"]) || array_key_exists("craft", $context) ? $context["craft"] : (function () { throw new RuntimeError('Variable "craft" does not exist.', 37, $this->source); })()), "app", [], "any", false, false, false, 37), "config", [], "any", false, false, false, 37), "general", [], "any", false, false, false, 37), "cpHeadTags", [], "any", false, false, false, 37));
        foreach ($context['_seq'] as $context["_key"] => $context["tag"]) {
            // line 38
            yield "        ";
            yield $this->extensions['craft\web\twig\Extension']->tagFunction(craft\helpers\Template::attribute($this->env, $this->source, $context["tag"], 0, [], "array", false, false, false, 38), craft\helpers\Template::attribute($this->env, $this->source, $context["tag"], 1, [], "array", false, false, false, 38));
            yield "
        ";
            // line 39
            if (((craft\helpers\Template::attribute($this->env, $this->source, $context["tag"], 0, [], "array", false, false, false, 39) == "link") && ((((craft\helpers\Template::attribute($this->env, $this->source, craft\helpers\Template::attribute($this->env, $this->source, $context["tag"], 1, [], "array", false, true, false, 39), "rel", [], "any", true, true, false, 39) &&  !(null === craft\helpers\Template::attribute($this->env, $this->source, craft\helpers\Template::attribute($this->env, $this->source, $context["tag"], 1, [], "array", false, true, false, 39), "rel", [], "any", false, false, false, 39)))) ? (craft\helpers\Template::attribute($this->env, $this->source, craft\helpers\Template::attribute($this->env, $this->source, $context["tag"], 1, [], "array", false, true, false, 39), "rel", [], "any", false, false, false, 39)) : (null)) == "icon"))) {
                // line 40
                yield "            ";
                $context["hasCustomIcon"] = true;
                // line 41
                yield "        ";
            }
            // line 42
            yield "    ";
        }
        $_parent = $context['_parent'];
        unset($context['_seq'], $context['_key'], $context['tag'], $context['_parent']);
        $context = array_intersect_key($context, $_parent) + $_parent;
        // line 43
        yield "    ";
        if ( !(isset($context["hasCustomIcon"]) || array_key_exists("hasCustomIcon", $context) ? $context["hasCustomIcon"] : (function () { throw new RuntimeError('Variable "hasCustomIcon" does not exist.', 43, $this->source); })())) {
            // line 44
            yield "        <link rel=\"icon\" href=\"";
            yield $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape((isset($context["cpAssetUrl"]) || array_key_exists("cpAssetUrl", $context) ? $context["cpAssetUrl"] : (function () { throw new RuntimeError('Variable "cpAssetUrl" does not exist.', 44, $this->source); })()), "html", null, true);
            yield "/images/icons/favicon.ico\">
        <link rel=\"icon\" type=\"image/svg+xml\" sizes=\"any\" href=\"";
            // line 45
            yield $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape((isset($context["cpAssetUrl"]) || array_key_exists("cpAssetUrl", $context) ? $context["cpAssetUrl"] : (function () { throw new RuntimeError('Variable "cpAssetUrl" does not exist.', 45, $this->source); })()), "html", null, true);
            yield "/images/icons/icon.svg\">
        <link rel=\"apple-touch-icon\" sizes=\"180x180\" href=\"";
            // line 46
            yield $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape((isset($context["cpAssetUrl"]) || array_key_exists("cpAssetUrl", $context) ? $context["cpAssetUrl"] : (function () { throw new RuntimeError('Variable "cpAssetUrl" does not exist.', 46, $this->source); })()), "html", null, true);
            yield "/images/icons/apple-touch-icon.png\">
        <link rel=\"mask-icon\" href=\"";
            // line 47
            yield $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape((isset($context["cpAssetUrl"]) || array_key_exists("cpAssetUrl", $context) ? $context["cpAssetUrl"] : (function () { throw new RuntimeError('Variable "cpAssetUrl" does not exist.', 47, $this->source); })()), "html", null, true);
            yield "/images/icons/safari-pinned-tab.svg\" color=\"#e5422b\">
    ";
        }
        // line 49
        yield "
    <script type=\"text/javascript\">
        // Fix for Firefox autofocus CSS bug
        // See: http://stackoverflow.com/questions/18943276/html-5-autofocus-messes-up-css-loading/18945951#18945951
    </script>
    ";
        craft\helpers\Template::endProfile("block", "head");
        yield from [];
    }

    // line 59
    /**
     * @return iterable<null|scalar|\Stringable>
     */
    public function block_body(array $context, array $blocks = []): iterable
    {
        $macros = $this->macros;
        craft\helpers\Template::beginProfile("block", "body");
        craft\helpers\Template::endProfile("block", "body");
        yield from [];
    }

    // line 61
    /**
     * @return iterable<null|scalar|\Stringable>
     */
    public function block_foot(array $context, array $blocks = []): iterable
    {
        $macros = $this->macros;
        craft\helpers\Template::beginProfile("block", "foot");
        craft\helpers\Template::endProfile("block", "foot");
        yield from [];
    }

    /**
     * @codeCoverageIgnore
     */
    public function getTemplateName(): string
    {
        return "_layouts/base";
    }

    /**
     * @codeCoverageIgnore
     */
    public function isTraitable(): bool
    {
        return false;
    }

    /**
     * @codeCoverageIgnore
     */
    public function getDebugInfo(): array
    {
        return array (  214 => 61,  202 => 59,  191 => 49,  186 => 47,  182 => 46,  178 => 45,  173 => 44,  170 => 43,  164 => 42,  161 => 41,  158 => 40,  156 => 39,  151 => 38,  146 => 37,  144 => 36,  137 => 32,  133 => 31,  129 => 29,  121 => 28,  110 => 62,  107 => 61,  104 => 60,  101 => 59,  99 => 58,  95 => 57,  91 => 56,  88 => 55,  86 => 28,  81 => 26,  78 => 25,  75 => 23,  73 => 21,  71 => 20,  69 => 18,  68 => 17,  67 => 16,  66 => 15,  64 => 12,  63 => 11,  62 => 10,  61 => 9,  60 => 8,  59 => 7,  56 => 6,  54 => 5,  52 => 4,  50 => 3,  48 => 2,  46 => 1,);
    }

    public function getSourceContext(): Source
    {
        return new Source("{% set systemName = craft.app.getSystemName()|t('site') -%}
{% set docTitle = docTitle is defined ? docTitle : title|striptags -%}
{% set orientation = craft.app.locale.getOrientation() -%}
{% set a11yDefaults = craft.app.config.general.accessibilityDefaults %}
{% set requestedSite = craft.cp.requestedSite %}

{% set bodyClass = (bodyClass ?? [])|explodeClass|merge([
    orientation,
    (currentUser.getPreference('useShapes') ?? a11yDefaults['useShapes'] ?? false) ? 'use-shapes',
    (currentUser.getPreference('underlineLinks') ?? a11yDefaults['underlineLinks'] ?? false) ? 'underline-links',
    \"notifications--#{currentUser.getPreference('notificationPosition') ?? a11yDefaults['notificationPosition'] ?? 'end-start'}\",
    requestedSite ? \"site--#{requestedSite.handle}\",
])|filter -%}

{% set bodyAttributes = {
    class: bodyClass,
    dir: orientation,
}|merge(bodyAttributes ?? {}, recursive=true) -%}

{% do view.registerAssetBundle('craft\\\\web\\\\assets\\\\cp\\\\CpAsset') -%}
{% set cpAssetUrl = view.getAssetManager().getPublishedUrl('@app/web/assets/cp/dist', true) -%}

{% hook \"cp.layouts.base\" -%}

<!DOCTYPE html>
<html xmlns=\"http://www.w3.org/1999/xhtml\" lang=\"{{ craft.app.language }}\">
<head>
    {% block head %}
    <meta http-equiv=\"X-UA-Compatible\" content=\"IE=edge\">
    <meta charset=\"utf-8\">
    <title>{{ docTitle ~ (docTitle|length and systemName|length ? ' - ') ~ systemName }}</title>
    {{ head() }}
    <meta name=\"referrer\" content=\"origin-when-cross-origin\">
    <meta name=\"viewport\" content=\"width=device-width, initial-scale=1\">

    {% set hasCustomIcon = false %}
    {% for tag in craft.app.config.general.cpHeadTags %}
        {{ tag(tag[0], tag[1]) }}
        {% if tag[0] == 'link' and (tag[1].rel ?? null) == 'icon' %}
            {% set hasCustomIcon = true %}
        {% endif %}
    {% endfor %}
    {% if not hasCustomIcon %}
        <link rel=\"icon\" href=\"{{ cpAssetUrl }}/images/icons/favicon.ico\">
        <link rel=\"icon\" type=\"image/svg+xml\" sizes=\"any\" href=\"{{ cpAssetUrl }}/images/icons/icon.svg\">
        <link rel=\"apple-touch-icon\" sizes=\"180x180\" href=\"{{ cpAssetUrl }}/images/icons/apple-touch-icon.png\">
        <link rel=\"mask-icon\" href=\"{{ cpAssetUrl }}/images/icons/safari-pinned-tab.svg\" color=\"#e5422b\">
    {% endif %}

    <script type=\"text/javascript\">
        // Fix for Firefox autofocus CSS bug
        // See: http://stackoverflow.com/questions/18943276/html-5-autofocus-messes-up-css-loading/18945951#18945951
    </script>
    {% endblock %}
</head>
<body {{ attr(bodyAttributes) }}>
    {{ beginBody() }}
    {% include '_layouts/components/global-live-region' %}
    {% block body %}{% endblock %}
    {% include '_layouts/components/notifications' %}
    {% block foot %}{% endblock %}
    {{ endBody() }}
</body>
</html>
", "_layouts/base", "/var/www/html/backend/vendor/craftcms/cms/src/templates/_layouts/base.twig");
    }
}

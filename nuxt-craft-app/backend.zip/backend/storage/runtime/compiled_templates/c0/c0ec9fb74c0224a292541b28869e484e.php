<?php

use Twig\Environment;
use Twig\Error\LoaderError;
use Twig\Error\RuntimeError;
use Twig\Extension\CoreExtension;
use Twig\Extension\SandboxExtension;
use Twig\Markup;
use Twig\Sandbox\SecurityError;
use Twig\Sandbox\SecurityNotAllowedTagError;
use Twig\Sandbox\SecurityNotAllowedFilterError;
use Twig\Sandbox\SecurityNotAllowedFunctionError;
use Twig\Source;
use Twig\Template;
use Twig\TemplateWrapper;

/* settings */
class __TwigTemplate_131838f8e396025817e938500b754259 extends Template
{
    private Source $source;
    /**
     * @var array<string, Template>
     */
    private array $macros = [];

    public function __construct(Environment $env)
    {
        parent::__construct($env);

        $this->source = $this->getSourceContext();

        $this->blocks = [
            'content' => [$this, 'block_content'],
        ];
    }

    protected function doGetParent(array $context): bool|string|Template|TemplateWrapper
    {
        // line 4
        return "_layouts/cp";
    }

    protected function doDisplay(array $context, array $blocks = []): iterable
    {
        $macros = $this->macros;
        craft\helpers\Template::beginProfile("template", "settings");
        // line 1
        Craft::$app->controller->requireAdmin(false);
        // line 5
        $context["title"] = $this->extensions['craft\web\twig\Extension']->translateFilter("Settings", "app");
        // line 6
        $context["readOnly"] =  !craft\helpers\Template::attribute($this->env, $this->source, craft\helpers\Template::attribute($this->env, $this->source, craft\helpers\Template::attribute($this->env, $this->source, craft\helpers\Template::attribute($this->env, $this->source, (isset($context["craft"]) || array_key_exists("craft", $context) ? $context["craft"] : (function () { throw new RuntimeError('Variable "craft" does not exist.', 6, $this->source); })()), "app", [], "any", false, false, false, 6), "config", [], "any", false, false, false, 6), "general", [], "any", false, false, false, 6), "allowAdminChanges", [], "any", false, false, false, 6);
        // line 8
        if ((isset($context["readOnly"]) || array_key_exists("readOnly", $context) ? $context["readOnly"] : (function () { throw new RuntimeError('Variable "readOnly" does not exist.', 8, $this->source); })())) {
            // line 9
            $context["contentNotice"] = craft\helpers\Cp::readOnlyNoticeHtml();
        }
        // line 4
        $this->parent = $this->loadTemplate("_layouts/cp", "settings", 4);
        yield from $this->parent->unwrap()->yield($context, array_merge($this->blocks, $blocks));
        craft\helpers\Template::endProfile("template", "settings");
    }

    // line 12
    /**
     * @return iterable<null|scalar|\Stringable>
     */
    public function block_content(array $context, array $blocks = []): iterable
    {
        $macros = $this->macros;
        craft\helpers\Template::beginProfile("block", "content");
        // line 13
        yield "    ";
        $context['_parent'] = $context;
        $context['_seq'] = CoreExtension::ensureTraversable(craft\helpers\Template::attribute($this->env, $this->source, craft\helpers\Template::attribute($this->env, $this->source, (isset($context["craft"]) || array_key_exists("craft", $context) ? $context["craft"] : (function () { throw new RuntimeError('Variable "craft" does not exist.', 13, $this->source); })()), "cp", [], "any", false, false, false, 13), "settings", [80], "method", false, false, false, 13));
        $context['loop'] = [
          'parent' => $context['_parent'],
          'index0' => 0,
          'index'  => 1,
          'first'  => true,
        ];
        if (is_array($context['_seq']) || (is_object($context['_seq']) && $context['_seq'] instanceof \Countable)) {
            $length = count($context['_seq']);
            $context['loop']['revindex0'] = $length - 1;
            $context['loop']['revindex'] = $length;
            $context['loop']['length'] = $length;
            $context['loop']['last'] = 1 === $length;
        }
        foreach ($context['_seq'] as $context["category"] => $context["items"]) {
            // line 14
            yield "        ";
            $context["headingId"] = ("category-heading-" . craft\helpers\Template::attribute($this->env, $this->source, $context["loop"], "index", [], "any", false, false, false, 14));
            // line 15
            yield "        <h2 id=\"";
            yield $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape((isset($context["headingId"]) || array_key_exists("headingId", $context) ? $context["headingId"] : (function () { throw new RuntimeError('Variable "headingId" does not exist.', 15, $this->source); })()), "html", null, true);
            yield "\">";
            yield $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($context["category"], "html", null, true);
            yield "</h2>
        <nav aria-labelledby=\"";
            // line 16
            yield $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape((isset($context["headingId"]) || array_key_exists("headingId", $context) ? $context["headingId"] : (function () { throw new RuntimeError('Variable "headingId" does not exist.', 16, $this->source); })()), "html", null, true);
            yield "\">
            <ul class=\"icons\">
                ";
            // line 18
            $context['_parent'] = $context;
            $context['_seq'] = CoreExtension::ensureTraversable($context["items"]);
            foreach ($context['_seq'] as $context["handle"] => $context["item"]) {
                // line 19
                yield "                    ";
                $context["label"] = ((craft\helpers\Template::attribute($this->env, $this->source, $context["item"], "label", [], "any", false, false, false, 19) . " - ") . $this->extensions['craft\web\twig\Extension']->translateFilter("Settings", "app"));
                // line 20
                yield "                    ";
                $context["icon"] = (((craft\helpers\Template::attribute($this->env, $this->source, $context["item"], "iconMask", [], "any", true, true, false, 20) &&  !(null === craft\helpers\Template::attribute($this->env, $this->source, $context["item"], "iconMask", [], "any", false, false, false, 20)))) ? (craft\helpers\Template::attribute($this->env, $this->source, $context["item"], "iconMask", [], "any", false, false, false, 20)) : (craft\helpers\Template::attribute($this->env, $this->source, $context["item"], "icon", [], "any", false, false, false, 20)));
                // line 21
                yield "                    <li>
                        <a aria-label=\"";
                // line 22
                yield $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape((isset($context["label"]) || array_key_exists("label", $context) ? $context["label"] : (function () { throw new RuntimeError('Variable "label" does not exist.', 22, $this->source); })()), "html", null, true);
                yield "\" href=\"";
                if (craft\helpers\Template::attribute($this->env, $this->source, $context["item"], "url", [], "any", true, true, false, 22)) {
                    yield $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape(craft\helpers\UrlHelper::url(craft\helpers\Template::attribute($this->env, $this->source, $context["item"], "url", [], "any", false, false, false, 22)), "html", null, true);
                } else {
                    yield $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape(craft\helpers\UrlHelper::url(("settings/" . $context["handle"])), "html", null, true);
                }
                yield "\">
                            <div class=\"icon";
                // line 23
                if (craft\helpers\Template::attribute($this->env, $this->source, $context["item"], "iconMask", [], "any", true, true, false, 23)) {
                    yield " icon-mask";
                }
                yield "\" aria-hidden=\"true\">
                                ";
                // line 24
                yield $this->extensions['craft\web\twig\Extension']->svgFunction((isset($context["icon"]) || array_key_exists("icon", $context) ? $context["icon"] : (function () { throw new RuntimeError('Variable "icon" does not exist.', 24, $this->source); })()), true, true);
                yield "
                            </div>
                            ";
                // line 26
                yield $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape(craft\helpers\Template::attribute($this->env, $this->source, $context["item"], "label", [], "any", false, false, false, 26), "html", null, true);
                yield "
                        </a>
                    </li>
                ";
            }
            $_parent = $context['_parent'];
            unset($context['_seq'], $context['handle'], $context['item'], $context['_parent']);
            $context = array_intersect_key($context, $_parent) + $_parent;
            // line 30
            yield "            </ul>
        </nav>

        ";
            // line 33
            if ( !craft\helpers\Template::attribute($this->env, $this->source, $context["loop"], "last", [], "any", false, false, false, 33)) {
                // line 34
                yield "            <hr>
        ";
            }
            // line 36
            yield "    ";
            ++$context['loop']['index0'];
            ++$context['loop']['index'];
            $context['loop']['first'] = false;
            if (isset($context['loop']['revindex0'], $context['loop']['revindex'])) {
                --$context['loop']['revindex0'];
                --$context['loop']['revindex'];
                $context['loop']['last'] = 0 === $context['loop']['revindex0'];
            }
        }
        $_parent = $context['_parent'];
        unset($context['_seq'], $context['category'], $context['items'], $context['_parent'], $context['loop']);
        $context = array_intersect_key($context, $_parent) + $_parent;
        craft\helpers\Template::endProfile("block", "content");
        yield from [];
    }

    /**
     * @codeCoverageIgnore
     */
    public function getTemplateName(): string
    {
        return "settings";
    }

    /**
     * @codeCoverageIgnore
     */
    public function isTraitable(): bool
    {
        return false;
    }

    /**
     * @codeCoverageIgnore
     */
    public function getDebugInfo(): array
    {
        return array (  161 => 36,  157 => 34,  155 => 33,  150 => 30,  140 => 26,  135 => 24,  129 => 23,  119 => 22,  116 => 21,  113 => 20,  110 => 19,  106 => 18,  101 => 16,  94 => 15,  91 => 14,  73 => 13,  65 => 12,  59 => 4,  56 => 9,  54 => 8,  52 => 6,  50 => 5,  48 => 1,  40 => 4,);
    }

    public function getSourceContext(): Source
    {
        return new Source("{% requireAdmin false %}


{% extends \"_layouts/cp\" %}
{% set title = \"Settings\"|t('app') %}
{% set readOnly = not craft.app.config.general.allowAdminChanges %}

{% if readOnly %}
    {% set contentNotice = readOnlyNotice() %}
{% endif %}

{% block content %}
    {% for category, items in craft.cp.settings(80) %}
        {% set headingId = \"category-heading-#{loop.index}\" %}
        <h2 id=\"{{ headingId }}\">{{ category }}</h2>
        <nav aria-labelledby=\"{{ headingId }}\">
            <ul class=\"icons\">
                {% for handle, item in items %}
                    {% set label = item.label ~ ' - ' ~ 'Settings'|t('app') %}
                    {% set icon = item.iconMask ?? item.icon %}
                    <li>
                        <a aria-label=\"{{ label }}\" href=\"{% if item.url is defined %}{{ url(item.url) }}{% else %}{{ url('settings/'~handle) }}{% endif %}\">
                            <div class=\"icon{% if item.iconMask is defined %} icon-mask{% endif %}\" aria-hidden=\"true\">
                                {{ svg(icon, sanitize=true, namespace=true) }}
                            </div>
                            {{ item.label }}
                        </a>
                    </li>
                {% endfor %}
            </ul>
        </nav>

        {% if not loop.last %}
            <hr>
        {% endif %}
    {% endfor %}
{% endblock %}
", "settings", "/var/www/html/backend/vendor/craftcms/cms/src/templates/settings/index.twig");
    }
}

<?php

use Twig\Environment;
use Twig\Error\LoaderError;
use Twig\Error\RuntimeError;
use Twig\Extension\CoreExtension;
use Twig\Extension\SandboxExtension;
use Twig\Markup;
use Twig\Sandbox\SecurityError;
use Twig\Sandbox\SecurityNotAllowedTagError;
use Twig\Sandbox\SecurityNotAllowedFilterError;
use Twig\Sandbox\SecurityNotAllowedFunctionError;
use Twig\Source;
use Twig\Template;
use Twig\TemplateWrapper;

/* _layouts/components/system-info */
class __TwigTemplate_dbaf1d5cd6a6fd5dc72a6974b83e255d extends Template
{
    private Source $source;
    /**
     * @var array<string, Template>
     */
    private array $macros = [];

    public function __construct(Environment $env)
    {
        parent::__construct($env);

        $this->source = $this->getSourceContext();

        $this->parent = false;

        $this->blocks = [
        ];
    }

    protected function doDisplay(array $context, array $blocks = []): iterable
    {
        $macros = $this->macros;
        craft\helpers\Template::beginProfile("template", "_layouts/components/system-info");
        // line 1
        $context["hasSystemIcon"] = (((isset($context["CraftEdition"]) || array_key_exists("CraftEdition", $context) ? $context["CraftEdition"] : (function () { throw new RuntimeError('Variable "CraftEdition" does not exist.', 1, $this->source); })()) >= (isset($context["CraftPro"]) || array_key_exists("CraftPro", $context) ? $context["CraftPro"] : (function () { throw new RuntimeError('Variable "CraftPro" does not exist.', 1, $this->source); })())) && craft\helpers\Template::attribute($this->env, $this->source, craft\helpers\Template::attribute($this->env, $this->source, (isset($context["craft"]) || array_key_exists("craft", $context) ? $context["craft"] : (function () { throw new RuntimeError('Variable "craft" does not exist.', 1, $this->source); })()), "rebrand", [], "any", false, false, false, 1), "isIconUploaded", [], "any", false, false, false, 1));
        // line 2
        yield "
";
        // line 3
        ob_start();
        // line 10
        yield "    <div id=\"site-icon\">
        ";
        // line 11
        if ((isset($context["hasSystemIcon"]) || array_key_exists("hasSystemIcon", $context) ? $context["hasSystemIcon"] : (function () { throw new RuntimeError('Variable "hasSystemIcon" does not exist.', 11, $this->source); })())) {
            // line 12
            yield "            <img src=\"";
            yield $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape(craft\helpers\Template::attribute($this->env, $this->source, craft\helpers\Template::attribute($this->env, $this->source, craft\helpers\Template::attribute($this->env, $this->source, (isset($context["craft"]) || array_key_exists("craft", $context) ? $context["craft"] : (function () { throw new RuntimeError('Variable "craft" does not exist.', 12, $this->source); })()), "rebrand", [], "any", false, false, false, 12), "icon", [], "any", false, false, false, 12), "url", [], "any", false, false, false, 12), "html", null, true);
            yield "\" alt=\"\">
        ";
        } else {
            // line 14
            yield "            ";
            yield craft\helpers\Cp::iconSvg("c-outline");
            yield "
        ";
        }
        // line 16
        yield "    </div>
    <div id=\"system-name\">
        <span class=\"h2\">";
        // line 18
        yield $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape((isset($context["systemName"]) || array_key_exists("systemName", $context) ? $context["systemName"] : (function () { throw new RuntimeError('Variable "systemName" does not exist.', 18, $this->source); })()), "html", null, true);
        yield "</span>
    </div>
";
        echo craft\helpers\Html::tag(((        // line 3
(isset($context["siteUrl"]) || array_key_exists("siteUrl", $context) ? $context["siteUrl"] : (function () { throw new RuntimeError('Variable "siteUrl" does not exist.', 3, $this->source); })())) ? ("a") : ("div")), ob_get_clean(), ["id" => "system-info", "href" => ((        // line 5
$context["siteUrl"]) ?? (false)), "rel" => ((        // line 6
(isset($context["siteUrl"]) || array_key_exists("siteUrl", $context) ? $context["siteUrl"] : (function () { throw new RuntimeError('Variable "siteUrl" does not exist.', 6, $this->source); })())) ? ("noopener") : (false)), "target" => ((        // line 7
(isset($context["siteUrl"]) || array_key_exists("siteUrl", $context) ? $context["siteUrl"] : (function () { throw new RuntimeError('Variable "siteUrl" does not exist.', 7, $this->source); })())) ? ("_blank") : (false)), "title" => ((        // line 8
(isset($context["siteUrl"]) || array_key_exists("siteUrl", $context) ? $context["siteUrl"] : (function () { throw new RuntimeError('Variable "siteUrl" does not exist.', 8, $this->source); })())) ? ($this->extensions['craft\web\twig\Extension']->translateFilter("View site", "app")) : (false))]);
        craft\helpers\Template::endProfile("template", "_layouts/components/system-info");
        yield from [];
    }

    /**
     * @codeCoverageIgnore
     */
    public function getTemplateName(): string
    {
        return "_layouts/components/system-info";
    }

    /**
     * @codeCoverageIgnore
     */
    public function isTraitable(): bool
    {
        return false;
    }

    /**
     * @codeCoverageIgnore
     */
    public function getDebugInfo(): array
    {
        return array (  80 => 8,  79 => 7,  78 => 6,  77 => 5,  76 => 3,  71 => 18,  67 => 16,  61 => 14,  55 => 12,  53 => 11,  50 => 10,  48 => 3,  45 => 2,  43 => 1,);
    }

    public function getSourceContext(): Source
    {
        return new Source("{% set hasSystemIcon = CraftEdition >= CraftPro and craft.rebrand.isIconUploaded %}

{% tag siteUrl ? 'a' : 'div' with {
    id: 'system-info',
    href: siteUrl ?? false,
    rel: siteUrl ? 'noopener' : false,
    target: siteUrl ? '_blank' : false,
    title: siteUrl ? 'View site'|t('app') : false,
} %}
    <div id=\"site-icon\">
        {% if hasSystemIcon %}
            <img src=\"{{ craft.rebrand.icon.url }}\" alt=\"\">
        {% else %}
            {{ iconSvg('c-outline') }}
        {% endif %}
    </div>
    <div id=\"system-name\">
        <span class=\"h2\">{{ systemName }}</span>
    </div>
{% endtag %}
", "_layouts/components/system-info", "/var/www/html/backend/vendor/craftcms/cms/src/templates/_layouts/components/system-info.twig");
    }
}

<?php

use Twig\Environment;
use Twig\Error\LoaderError;
use Twig\Error\RuntimeError;
use Twig\Extension\CoreExtension;
use Twig\Extension\SandboxExtension;
use Twig\Markup;
use Twig\Sandbox\SecurityError;
use Twig\Sandbox\SecurityNotAllowedTagError;
use Twig\Sandbox\SecurityNotAllowedFilterError;
use Twig\Sandbox\SecurityNotAllowedFunctionError;
use Twig\Source;
use Twig\Template;
use Twig\TemplateWrapper;

/* _includes/forms/entryTypeSelect */
class __TwigTemplate_73de1076a1d5a09c0b693593ad44c849 extends Template
{
    private Source $source;
    /**
     * @var array<string, Template>
     */
    private array $macros = [];

    public function __construct(Environment $env)
    {
        parent::__construct($env);

        $this->source = $this->getSourceContext();

        $this->parent = false;

        $this->blocks = [
        ];
    }

    protected function doDisplay(array $context, array $blocks = []): iterable
    {
        $macros = $this->macros;
        craft\helpers\Template::beginProfile("template", "_includes/forms/entryTypeSelect");
        // line 1
        $context["allowOverrides"] = (($context["allowOverrides"]) ?? (false));
        // line 2
        yield "
";
        // line 3
        yield from $this->loadTemplate("_includes/forms/entryTypeSelect", "_includes/forms/entryTypeSelect", 3, "214092413")->unwrap()->yield(CoreExtension::merge($context, ["options" => ((        // line 4
$context["options"]) ?? (craft\helpers\Template::attribute($this->env, $this->source, craft\helpers\Template::attribute($this->env, $this->source, craft\helpers\Template::attribute($this->env, $this->source, (isset($context["craft"]) || array_key_exists("craft", $context) ? $context["craft"] : (function () { throw new RuntimeError('Variable "craft" does not exist.', 4, $this->source); })()), "app", [], "any", false, false, false, 4), "entries", [], "any", false, false, false, 4), "getAllEntryTypes", [], "method", false, false, false, 4))), "showHandles" => true, "showIndicators" => ((        // line 6
$context["showIndicators"]) ?? ((isset($context["allowOverrides"]) || array_key_exists("allowOverrides", $context) ? $context["allowOverrides"] : (function () { throw new RuntimeError('Variable "allowOverrides" does not exist.', 6, $this->source); })()))), "showDescription" => ((        // line 7
$context["showDescription"]) ?? ((isset($context["allowOverrides"]) || array_key_exists("allowOverrides", $context) ? $context["allowOverrides"] : (function () { throw new RuntimeError('Variable "allowOverrides" does not exist.', 7, $this->source); })()))), "createAction" => ((((        // line 8
$context["create"]) ?? (false))) ? ("entry-types/edit") : (null)), "jsClass" => ((        // line 9
$context["jsClass"]) ?? ("Craft.EntryTypeSelectInput")), "jsSettings" => $this->extensions['craft\web\twig\Extension']->mergeFilter(["allowOverrides" =>         // line 11
(isset($context["allowOverrides"]) || array_key_exists("allowOverrides", $context) ? $context["allowOverrides"] : (function () { throw new RuntimeError('Variable "allowOverrides" does not exist.', 11, $this->source); })())], ((        // line 12
$context["jsSettings"]) ?? ([])))]));
        craft\helpers\Template::endProfile("template", "_includes/forms/entryTypeSelect");
        yield from [];
    }

    /**
     * @codeCoverageIgnore
     */
    public function getTemplateName(): string
    {
        return "_includes/forms/entryTypeSelect";
    }

    /**
     * @codeCoverageIgnore
     */
    public function isTraitable(): bool
    {
        return false;
    }

    /**
     * @codeCoverageIgnore
     */
    public function getDebugInfo(): array
    {
        return array (  55 => 12,  54 => 11,  53 => 9,  52 => 8,  51 => 7,  50 => 6,  49 => 4,  48 => 3,  45 => 2,  43 => 1,);
    }

    public function getSourceContext(): Source
    {
        return new Source("{% set allowOverrides = allowOverrides ?? false %}

{% embed '_includes/forms/componentSelect.twig' with {
  options: options ?? craft.app.entries.getAllEntryTypes(),
  showHandles: true,
  showIndicators: showIndicators ?? allowOverrides,
  showDescription: showDescription ?? allowOverrides,
  createAction: (create ?? false) ? 'entry-types/edit' : null,
  jsClass: jsClass ?? 'Craft.EntryTypeSelectInput',
  jsSettings: {
    allowOverrides,
  }|merge(jsSettings ?? {}),
} %}
  {% block chips %}
    {% for entryType in values %}
      {% set overrides = allowOverrides ? {
        name: entryType.original and entryType.name != entryType.original.name ? entryType.name : null,
        handle: entryType.original and entryType.handle != entryType.original.handle ? entryType.handle : null,
        description: entryType.original and entryType.description != entryType.original.description ? entryType.description : null,
      }|filter : {} %}
      <li>
        {% set chip = chip(entryType, {
          inputName: inputName ?? name ?? null,
          inputValue: allowOverrides ? {
            id: entryType.id,
            group: (includeGroupInValues ?? false) ? (entryType.group ?? 'General'|t('app')) : null,
          }|filter|merge(overrides)|json_encode : null,
          checkbox: selectable ?? false,
          showActionMenu: showActionMenus,
          showHandle: showHandles,
          showIndicators: showIndicators,
          showDescription: showDescription,
          hyperlink: hyperlinks,
          overrides,
        }) %}
        {% if disabled %}
          {% set chip = chip|removeClass('removable') %}
        {% endif %}
        {{ chip|raw }}
      </li>
    {% endfor %}
  {% endblock %}
{% endembed %}
", "_includes/forms/entryTypeSelect", "/var/www/html/backend/vendor/craftcms/cms/src/templates/_includes/forms/entryTypeSelect.twig");
    }
}


/* _includes/forms/entryTypeSelect */
class __TwigTemplate_73de1076a1d5a09c0b693593ad44c849___214092413 extends Template
{
    private Source $source;
    /**
     * @var array<string, Template>
     */
    private array $macros = [];

    public function __construct(Environment $env)
    {
        parent::__construct($env);

        $this->source = $this->getSourceContext();

        $this->blocks = [
            'chips' => [$this, 'block_chips'],
        ];
    }

    protected function doGetParent(array $context): bool|string|Template|TemplateWrapper
    {
        // line 3
        return "_includes/forms/componentSelect.twig";
    }

    protected function doDisplay(array $context, array $blocks = []): iterable
    {
        $macros = $this->macros;
        craft\helpers\Template::beginProfile("template", "_includes/forms/entryTypeSelect");
        $this->parent = $this->loadTemplate("_includes/forms/componentSelect.twig", "_includes/forms/entryTypeSelect", 3);
        yield from $this->parent->unwrap()->yield($context, array_merge($this->blocks, $blocks));
        craft\helpers\Template::endProfile("template", "_includes/forms/entryTypeSelect");
    }

    // line 14
    /**
     * @return iterable<null|scalar|\Stringable>
     */
    public function block_chips(array $context, array $blocks = []): iterable
    {
        $macros = $this->macros;
        craft\helpers\Template::beginProfile("block", "chips");
        // line 15
        yield "    ";
        $context['_parent'] = $context;
        $context['_seq'] = CoreExtension::ensureTraversable((isset($context["values"]) || array_key_exists("values", $context) ? $context["values"] : (function () { throw new RuntimeError('Variable "values" does not exist.', 15, $this->source); })()));
        foreach ($context['_seq'] as $context["_key"] => $context["entryType"]) {
            // line 16
            yield "      ";
            $context["overrides"] = (((isset($context["allowOverrides"]) || array_key_exists("allowOverrides", $context) ? $context["allowOverrides"] : (function () { throw new RuntimeError('Variable "allowOverrides" does not exist.', 16, $this->source); })())) ? ($this->extensions['craft\web\twig\Extension']->filterFilter($this->env, ["name" => (((craft\helpers\Template::attribute($this->env, $this->source,             // line 17
$context["entryType"], "original", [], "any", false, false, false, 17) && (craft\helpers\Template::attribute($this->env, $this->source, $context["entryType"], "name", [], "any", false, false, false, 17) != craft\helpers\Template::attribute($this->env, $this->source, craft\helpers\Template::attribute($this->env, $this->source, $context["entryType"], "original", [], "any", false, false, false, 17), "name", [], "any", false, false, false, 17)))) ? (craft\helpers\Template::attribute($this->env, $this->source, $context["entryType"], "name", [], "any", false, false, false, 17)) : (null)), "handle" => (((craft\helpers\Template::attribute($this->env, $this->source,             // line 18
$context["entryType"], "original", [], "any", false, false, false, 18) && (craft\helpers\Template::attribute($this->env, $this->source, $context["entryType"], "handle", [], "any", false, false, false, 18) != craft\helpers\Template::attribute($this->env, $this->source, craft\helpers\Template::attribute($this->env, $this->source, $context["entryType"], "original", [], "any", false, false, false, 18), "handle", [], "any", false, false, false, 18)))) ? (craft\helpers\Template::attribute($this->env, $this->source, $context["entryType"], "handle", [], "any", false, false, false, 18)) : (null)), "description" => (((craft\helpers\Template::attribute($this->env, $this->source,             // line 19
$context["entryType"], "original", [], "any", false, false, false, 19) && (craft\helpers\Template::attribute($this->env, $this->source, $context["entryType"], "description", [], "any", false, false, false, 19) != craft\helpers\Template::attribute($this->env, $this->source, craft\helpers\Template::attribute($this->env, $this->source, $context["entryType"], "original", [], "any", false, false, false, 19), "description", [], "any", false, false, false, 19)))) ? (craft\helpers\Template::attribute($this->env, $this->source, $context["entryType"], "description", [], "any", false, false, false, 19)) : (null))])) : ([]));
            // line 21
            yield "      <li>
        ";
            // line 22
            $context["chip"] = craft\helpers\Cp::chipHtml($context["entryType"], ["inputName" => ((            // line 23
$context["inputName"]) ?? ((($context["name"]) ?? (null)))), "inputValue" => ((            // line 24
(isset($context["allowOverrides"]) || array_key_exists("allowOverrides", $context) ? $context["allowOverrides"] : (function () { throw new RuntimeError('Variable "allowOverrides" does not exist.', 24, $this->source); })())) ? ($this->extensions['craft\web\twig\Extension']->jsonEncodeFilter($this->extensions['craft\web\twig\Extension']->mergeFilter($this->extensions['craft\web\twig\Extension']->filterFilter($this->env, ["id" => craft\helpers\Template::attribute($this->env, $this->source,             // line 25
$context["entryType"], "id", [], "any", false, false, false, 25), "group" => ((((            // line 26
$context["includeGroupInValues"]) ?? (false))) ? ((((craft\helpers\Template::attribute($this->env, $this->source, $context["entryType"], "group", [], "any", true, true, false, 26) &&  !(null === craft\helpers\Template::attribute($this->env, $this->source, $context["entryType"], "group", [], "any", false, false, false, 26)))) ? (craft\helpers\Template::attribute($this->env, $this->source, $context["entryType"], "group", [], "any", false, false, false, 26)) : ($this->extensions['craft\web\twig\Extension']->translateFilter("General", "app")))) : (null))]),             // line 27
(isset($context["overrides"]) || array_key_exists("overrides", $context) ? $context["overrides"] : (function () { throw new RuntimeError('Variable "overrides" does not exist.', 27, $this->source); })())))) : (null)), "checkbox" => ((            // line 28
$context["selectable"]) ?? (false)), "showActionMenu" =>             // line 29
(isset($context["showActionMenus"]) || array_key_exists("showActionMenus", $context) ? $context["showActionMenus"] : (function () { throw new RuntimeError('Variable "showActionMenus" does not exist.', 29, $this->source); })()), "showHandle" =>             // line 30
(isset($context["showHandles"]) || array_key_exists("showHandles", $context) ? $context["showHandles"] : (function () { throw new RuntimeError('Variable "showHandles" does not exist.', 30, $this->source); })()), "showIndicators" =>             // line 31
(isset($context["showIndicators"]) || array_key_exists("showIndicators", $context) ? $context["showIndicators"] : (function () { throw new RuntimeError('Variable "showIndicators" does not exist.', 31, $this->source); })()), "showDescription" =>             // line 32
(isset($context["showDescription"]) || array_key_exists("showDescription", $context) ? $context["showDescription"] : (function () { throw new RuntimeError('Variable "showDescription" does not exist.', 32, $this->source); })()), "hyperlink" =>             // line 33
(isset($context["hyperlinks"]) || array_key_exists("hyperlinks", $context) ? $context["hyperlinks"] : (function () { throw new RuntimeError('Variable "hyperlinks" does not exist.', 33, $this->source); })()), "overrides" =>             // line 34
(isset($context["overrides"]) || array_key_exists("overrides", $context) ? $context["overrides"] : (function () { throw new RuntimeError('Variable "overrides" does not exist.', 34, $this->source); })())]);
            // line 36
            yield "        ";
            if ((isset($context["disabled"]) || array_key_exists("disabled", $context) ? $context["disabled"] : (function () { throw new RuntimeError('Variable "disabled" does not exist.', 36, $this->source); })())) {
                // line 37
                yield "          ";
                $context["chip"] = $this->extensions['craft\web\twig\Extension']->removeClassFilter((isset($context["chip"]) || array_key_exists("chip", $context) ? $context["chip"] : (function () { throw new RuntimeError('Variable "chip" does not exist.', 37, $this->source); })()), "removable");
                // line 38
                yield "        ";
            }
            // line 39
            yield "        ";
            yield (isset($context["chip"]) || array_key_exists("chip", $context) ? $context["chip"] : (function () { throw new RuntimeError('Variable "chip" does not exist.', 39, $this->source); })());
            yield "
      </li>
    ";
        }
        $_parent = $context['_parent'];
        unset($context['_seq'], $context['_key'], $context['entryType'], $context['_parent']);
        $context = array_intersect_key($context, $_parent) + $_parent;
        // line 42
        yield "  ";
        craft\helpers\Template::endProfile("block", "chips");
        yield from [];
    }

    /**
     * @codeCoverageIgnore
     */
    public function getTemplateName(): string
    {
        return "_includes/forms/entryTypeSelect";
    }

    /**
     * @codeCoverageIgnore
     */
    public function isTraitable(): bool
    {
        return false;
    }

    /**
     * @codeCoverageIgnore
     */
    public function getDebugInfo(): array
    {
        return array (  225 => 42,  215 => 39,  212 => 38,  209 => 37,  206 => 36,  204 => 34,  203 => 33,  202 => 32,  201 => 31,  200 => 30,  199 => 29,  198 => 28,  197 => 27,  196 => 26,  195 => 25,  194 => 24,  193 => 23,  192 => 22,  189 => 21,  187 => 19,  186 => 18,  185 => 17,  183 => 16,  178 => 15,  170 => 14,  157 => 3,  55 => 12,  54 => 11,  53 => 9,  52 => 8,  51 => 7,  50 => 6,  49 => 4,  48 => 3,  45 => 2,  43 => 1,);
    }

    public function getSourceContext(): Source
    {
        return new Source("{% set allowOverrides = allowOverrides ?? false %}

{% embed '_includes/forms/componentSelect.twig' with {
  options: options ?? craft.app.entries.getAllEntryTypes(),
  showHandles: true,
  showIndicators: showIndicators ?? allowOverrides,
  showDescription: showDescription ?? allowOverrides,
  createAction: (create ?? false) ? 'entry-types/edit' : null,
  jsClass: jsClass ?? 'Craft.EntryTypeSelectInput',
  jsSettings: {
    allowOverrides,
  }|merge(jsSettings ?? {}),
} %}
  {% block chips %}
    {% for entryType in values %}
      {% set overrides = allowOverrides ? {
        name: entryType.original and entryType.name != entryType.original.name ? entryType.name : null,
        handle: entryType.original and entryType.handle != entryType.original.handle ? entryType.handle : null,
        description: entryType.original and entryType.description != entryType.original.description ? entryType.description : null,
      }|filter : {} %}
      <li>
        {% set chip = chip(entryType, {
          inputName: inputName ?? name ?? null,
          inputValue: allowOverrides ? {
            id: entryType.id,
            group: (includeGroupInValues ?? false) ? (entryType.group ?? 'General'|t('app')) : null,
          }|filter|merge(overrides)|json_encode : null,
          checkbox: selectable ?? false,
          showActionMenu: showActionMenus,
          showHandle: showHandles,
          showIndicators: showIndicators,
          showDescription: showDescription,
          hyperlink: hyperlinks,
          overrides,
        }) %}
        {% if disabled %}
          {% set chip = chip|removeClass('removable') %}
        {% endif %}
        {{ chip|raw }}
      </li>
    {% endfor %}
  {% endblock %}
{% endembed %}
", "_includes/forms/entryTypeSelect", "/var/www/html/backend/vendor/craftcms/cms/src/templates/_includes/forms/entryTypeSelect.twig");
    }
}

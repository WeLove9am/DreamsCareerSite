<?php

use Twig\Environment;
use Twig\Error\LoaderError;
use Twig\Error\RuntimeError;
use Twig\Extension\CoreExtension;
use Twig\Extension\SandboxExtension;
use Twig\Markup;
use Twig\Sandbox\SecurityError;
use Twig\Sandbox\SecurityNotAllowedTagError;
use Twig\Sandbox\SecurityNotAllowedFilterError;
use Twig\Sandbox\SecurityNotAllowedFunctionError;
use Twig\Source;
use Twig\Template;
use Twig\TemplateWrapper;

/* _includes/forms/copytext */
class __TwigTemplate_db662879f9b6a66fdd9902a437804de2 extends Template
{
    private Source $source;
    /**
     * @var array<string, Template>
     */
    private array $macros = [];

    public function __construct(Environment $env)
    {
        parent::__construct($env);

        $this->source = $this->getSourceContext();

        $this->parent = false;

        $this->blocks = [
            'js' => [$this, 'block_js'],
        ];
    }

    protected function doDisplay(array $context, array $blocks = []): iterable
    {
        $macros = $this->macros;
        craft\helpers\Template::beginProfile("template", "_includes/forms/copytext");
        // line 1
        $context["id"] = (($context["id"]) ?? (("copytext" . Twig\Extension\CoreExtension::random($this->env->getCharset()))));
        // line 2
        $context["buttonId"] = (($context["buttonId"]) ?? (((isset($context["id"]) || array_key_exists("id", $context) ? $context["id"] : (function () { throw new RuntimeError('Variable "id" does not exist.', 2, $this->source); })()) . "-btn")));
        // line 4
        yield "<div class=\"copytext\">";
        // line 5
        yield from $this->loadTemplate("_includes/forms/text", "_includes/forms/copytext", 5)->unwrap()->yield(CoreExtension::merge($context, ["readonly" => true]));
        // line 8
        yield $this->extensions['craft\web\twig\Extension']->tagFunction("button", ["type" => "button", "id" =>         // line 10
(isset($context["buttonId"]) || array_key_exists("buttonId", $context) ? $context["buttonId"] : (function () { throw new RuntimeError('Variable "buttonId" does not exist.', 10, $this->source); })()), "class" => $this->extensions['craft\web\twig\Extension']->pushFilter(craft\helpers\Html::explodeClass(((        // line 11
$context["buttonClass"]) ?? ([]))), "btn"), "title" => $this->extensions['craft\web\twig\Extension']->translateFilter("Copy to clipboard", "app"), "aria" => ["label" => $this->extensions['craft\web\twig\Extension']->translateFilter("Copy to clipboard", "app"), "describedby" => ((        // line 15
$context["describedBy"]) ?? (false))], "data" => ["icon" => "clipboard"]]);
        // line 21
        yield "</div>

";
        // line 23
        ob_start();
        // line 24
        yield "    ";
        yield from $this->unwrap()->yieldBlock('js', $context, $blocks);
        craft\helpers\Template::js(ob_get_clean(), ['position' => 3]);
        craft\helpers\Template::endProfile("template", "_includes/forms/copytext");
        yield from [];
    }

    /**
     * @return iterable<null|scalar|\Stringable>
     */
    public function block_js(array $context, array $blocks = []): iterable
    {
        $macros = $this->macros;
        craft\helpers\Template::beginProfile("block", "js");
        // line 25
        yield "        \$('#";
        yield $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($this->env->getFilter('namespaceInputId')->getCallable()((isset($context["buttonId"]) || array_key_exists("buttonId", $context) ? $context["buttonId"] : (function () { throw new RuntimeError('Variable "buttonId" does not exist.', 25, $this->source); })())), "js"), "html", null, true);
        yield "').on('click', function() {
            document.getElementById('";
        // line 26
        yield $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($this->env->getFilter('namespaceInputId')->getCallable()((isset($context["id"]) || array_key_exists("id", $context) ? $context["id"] : (function () { throw new RuntimeError('Variable "id" does not exist.', 26, $this->source); })())), "js"), "html", null, true);
        yield "').select();
            document.execCommand('copy');
            Craft.cp.displayNotice(\"";
        // line 28
        yield $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($this->extensions['craft\web\twig\Extension']->translateFilter("Copied to clipboard.", "app"), "js"), "html", null, true);
        yield "\");
            \$(this).parent().trigger('copy');
            document.getElementById('";
        // line 30
        yield $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($this->env->getFilter('namespaceInputId')->getCallable()((isset($context["id"]) || array_key_exists("id", $context) ? $context["id"] : (function () { throw new RuntimeError('Variable "id" does not exist.', 30, $this->source); })())), "js"), "html", null, true);
        yield "').setSelectionRange(0, 0);
            \$(this).focus();
        });
    ";
        craft\helpers\Template::endProfile("block", "js");
        yield from [];
    }

    /**
     * @codeCoverageIgnore
     */
    public function getTemplateName(): string
    {
        return "_includes/forms/copytext";
    }

    /**
     * @codeCoverageIgnore
     */
    public function isTraitable(): bool
    {
        return false;
    }

    /**
     * @codeCoverageIgnore
     */
    public function getDebugInfo(): array
    {
        return array (  93 => 30,  88 => 28,  83 => 26,  78 => 25,  63 => 24,  61 => 23,  57 => 21,  55 => 15,  54 => 11,  53 => 10,  52 => 8,  50 => 5,  48 => 4,  46 => 2,  44 => 1,);
    }

    public function getSourceContext(): Source
    {
        return new Source("{% set id = id ?? \"copytext#{random()}\" %}
{% set buttonId = buttonId ?? \"#{id}-btn\" -%}

<div class=\"copytext\">
    {%- include '_includes/forms/text' with {
        readonly: true,
    } %}
    {{- tag('button', {
        type: 'button',
        id: buttonId,
        class: (buttonClass ?? [])|explodeClass|push('btn'),
        title: 'Copy to clipboard'|t('app'),
        aria: {
            label: 'Copy to clipboard'|t('app'),
            describedby: describedBy ?? false,
        },
        data: {
            icon: 'clipboard',
        },
    }) -}}
</div>

{% js %}
    {% block js %}
        \$('#{{ buttonId|namespaceInputId|e('js') }}').on('click', function() {
            document.getElementById('{{ id|namespaceInputId|e('js') }}').select();
            document.execCommand('copy');
            Craft.cp.displayNotice(\"{{ 'Copied to clipboard.'|t('app')|e('js') }}\");
            \$(this).parent().trigger('copy');
            document.getElementById('{{ id|namespaceInputId|e('js') }}').setSelectionRange(0, 0);
            \$(this).focus();
        });
    {% endblock %}
{% endjs %}
", "_includes/forms/copytext", "/var/www/html/backend/vendor/craftcms/cms/src/templates/_includes/forms/copytext.twig");
    }
}

<?php

use Twig\Environment;
use Twig\Error\LoaderError;
use Twig\Error\RuntimeError;
use Twig\Extension\CoreExtension;
use Twig\Extension\SandboxExtension;
use Twig\Markup;
use Twig\Sandbox\SecurityError;
use Twig\Sandbox\SecurityNotAllowedTagError;
use Twig\Sandbox\SecurityNotAllowedFilterError;
use Twig\Sandbox\SecurityNotAllowedFunctionError;
use Twig\Source;
use Twig\Template;
use Twig\TemplateWrapper;

/* graphql/tokens/_edit.twig */
class __TwigTemplate_ea24362474851a114625aab08ae5a4bb extends Template
{
    private Source $source;
    /**
     * @var array<string, Template>
     */
    private array $macros = [];

    public function __construct(Environment $env)
    {
        parent::__construct($env);

        $this->source = $this->getSourceContext();

        $this->blocks = [
            'content' => [$this, 'block_content'],
            'details' => [$this, 'block_details'],
        ];
    }

    protected function doGetParent(array $context): bool|string|Template|TemplateWrapper
    {
        // line 1
        return "_layouts/cp";
    }

    protected function doDisplay(array $context, array $blocks = []): iterable
    {
        $macros = $this->macros;
        craft\helpers\Template::beginProfile("template", "graphql/tokens/_edit.twig");
        // line 3
        $context["selectedSubnavItem"] = "tokens";
        // line 5
        $context["fullPageForm"] = true;
        // line 7
        $context["crumbs"] = [["label" => $this->extensions['craft\web\twig\Extension']->translateFilter("GraphQL Tokens", "app"), "url" => craft\helpers\UrlHelper::url("graphql/tokens")]];
        // line 11
        $macros["forms"] = $this->macros["forms"] = $this->loadTemplate("_includes/forms", "graphql/tokens/_edit.twig", 11)->unwrap();
        // line 100
        ob_start();
        // line 101
        yield "    var \$headerInput = \$('#auth-header');
    var \$tokenInput = \$('#access-token');
    var \$regenBtn = \$('#regen-btn');
    var regenerating = false;

    function copyHeader() {
        \$headerInput[0].select();
        document.execCommand('copy');
        Craft.cp.displayNotice(\"";
        // line 109
        yield $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($this->extensions['craft\web\twig\Extension']->translateFilter("Copied to clipboard.", "app"), "js"), "html", null, true);
        yield "\");
    }

    \$headerInput.on('click', function() {
        if (!\$headerInput.hasClass('disabled')) {
            this.select();
        }
    });

    \$('#copy-btn').on('click', function() {
        if (!\$headerInput.hasClass('disabled')) {
            copyHeader();
        } else {
            Craft.elevatedSessionManager.requireElevatedSession(function() {
            \$('#token-spinner').removeClass('hidden');
            var data = ";
        // line 124
        yield $this->extensions['craft\web\twig\Extension']->jsonEncodeFilter(["tokenUid" => craft\helpers\Template::attribute($this->env, $this->source, (isset($context["token"]) || array_key_exists("token", $context) ? $context["token"] : (function () { throw new RuntimeError('Variable "token" does not exist.', 124, $this->source); })()), "uid", [], "any", false, false, false, 124)]);
        yield ";
            Craft.sendActionRequest('POST', 'graphql/fetch-token', {data})
                .then((response) => {
                    \$('#token-spinner').addClass('hidden');
                    \$headerInput
                        .val('Authorization: Bearer ' + response.data.accessToken)
                        .removeClass('disabled');
                    copyHeader();
                })
                .finally(() => {
                    \$('#token-spinner').addClass('hidden');
                });
            });
        }
    });

    \$regenBtn.on('click', function() {
        if (regenerating) {
            return;
        }
        regenerating = true;
        \$('#token-spinner').removeClass('hidden');
        \$regenBtn.addClass('active');

        Craft.sendActionRequest('POST', 'graphql/generate-token')
            .then((response) => {
                \$headerInput
                    .val('Authorization: Bearer ' + response.data.accessToken)
                    .removeClass('disabled');
                \$tokenInput
                    .val(response.data.accessToken)
                    .prop('disabled', false);
                \$regenBtn.removeClass('active');
                regenerating = false;
            })
            .finally(() => {
                \$('#token-spinner').addClass('hidden');
            });
        });

    new Craft.ElevatedSessionForm('#main-form');
";
        craft\helpers\Template::js(ob_get_clean(), ['position' => 3]);
        // line 1
        $this->parent = $this->loadTemplate("_layouts/cp", "graphql/tokens/_edit.twig", 1);
        yield from $this->parent->unwrap()->yield($context, array_merge($this->blocks, $blocks));
        craft\helpers\Template::endProfile("template", "graphql/tokens/_edit.twig");
    }

    // line 13
    /**
     * @return iterable<null|scalar|\Stringable>
     */
    public function block_content(array $context, array $blocks = []): iterable
    {
        $macros = $this->macros;
        craft\helpers\Template::beginProfile("block", "content");
        // line 14
        yield "    <input type=\"hidden\" name=\"action\" value=\"graphql/save-token\">
    ";
        // line 15
        yield craft\helpers\Html::redirectInput("graphql/tokens");
        yield "
    ";
        // line 16
        if (craft\helpers\Template::attribute($this->env, $this->source, (isset($context["token"]) || array_key_exists("token", $context) ? $context["token"] : (function () { throw new RuntimeError('Variable "token" does not exist.', 16, $this->source); })()), "id", [], "any", false, false, false, 16)) {
            yield "<input type=\"hidden\" name=\"tokenId\" value=\"";
            yield $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape(craft\helpers\Template::attribute($this->env, $this->source, (isset($context["token"]) || array_key_exists("token", $context) ? $context["token"] : (function () { throw new RuntimeError('Variable "token" does not exist.', 16, $this->source); })()), "id", [], "any", false, false, false, 16), "html", null, true);
            yield "\">";
        }
        // line 17
        yield "
    ";
        // line 18
        yield $macros["forms"]->getTemplateForMacro("macro_textField", $context, 18, $this->getSourceContext())->macro_textField(...[["first" => true, "label" => $this->extensions['craft\web\twig\Extension']->translateFilter("Name", "app"), "instructions" => $this->extensions['craft\web\twig\Extension']->translateFilter("What this token will be called in the control panel.", "app"), "id" => "name", "name" => "name", "value" => craft\helpers\Template::attribute($this->env, $this->source,         // line 24
(isset($context["token"]) || array_key_exists("token", $context) ? $context["token"] : (function () { throw new RuntimeError('Variable "token" does not exist.', 24, $this->source); })()), "name", [], "any", false, false, false, 24), "errors" => craft\helpers\Template::attribute($this->env, $this->source,         // line 25
(isset($context["token"]) || array_key_exists("token", $context) ? $context["token"] : (function () { throw new RuntimeError('Variable "token" does not exist.', 25, $this->source); })()), "getErrors", ["name"], "method", false, false, false, 25), "autofocus" => true, "required" => true]]);
        // line 28
        yield "

    ";
        // line 30
        $context["schemaInput"] = (((isset($context["schemaOptions"]) || array_key_exists("schemaOptions", $context) ? $context["schemaOptions"] : (function () { throw new RuntimeError('Variable "schemaOptions" does not exist.', 30, $this->source); })())) ? ($macros["forms"]->getTemplateForMacro("macro_selectField", $context, 31, $this->getSourceContext())->macro_selectField(...[["name" => "schema", "id" => "schema", "options" =>         // line 34
(isset($context["schemaOptions"]) || array_key_exists("schemaOptions", $context) ? $context["schemaOptions"] : (function () { throw new RuntimeError('Variable "schemaOptions" does not exist.', 34, $this->source); })()), "value" => craft\helpers\Template::attribute($this->env, $this->source,         // line 35
(isset($context["token"]) || array_key_exists("token", $context) ? $context["token"] : (function () { throw new RuntimeError('Variable "token" does not exist.', 35, $this->source); })()), "schemaId", [], "any", false, false, false, 35)]])) : ($this->extensions['craft\web\twig\Extension']->tagFunction("p", ["class" => ["warning", "with-icon"], "text" => $this->extensions['craft\web\twig\Extension']->translateFilter("No schemas exist yet to assign to this token.", "app")])));
        // line 42
        yield "
    ";
        // line 43
        yield $macros["forms"]->getTemplateForMacro("macro_field", $context, 43, $this->getSourceContext())->macro_field(...[["id" => "schema", "label" => "GraphQL Schema", "instructions" => "Choose which GraphQL schema this token has access to."],         // line 47
(isset($context["schemaInput"]) || array_key_exists("schemaInput", $context) ? $context["schemaInput"] : (function () { throw new RuntimeError('Variable "schemaInput" does not exist.', 47, $this->source); })())]);
        yield "

    <hr>

    ";
        // line 51
        yield from $this->loadTemplate("graphql/tokens/_edit.twig", "graphql/tokens/_edit.twig", 51, "362255219")->unwrap()->yield(CoreExtension::merge($context, ["label" => $this->extensions['craft\web\twig\Extension']->translateFilter("Authorization Header", "app"), "instructions" => $this->extensions['craft\web\twig\Extension']->translateFilter("The `Authorization` header that should be sent with GraphQL API requests to use this token.", "app"), "id" => "auth-header"]));
        craft\helpers\Template::endProfile("block", "content");
        yield from [];
    }

    // line 81
    /**
     * @return iterable<null|scalar|\Stringable>
     */
    public function block_details(array $context, array $blocks = []): iterable
    {
        $macros = $this->macros;
        craft\helpers\Template::beginProfile("block", "details");
        // line 82
        yield "    <div class=\"meta\">
        ";
        // line 83
        yield $macros["forms"]->getTemplateForMacro("macro_lightswitchField", $context, 83, $this->getSourceContext())->macro_lightswitchField(...[["label" => $this->extensions['craft\web\twig\Extension']->translateFilter("Enabled", "app"), "id" => "enabled", "name" => "enabled", "on" => craft\helpers\Template::attribute($this->env, $this->source,         // line 87
(isset($context["token"]) || array_key_exists("token", $context) ? $context["token"] : (function () { throw new RuntimeError('Variable "token" does not exist.', 87, $this->source); })()), "enabled", [], "any", false, false, false, 87)]]);
        // line 88
        yield "

        ";
        // line 90
        yield $macros["forms"]->getTemplateForMacro("macro_dateTimeField", $context, 90, $this->getSourceContext())->macro_dateTimeField(...[["label" => $this->extensions['craft\web\twig\Extension']->translateFilter("Expiry Date", "app"), "id" => "expiryDate", "name" => "expiryDate", "value" => ((craft\helpers\Template::attribute($this->env, $this->source,         // line 94
(isset($context["token"]) || array_key_exists("token", $context) ? $context["token"] : (function () { throw new RuntimeError('Variable "token" does not exist.', 94, $this->source); })()), "expiryDate", [], "any", false, false, false, 94)) ? (craft\helpers\Template::attribute($this->env, $this->source, (isset($context["token"]) || array_key_exists("token", $context) ? $context["token"] : (function () { throw new RuntimeError('Variable "token" does not exist.', 94, $this->source); })()), "expiryDate", [], "any", false, false, false, 94)) : (null)), "errors" => craft\helpers\Template::attribute($this->env, $this->source,         // line 95
(isset($context["token"]) || array_key_exists("token", $context) ? $context["token"] : (function () { throw new RuntimeError('Variable "token" does not exist.', 95, $this->source); })()), "getErrors", ["expiryDate"], "method", false, false, false, 95)]]);
        // line 96
        yield "
    </div>
";
        craft\helpers\Template::endProfile("block", "details");
        yield from [];
    }

    /**
     * @codeCoverageIgnore
     */
    public function getTemplateName(): string
    {
        return "graphql/tokens/_edit.twig";
    }

    /**
     * @codeCoverageIgnore
     */
    public function isTraitable(): bool
    {
        return false;
    }

    /**
     * @codeCoverageIgnore
     */
    public function getDebugInfo(): array
    {
        return array (  213 => 96,  211 => 95,  210 => 94,  209 => 90,  205 => 88,  203 => 87,  202 => 83,  199 => 82,  191 => 81,  185 => 51,  178 => 47,  177 => 43,  174 => 42,  172 => 35,  171 => 34,  170 => 30,  166 => 28,  164 => 25,  163 => 24,  162 => 18,  159 => 17,  153 => 16,  149 => 15,  146 => 14,  138 => 13,  132 => 1,  87 => 124,  69 => 109,  59 => 101,  57 => 100,  55 => 11,  53 => 7,  51 => 5,  49 => 3,  41 => 1,);
    }

    public function getSourceContext(): Source
    {
        return new Source("{% extends \"_layouts/cp\" %}

{% set selectedSubnavItem = 'tokens' %}

{% set fullPageForm = true %}

{% set crumbs = [
    { label: \"GraphQL Tokens\"|t('app'), url: url('graphql/tokens') }
] %}

{% import \"_includes/forms\" as forms %}

{% block content %}
    <input type=\"hidden\" name=\"action\" value=\"graphql/save-token\">
    {{ redirectInput('graphql/tokens') }}
    {% if token.id %}<input type=\"hidden\" name=\"tokenId\" value=\"{{ token.id }}\">{% endif %}

    {{ forms.textField({
        first: true,
        label: \"Name\"|t('app'),
        instructions: \"What this token will be called in the control panel.\"|t('app'),
        id: 'name',
        name: 'name',
        value: token.name,
        errors: token.getErrors('name'),
        autofocus: true,
        required: true,
    }) }}

    {% set schemaInput = schemaOptions
        ? forms.selectField({
            name: 'schema',
            id: 'schema',
            options: schemaOptions,
            value: token.schemaId,
        })
        : tag('p', {
            class: ['warning', 'with-icon'],
            text: 'No schemas exist yet to assign to this token.'|t('app'),
        })
    %}

    {{ forms.field({
        id: 'schema',
        label: 'GraphQL Schema',
        instructions: 'Choose which GraphQL schema this token has access to.',
    }, schemaInput) }}

    <hr>

    {% embed '_includes/forms/field' with {
        label: 'Authorization Header'|t('app'),
        instructions: 'The `Authorization` header that should be sent with GraphQL API requests to use this token.'|t('app'),
        id: 'auth-header',
    } %}
        {% block input %}
            {% import '_includes/forms' as forms %}
            <div class=\"flex\">
                {% embed '_includes/forms/copytext' with {
                    id: 'auth-header',
                    buttonId: 'copy-btn',
                    value: 'Authorization: Bearer ' ~ (accessToken ?? '••••••••••••••••••••••••••••••••'),
                    errors: token.getErrors('accessToken'),
                    class: ['code', not accessToken ? 'disabled']|filter,
                    size: 54,
                } %}
                    {# don't register the default JS #}
                    {% block js %}{% endblock %}
                {% endembed %}
                {{ hiddenInput('accessToken', accessToken, {
                    id: 'access-token',
                    disabled: not accessToken,
                }) }}
                <button type=\"button\" id=\"regen-btn\" class=\"btn\">{{ 'Regenerate'|t('app') }}</button>
                <div id=\"token-spinner\" class=\"spinner hidden\"></div>
            </div>
        {% endblock %}
    {% endembed %}
{% endblock %}

{% block details %}
    <div class=\"meta\">
        {{ forms.lightswitchField({
            label: 'Enabled'|t('app'),
            id: 'enabled',
            name: 'enabled',
            on: token.enabled,
        }) }}

        {{ forms.dateTimeField({
            label: \"Expiry Date\"|t('app'),
            id: 'expiryDate',
            name: 'expiryDate',
            value: (token.expiryDate ? token.expiryDate : null),
            errors: token.getErrors('expiryDate')
        }) }}
    </div>
{% endblock %}

{% js %}
    var \$headerInput = \$('#auth-header');
    var \$tokenInput = \$('#access-token');
    var \$regenBtn = \$('#regen-btn');
    var regenerating = false;

    function copyHeader() {
        \$headerInput[0].select();
        document.execCommand('copy');
        Craft.cp.displayNotice(\"{{ 'Copied to clipboard.'|t('app')|e('js') }}\");
    }

    \$headerInput.on('click', function() {
        if (!\$headerInput.hasClass('disabled')) {
            this.select();
        }
    });

    \$('#copy-btn').on('click', function() {
        if (!\$headerInput.hasClass('disabled')) {
            copyHeader();
        } else {
            Craft.elevatedSessionManager.requireElevatedSession(function() {
            \$('#token-spinner').removeClass('hidden');
            var data = {{ {tokenUid: token.uid}|json_encode|raw }};
            Craft.sendActionRequest('POST', 'graphql/fetch-token', {data})
                .then((response) => {
                    \$('#token-spinner').addClass('hidden');
                    \$headerInput
                        .val('Authorization: Bearer ' + response.data.accessToken)
                        .removeClass('disabled');
                    copyHeader();
                })
                .finally(() => {
                    \$('#token-spinner').addClass('hidden');
                });
            });
        }
    });

    \$regenBtn.on('click', function() {
        if (regenerating) {
            return;
        }
        regenerating = true;
        \$('#token-spinner').removeClass('hidden');
        \$regenBtn.addClass('active');

        Craft.sendActionRequest('POST', 'graphql/generate-token')
            .then((response) => {
                \$headerInput
                    .val('Authorization: Bearer ' + response.data.accessToken)
                    .removeClass('disabled');
                \$tokenInput
                    .val(response.data.accessToken)
                    .prop('disabled', false);
                \$regenBtn.removeClass('active');
                regenerating = false;
            })
            .finally(() => {
                \$('#token-spinner').addClass('hidden');
            });
        });

    new Craft.ElevatedSessionForm('#main-form');
{% endjs %}
", "graphql/tokens/_edit.twig", "/var/www/html/backend/vendor/craftcms/cms/src/templates/graphql/tokens/_edit.twig");
    }
}


/* graphql/tokens/_edit.twig */
class __TwigTemplate_ea24362474851a114625aab08ae5a4bb___362255219 extends Template
{
    private Source $source;
    /**
     * @var array<string, Template>
     */
    private array $macros = [];

    public function __construct(Environment $env)
    {
        parent::__construct($env);

        $this->source = $this->getSourceContext();

        $this->blocks = [
            'input' => [$this, 'block_input'],
        ];
    }

    protected function doGetParent(array $context): bool|string|Template|TemplateWrapper
    {
        // line 51
        return "_includes/forms/field";
    }

    protected function doDisplay(array $context, array $blocks = []): iterable
    {
        $macros = $this->macros;
        craft\helpers\Template::beginProfile("template", "graphql/tokens/_edit.twig");
        $this->parent = $this->loadTemplate("_includes/forms/field", "graphql/tokens/_edit.twig", 51);
        yield from $this->parent->unwrap()->yield($context, array_merge($this->blocks, $blocks));
        craft\helpers\Template::endProfile("template", "graphql/tokens/_edit.twig");
    }

    // line 56
    /**
     * @return iterable<null|scalar|\Stringable>
     */
    public function block_input(array $context, array $blocks = []): iterable
    {
        $macros = $this->macros;
        craft\helpers\Template::beginProfile("block", "input");
        // line 57
        yield "            ";
        $macros["forms"] = $this->loadTemplate("_includes/forms", "graphql/tokens/_edit.twig", 57)->unwrap();
        // line 58
        yield "            <div class=\"flex\">
                ";
        // line 59
        yield from $this->loadTemplate("graphql/tokens/_edit.twig", "graphql/tokens/_edit.twig", 59, "945173035")->unwrap()->yield(CoreExtension::merge($context, ["id" => "auth-header", "buttonId" => "copy-btn", "value" => ("Authorization: Bearer " . ((        // line 62
$context["accessToken"]) ?? ("••••••••••••••••••••••••••••••••"))), "errors" => craft\helpers\Template::attribute($this->env, $this->source,         // line 63
(isset($context["token"]) || array_key_exists("token", $context) ? $context["token"] : (function () { throw new RuntimeError('Variable "token" does not exist.', 63, $this->source); })()), "getErrors", ["accessToken"], "method", false, false, false, 63), "class" => $this->extensions['craft\web\twig\Extension']->filterFilter($this->env, ["code", (( !        // line 64
(isset($context["accessToken"]) || array_key_exists("accessToken", $context) ? $context["accessToken"] : (function () { throw new RuntimeError('Variable "accessToken" does not exist.', 64, $this->source); })())) ? ("disabled") : (""))]), "size" => 54]));
        // line 70
        yield "                ";
        yield craft\helpers\Html::hiddenInput("accessToken", (isset($context["accessToken"]) || array_key_exists("accessToken", $context) ? $context["accessToken"] : (function () { throw new RuntimeError('Variable "accessToken" does not exist.', 70, $this->source); })()), ["id" => "access-token", "disabled" =>  !        // line 72
(isset($context["accessToken"]) || array_key_exists("accessToken", $context) ? $context["accessToken"] : (function () { throw new RuntimeError('Variable "accessToken" does not exist.', 72, $this->source); })())]);
        // line 73
        yield "
                <button type=\"button\" id=\"regen-btn\" class=\"btn\">";
        // line 74
        yield $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($this->extensions['craft\web\twig\Extension']->translateFilter("Regenerate", "app"), "html", null, true);
        yield "</button>
                <div id=\"token-spinner\" class=\"spinner hidden\"></div>
            </div>
        ";
        craft\helpers\Template::endProfile("block", "input");
        yield from [];
    }

    /**
     * @codeCoverageIgnore
     */
    public function getTemplateName(): string
    {
        return "graphql/tokens/_edit.twig";
    }

    /**
     * @codeCoverageIgnore
     */
    public function isTraitable(): bool
    {
        return false;
    }

    /**
     * @codeCoverageIgnore
     */
    public function getDebugInfo(): array
    {
        return array (  478 => 74,  475 => 73,  473 => 72,  471 => 70,  469 => 64,  468 => 63,  467 => 62,  466 => 59,  463 => 58,  460 => 57,  452 => 56,  439 => 51,  213 => 96,  211 => 95,  210 => 94,  209 => 90,  205 => 88,  203 => 87,  202 => 83,  199 => 82,  191 => 81,  185 => 51,  178 => 47,  177 => 43,  174 => 42,  172 => 35,  171 => 34,  170 => 30,  166 => 28,  164 => 25,  163 => 24,  162 => 18,  159 => 17,  153 => 16,  149 => 15,  146 => 14,  138 => 13,  132 => 1,  87 => 124,  69 => 109,  59 => 101,  57 => 100,  55 => 11,  53 => 7,  51 => 5,  49 => 3,  41 => 1,);
    }

    public function getSourceContext(): Source
    {
        return new Source("{% extends \"_layouts/cp\" %}

{% set selectedSubnavItem = 'tokens' %}

{% set fullPageForm = true %}

{% set crumbs = [
    { label: \"GraphQL Tokens\"|t('app'), url: url('graphql/tokens') }
] %}

{% import \"_includes/forms\" as forms %}

{% block content %}
    <input type=\"hidden\" name=\"action\" value=\"graphql/save-token\">
    {{ redirectInput('graphql/tokens') }}
    {% if token.id %}<input type=\"hidden\" name=\"tokenId\" value=\"{{ token.id }}\">{% endif %}

    {{ forms.textField({
        first: true,
        label: \"Name\"|t('app'),
        instructions: \"What this token will be called in the control panel.\"|t('app'),
        id: 'name',
        name: 'name',
        value: token.name,
        errors: token.getErrors('name'),
        autofocus: true,
        required: true,
    }) }}

    {% set schemaInput = schemaOptions
        ? forms.selectField({
            name: 'schema',
            id: 'schema',
            options: schemaOptions,
            value: token.schemaId,
        })
        : tag('p', {
            class: ['warning', 'with-icon'],
            text: 'No schemas exist yet to assign to this token.'|t('app'),
        })
    %}

    {{ forms.field({
        id: 'schema',
        label: 'GraphQL Schema',
        instructions: 'Choose which GraphQL schema this token has access to.',
    }, schemaInput) }}

    <hr>

    {% embed '_includes/forms/field' with {
        label: 'Authorization Header'|t('app'),
        instructions: 'The `Authorization` header that should be sent with GraphQL API requests to use this token.'|t('app'),
        id: 'auth-header',
    } %}
        {% block input %}
            {% import '_includes/forms' as forms %}
            <div class=\"flex\">
                {% embed '_includes/forms/copytext' with {
                    id: 'auth-header',
                    buttonId: 'copy-btn',
                    value: 'Authorization: Bearer ' ~ (accessToken ?? '••••••••••••••••••••••••••••••••'),
                    errors: token.getErrors('accessToken'),
                    class: ['code', not accessToken ? 'disabled']|filter,
                    size: 54,
                } %}
                    {# don't register the default JS #}
                    {% block js %}{% endblock %}
                {% endembed %}
                {{ hiddenInput('accessToken', accessToken, {
                    id: 'access-token',
                    disabled: not accessToken,
                }) }}
                <button type=\"button\" id=\"regen-btn\" class=\"btn\">{{ 'Regenerate'|t('app') }}</button>
                <div id=\"token-spinner\" class=\"spinner hidden\"></div>
            </div>
        {% endblock %}
    {% endembed %}
{% endblock %}

{% block details %}
    <div class=\"meta\">
        {{ forms.lightswitchField({
            label: 'Enabled'|t('app'),
            id: 'enabled',
            name: 'enabled',
            on: token.enabled,
        }) }}

        {{ forms.dateTimeField({
            label: \"Expiry Date\"|t('app'),
            id: 'expiryDate',
            name: 'expiryDate',
            value: (token.expiryDate ? token.expiryDate : null),
            errors: token.getErrors('expiryDate')
        }) }}
    </div>
{% endblock %}

{% js %}
    var \$headerInput = \$('#auth-header');
    var \$tokenInput = \$('#access-token');
    var \$regenBtn = \$('#regen-btn');
    var regenerating = false;

    function copyHeader() {
        \$headerInput[0].select();
        document.execCommand('copy');
        Craft.cp.displayNotice(\"{{ 'Copied to clipboard.'|t('app')|e('js') }}\");
    }

    \$headerInput.on('click', function() {
        if (!\$headerInput.hasClass('disabled')) {
            this.select();
        }
    });

    \$('#copy-btn').on('click', function() {
        if (!\$headerInput.hasClass('disabled')) {
            copyHeader();
        } else {
            Craft.elevatedSessionManager.requireElevatedSession(function() {
            \$('#token-spinner').removeClass('hidden');
            var data = {{ {tokenUid: token.uid}|json_encode|raw }};
            Craft.sendActionRequest('POST', 'graphql/fetch-token', {data})
                .then((response) => {
                    \$('#token-spinner').addClass('hidden');
                    \$headerInput
                        .val('Authorization: Bearer ' + response.data.accessToken)
                        .removeClass('disabled');
                    copyHeader();
                })
                .finally(() => {
                    \$('#token-spinner').addClass('hidden');
                });
            });
        }
    });

    \$regenBtn.on('click', function() {
        if (regenerating) {
            return;
        }
        regenerating = true;
        \$('#token-spinner').removeClass('hidden');
        \$regenBtn.addClass('active');

        Craft.sendActionRequest('POST', 'graphql/generate-token')
            .then((response) => {
                \$headerInput
                    .val('Authorization: Bearer ' + response.data.accessToken)
                    .removeClass('disabled');
                \$tokenInput
                    .val(response.data.accessToken)
                    .prop('disabled', false);
                \$regenBtn.removeClass('active');
                regenerating = false;
            })
            .finally(() => {
                \$('#token-spinner').addClass('hidden');
            });
        });

    new Craft.ElevatedSessionForm('#main-form');
{% endjs %}
", "graphql/tokens/_edit.twig", "/var/www/html/backend/vendor/craftcms/cms/src/templates/graphql/tokens/_edit.twig");
    }
}


/* graphql/tokens/_edit.twig */
class __TwigTemplate_ea24362474851a114625aab08ae5a4bb___945173035 extends Template
{
    private Source $source;
    /**
     * @var array<string, Template>
     */
    private array $macros = [];

    public function __construct(Environment $env)
    {
        parent::__construct($env);

        $this->source = $this->getSourceContext();

        $this->blocks = [
            'js' => [$this, 'block_js'],
        ];
    }

    protected function doGetParent(array $context): bool|string|Template|TemplateWrapper
    {
        // line 59
        return "_includes/forms/copytext";
    }

    protected function doDisplay(array $context, array $blocks = []): iterable
    {
        $macros = $this->macros;
        craft\helpers\Template::beginProfile("template", "graphql/tokens/_edit.twig");
        $this->parent = $this->loadTemplate("_includes/forms/copytext", "graphql/tokens/_edit.twig", 59);
        yield from $this->parent->unwrap()->yield($context, array_merge($this->blocks, $blocks));
        craft\helpers\Template::endProfile("template", "graphql/tokens/_edit.twig");
    }

    // line 68
    /**
     * @return iterable<null|scalar|\Stringable>
     */
    public function block_js(array $context, array $blocks = []): iterable
    {
        $macros = $this->macros;
        craft\helpers\Template::beginProfile("block", "js");
        craft\helpers\Template::endProfile("block", "js");
        yield from [];
    }

    /**
     * @codeCoverageIgnore
     */
    public function getTemplateName(): string
    {
        return "graphql/tokens/_edit.twig";
    }

    /**
     * @codeCoverageIgnore
     */
    public function isTraitable(): bool
    {
        return false;
    }

    /**
     * @codeCoverageIgnore
     */
    public function getDebugInfo(): array
    {
        return array (  719 => 68,  706 => 59,  478 => 74,  475 => 73,  473 => 72,  471 => 70,  469 => 64,  468 => 63,  467 => 62,  466 => 59,  463 => 58,  460 => 57,  452 => 56,  439 => 51,  213 => 96,  211 => 95,  210 => 94,  209 => 90,  205 => 88,  203 => 87,  202 => 83,  199 => 82,  191 => 81,  185 => 51,  178 => 47,  177 => 43,  174 => 42,  172 => 35,  171 => 34,  170 => 30,  166 => 28,  164 => 25,  163 => 24,  162 => 18,  159 => 17,  153 => 16,  149 => 15,  146 => 14,  138 => 13,  132 => 1,  87 => 124,  69 => 109,  59 => 101,  57 => 100,  55 => 11,  53 => 7,  51 => 5,  49 => 3,  41 => 1,);
    }

    public function getSourceContext(): Source
    {
        return new Source("{% extends \"_layouts/cp\" %}

{% set selectedSubnavItem = 'tokens' %}

{% set fullPageForm = true %}

{% set crumbs = [
    { label: \"GraphQL Tokens\"|t('app'), url: url('graphql/tokens') }
] %}

{% import \"_includes/forms\" as forms %}

{% block content %}
    <input type=\"hidden\" name=\"action\" value=\"graphql/save-token\">
    {{ redirectInput('graphql/tokens') }}
    {% if token.id %}<input type=\"hidden\" name=\"tokenId\" value=\"{{ token.id }}\">{% endif %}

    {{ forms.textField({
        first: true,
        label: \"Name\"|t('app'),
        instructions: \"What this token will be called in the control panel.\"|t('app'),
        id: 'name',
        name: 'name',
        value: token.name,
        errors: token.getErrors('name'),
        autofocus: true,
        required: true,
    }) }}

    {% set schemaInput = schemaOptions
        ? forms.selectField({
            name: 'schema',
            id: 'schema',
            options: schemaOptions,
            value: token.schemaId,
        })
        : tag('p', {
            class: ['warning', 'with-icon'],
            text: 'No schemas exist yet to assign to this token.'|t('app'),
        })
    %}

    {{ forms.field({
        id: 'schema',
        label: 'GraphQL Schema',
        instructions: 'Choose which GraphQL schema this token has access to.',
    }, schemaInput) }}

    <hr>

    {% embed '_includes/forms/field' with {
        label: 'Authorization Header'|t('app'),
        instructions: 'The `Authorization` header that should be sent with GraphQL API requests to use this token.'|t('app'),
        id: 'auth-header',
    } %}
        {% block input %}
            {% import '_includes/forms' as forms %}
            <div class=\"flex\">
                {% embed '_includes/forms/copytext' with {
                    id: 'auth-header',
                    buttonId: 'copy-btn',
                    value: 'Authorization: Bearer ' ~ (accessToken ?? '••••••••••••••••••••••••••••••••'),
                    errors: token.getErrors('accessToken'),
                    class: ['code', not accessToken ? 'disabled']|filter,
                    size: 54,
                } %}
                    {# don't register the default JS #}
                    {% block js %}{% endblock %}
                {% endembed %}
                {{ hiddenInput('accessToken', accessToken, {
                    id: 'access-token',
                    disabled: not accessToken,
                }) }}
                <button type=\"button\" id=\"regen-btn\" class=\"btn\">{{ 'Regenerate'|t('app') }}</button>
                <div id=\"token-spinner\" class=\"spinner hidden\"></div>
            </div>
        {% endblock %}
    {% endembed %}
{% endblock %}

{% block details %}
    <div class=\"meta\">
        {{ forms.lightswitchField({
            label: 'Enabled'|t('app'),
            id: 'enabled',
            name: 'enabled',
            on: token.enabled,
        }) }}

        {{ forms.dateTimeField({
            label: \"Expiry Date\"|t('app'),
            id: 'expiryDate',
            name: 'expiryDate',
            value: (token.expiryDate ? token.expiryDate : null),
            errors: token.getErrors('expiryDate')
        }) }}
    </div>
{% endblock %}

{% js %}
    var \$headerInput = \$('#auth-header');
    var \$tokenInput = \$('#access-token');
    var \$regenBtn = \$('#regen-btn');
    var regenerating = false;

    function copyHeader() {
        \$headerInput[0].select();
        document.execCommand('copy');
        Craft.cp.displayNotice(\"{{ 'Copied to clipboard.'|t('app')|e('js') }}\");
    }

    \$headerInput.on('click', function() {
        if (!\$headerInput.hasClass('disabled')) {
            this.select();
        }
    });

    \$('#copy-btn').on('click', function() {
        if (!\$headerInput.hasClass('disabled')) {
            copyHeader();
        } else {
            Craft.elevatedSessionManager.requireElevatedSession(function() {
            \$('#token-spinner').removeClass('hidden');
            var data = {{ {tokenUid: token.uid}|json_encode|raw }};
            Craft.sendActionRequest('POST', 'graphql/fetch-token', {data})
                .then((response) => {
                    \$('#token-spinner').addClass('hidden');
                    \$headerInput
                        .val('Authorization: Bearer ' + response.data.accessToken)
                        .removeClass('disabled');
                    copyHeader();
                })
                .finally(() => {
                    \$('#token-spinner').addClass('hidden');
                });
            });
        }
    });

    \$regenBtn.on('click', function() {
        if (regenerating) {
            return;
        }
        regenerating = true;
        \$('#token-spinner').removeClass('hidden');
        \$regenBtn.addClass('active');

        Craft.sendActionRequest('POST', 'graphql/generate-token')
            .then((response) => {
                \$headerInput
                    .val('Authorization: Bearer ' + response.data.accessToken)
                    .removeClass('disabled');
                \$tokenInput
                    .val(response.data.accessToken)
                    .prop('disabled', false);
                \$regenBtn.removeClass('active');
                regenerating = false;
            })
            .finally(() => {
                \$('#token-spinner').addClass('hidden');
            });
        });

    new Craft.ElevatedSessionForm('#main-form');
{% endjs %}
", "graphql/tokens/_edit.twig", "/var/www/html/backend/vendor/craftcms/cms/src/templates/graphql/tokens/_edit.twig");
    }
}

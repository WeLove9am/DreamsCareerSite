<?php

use Twig\Environment;
use Twig\Error\LoaderError;
use Twig\Error\RuntimeError;
use Twig\Extension\CoreExtension;
use Twig\Extension\SandboxExtension;
use Twig\Markup;
use Twig\Sandbox\SecurityError;
use Twig\Sandbox\SecurityNotAllowedTagError;
use Twig\Sandbox\SecurityNotAllowedFilterError;
use Twig\Sandbox\SecurityNotAllowedFunctionError;
use Twig\Source;
use Twig\Template;
use Twig\TemplateWrapper;

/* _layouts/components/skip-links */
class __TwigTemplate_552ed9971f1e2d79a4c97378d87de6df extends Template
{
    private Source $source;
    /**
     * @var array<string, Template>
     */
    private array $macros = [];

    public function __construct(Environment $env)
    {
        parent::__construct($env);

        $this->source = $this->getSourceContext();

        $this->parent = false;

        $this->blocks = [
        ];
    }

    protected function doDisplay(array $context, array $blocks = []): iterable
    {
        $macros = $this->macros;
        craft\helpers\Template::beginProfile("template", "_layouts/components/skip-links");
        // line 1
        $context["orientation"] = craft\helpers\Template::attribute($this->env, $this->source, craft\helpers\Template::attribute($this->env, $this->source, craft\helpers\Template::attribute($this->env, $this->source, (isset($context["craft"]) || array_key_exists("craft", $context) ? $context["craft"] : (function () { throw new RuntimeError('Variable "craft" does not exist.', 1, $this->source); })()), "app", [], "any", false, false, false, 1), "locale", [], "any", false, false, false, 1), "getOrientation", [], "method", false, false, false, 1);
        // line 3
        $context["links"] = [["label" => $this->extensions['craft\web\twig\Extension']->translateFilter("Skip to main section", "app"), "url" => "#main"], ["label" => (((        // line 9
(isset($context["orientation"]) || array_key_exists("orientation", $context) ? $context["orientation"] : (function () { throw new RuntimeError('Variable "orientation" does not exist.', 9, $this->source); })()) == "ltr")) ? ($this->extensions['craft\web\twig\Extension']->translateFilter("Skip to left sidebar", "app")) : ($this->extensions['craft\web\twig\Extension']->translateFilter("Skip to right sidebar", "app"))), "url" => "#sidebar-container"], ["label" => $this->extensions['craft\web\twig\Extension']->translateFilter("Skip to content", "app"), "url" => "#content-container"], ["label" => (((        // line 17
(isset($context["orientation"]) || array_key_exists("orientation", $context) ? $context["orientation"] : (function () { throw new RuntimeError('Variable "orientation" does not exist.', 17, $this->source); })()) == "ltr")) ? ($this->extensions['craft\web\twig\Extension']->translateFilter("Skip to right sidebar", "app")) : ($this->extensions['craft\web\twig\Extension']->translateFilter("Skip to left sidebar", "app"))), "url" => "#details-container"]];
        // line 21
        yield "
<ul id=\"global-skip-links\">
  ";
        // line 23
        $context['_parent'] = $context;
        $context['_seq'] = CoreExtension::ensureTraversable((isset($context["links"]) || array_key_exists("links", $context) ? $context["links"] : (function () { throw new RuntimeError('Variable "links" does not exist.', 23, $this->source); })()));
        foreach ($context['_seq'] as $context["_key"] => $context["link"]) {
            // line 24
            yield "    <li>
      ";
            // line 25
            yield $this->extensions['craft\web\twig\Extension']->tagFunction("a", ["text" => craft\helpers\Template::attribute($this->env, $this->source,             // line 26
$context["link"], "label", [], "any", false, false, false, 26), "href" => craft\helpers\Template::attribute($this->env, $this->source,             // line 27
$context["link"], "url", [], "any", false, false, false, 27), "class" => "skip-link skip-link--global btn"]);
            // line 29
            yield "
    </li>
  ";
        }
        $_parent = $context['_parent'];
        unset($context['_seq'], $context['_key'], $context['link'], $context['_parent']);
        $context = array_intersect_key($context, $_parent) + $_parent;
        // line 32
        yield "</ul>
";
        craft\helpers\Template::endProfile("template", "_layouts/components/skip-links");
        yield from [];
    }

    /**
     * @codeCoverageIgnore
     */
    public function getTemplateName(): string
    {
        return "_layouts/components/skip-links";
    }

    /**
     * @codeCoverageIgnore
     */
    public function isTraitable(): bool
    {
        return false;
    }

    /**
     * @codeCoverageIgnore
     */
    public function getDebugInfo(): array
    {
        return array (  72 => 32,  64 => 29,  62 => 27,  61 => 26,  60 => 25,  57 => 24,  53 => 23,  49 => 21,  47 => 17,  46 => 9,  45 => 3,  43 => 1,);
    }

    public function getSourceContext(): Source
    {
        return new Source("{% set orientation = craft.app.locale.getOrientation() -%}

{% set links = [
  {
    label: 'Skip to main section'|t('app'),
    url: '#main',
  },
  {
    label: orientation == 'ltr' ? 'Skip to left sidebar'|t('app') : 'Skip to right sidebar'|t('app'),
    url: '#sidebar-container',
  },
  {
    label: 'Skip to content'|t('app'),
    url: '#content-container',
  },
  {
    label: orientation == 'ltr' ? 'Skip to right sidebar'|t('app') : 'Skip to left sidebar'|t('app'),
    url: '#details-container',
  },
] %}

<ul id=\"global-skip-links\">
  {% for link in links %}
    <li>
      {{ tag ('a', {
        text: link.label,
        href: link.url,
        class: 'skip-link skip-link--global btn',
      }) }}
    </li>
  {% endfor %}
</ul>
", "_layouts/components/skip-links", "/var/www/html/backend/vendor/craftcms/cms/src/templates/_layouts/components/skip-links.twig");
    }
}

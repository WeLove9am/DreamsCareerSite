<?php

use Twig\Environment;
use Twig\Error\LoaderError;
use Twig\Error\RuntimeError;
use Twig\Extension\CoreExtension;
use Twig\Extension\SandboxExtension;
use Twig\Markup;
use Twig\Sandbox\SecurityError;
use Twig\Sandbox\SecurityNotAllowedTagError;
use Twig\Sandbox\SecurityNotAllowedFilterError;
use Twig\Sandbox\SecurityNotAllowedFunctionError;
use Twig\Source;
use Twig\Template;
use Twig\TemplateWrapper;

/* _includes/forms/componentSelect.twig */
class __TwigTemplate_334119e0856abe9bcfc01f47eff5c2b2 extends Template
{
    private Source $source;
    /**
     * @var array<string, Template>
     */
    private array $macros = [];

    public function __construct(Environment $env)
    {
        parent::__construct($env);

        $this->source = $this->getSourceContext();

        $this->parent = false;

        $this->blocks = [
            'chips' => [$this, 'block_chips'],
        ];
    }

    protected function doDisplay(array $context, array $blocks = []): iterable
    {
        $macros = $this->macros;
        craft\helpers\Template::beginProfile("template", "_includes/forms/componentSelect.twig");
        // line 1
        $macros["forms"] = $this->macros["forms"] = $this->loadTemplate("_includes/forms.twig", "_includes/forms/componentSelect.twig", 1)->unwrap();
        // line 2
        yield "
";
        // line 3
        if (((($context["name"]) ?? (false)) && (($context["renderDefaultInput"]) ?? (true)))) {
            // line 4
            yield "  ";
            yield craft\helpers\Html::hiddenInput($this->extensions['craft\web\twig\Extension']->replaceFilter((isset($context["name"]) || array_key_exists("name", $context) ? $context["name"] : (function () { throw new RuntimeError('Variable "name" does not exist.', 4, $this->source); })()), "/\\[\\]\$/", ""), "");
            yield "
";
        }
        // line 7
        $context["id"] = (($context["id"]) ?? (("componentselect" . Twig\Extension\CoreExtension::random($this->env->getCharset()))));
        // line 8
        $context["options"] = (($context["options"]) ?? ([]));
        // line 9
        $context["values"] = (($context["values"]) ?? ((((($context["value"]) ?? (false))) ? ([(isset($context["value"]) || array_key_exists("value", $context) ? $context["value"] : (function () { throw new RuntimeError('Variable "value" does not exist.', 9, $this->source); })())]) : ([]))));
        // line 10
        $context["limit"] = (($context["limit"]) ?? (null));
        // line 11
        $context["showHandles"] = (($context["showHandles"]) ?? (false));
        // line 12
        $context["showIndicators"] = (($context["showIndicators"]) ?? (false));
        // line 13
        $context["showDescription"] = (($context["showDescription"]) ?? (false));
        // line 14
        $context["sortable"] = (( !(isset($context["limit"]) || array_key_exists("limit", $context) ? $context["limit"] : (function () { throw new RuntimeError('Variable "limit" does not exist.', 14, $this->source); })()) || ((isset($context["limit"]) || array_key_exists("limit", $context) ? $context["limit"] : (function () { throw new RuntimeError('Variable "limit" does not exist.', 14, $this->source); })()) > 1)) && (($context["sortable"]) ?? (true)));
        // line 15
        $context["showActionMenus"] = (($context["showActionMenus"]) ?? (true));
        // line 16
        $context["hyperlinks"] = (($context["hyperlinks"]) ?? (true));
        // line 17
        $context["withSearchInput"] = (($context["withSearchInput"]) ?? (($this->extensions['craft\web\twig\Extension']->lengthFilter($this->env, (isset($context["options"]) || array_key_exists("options", $context) ? $context["options"] : (function () { throw new RuntimeError('Variable "options" does not exist.', 17, $this->source); })())) > 5)));
        // line 18
        $context["createAction"] = (($context["createAction"]) ?? (null));
        // line 19
        $context["disabled"] = (((($context["disabled"]) ?? (false))) ? (true) : (false));
        // line 20
        $context["registerJs"] = (($context["registerJs"]) ?? (true));
        // line 21
        $context["jsClass"] = (($context["jsClass"]) ?? ("Craft.ComponentSelectInput"));
        // line 22
        yield "
";
        // line 24
        if ((isset($context["showHandles"]) || array_key_exists("showHandles", $context) ? $context["showHandles"] : (function () { throw new RuntimeError('Variable "showHandles" does not exist.', 24, $this->source); })())) {
            // line 25
            yield "  ";
            $context["options"] = $this->extensions['craft\web\twig\Extension']->sortFilter($this->env, (isset($context["options"]) || array_key_exists("options", $context) ? $context["options"] : (function () { throw new RuntimeError('Variable "options" does not exist.', 25, $this->source); })()), function ($__a__, $__b__) use ($context, $macros) { $context["a"] = $__a__; $context["b"] = $__b__; return (($this->env->getTest('instance of')->getCallable()((isset($context["a"]) || array_key_exists("a", $context) ? $context["a"] : (function () { throw new RuntimeError('Variable "a" does not exist.', 25, $this->source); })()), "craft\\base\\Grippable")) ? ((((craft\helpers\Template::attribute($this->env, $this->source, (isset($context["a"]) || array_key_exists("a", $context) ? $context["a"] : (function () { throw new RuntimeError('Variable "a" does not exist.', 25, $this->source); })()), "getHandle", [], "method", false, false, false, 25) <=> $this->env->getTest('instance of')->getCallable()((isset($context["b"]) || array_key_exists("b", $context) ? $context["b"] : (function () { throw new RuntimeError('Variable "b" does not exist.', 25, $this->source); })()), "craft\\base\\Grippable"))) ? (craft\helpers\Template::attribute($this->env, $this->source, (isset($context["b"]) || array_key_exists("b", $context) ? $context["b"] : (function () { throw new RuntimeError('Variable "b" does not exist.', 25, $this->source); })()), "getHandle", [], "method", false, false, false, 25)) : (""))) : ("")); });
        }
        // line 27
        $context["options"] = $this->extensions['craft\web\twig\Extension']->sortFilter($this->env, (isset($context["options"]) || array_key_exists("options", $context) ? $context["options"] : (function () { throw new RuntimeError('Variable "options" does not exist.', 27, $this->source); })()), function ($__a__, $__b__) use ($context, $macros) { $context["a"] = $__a__; $context["b"] = $__b__; return (craft\helpers\Template::attribute($this->env, $this->source, (isset($context["a"]) || array_key_exists("a", $context) ? $context["a"] : (function () { throw new RuntimeError('Variable "a" does not exist.', 27, $this->source); })()), "getUiLabel", [], "method", false, false, false, 27) <=> craft\helpers\Template::attribute($this->env, $this->source, (isset($context["b"]) || array_key_exists("b", $context) ? $context["b"] : (function () { throw new RuntimeError('Variable "b" does not exist.', 27, $this->source); })()), "getUiLabel", [], "method", false, false, false, 27)); });
        // line 28
        yield "
";
        // line 29
        $context["containerAttributes"] = $this->extensions['craft\web\twig\Extension']->mergeFilter(["id" =>         // line 30
(isset($context["id"]) || array_key_exists("id", $context) ? $context["id"] : (function () { throw new RuntimeError('Variable "id" does not exist.', 30, $this->source); })()), "class" => $this->extensions['craft\web\twig\Extension']->mergeFilter(["componentselect"], craft\helpers\Html::explodeClass(((        // line 31
$context["class"]) ?? ([]))))], ((        // line 32
$context["containerAttributes"]) ?? ([])), true);
        // line 34
        if (        $this->unwrap()->hasBlock("attr", $context, $blocks)) {
            // line 35
            $context["containerAttributes"] = $this->extensions['craft\web\twig\Extension']->mergeFilter((isset($context["containerAttributes"]) || array_key_exists("containerAttributes", $context) ? $context["containerAttributes"] : (function () { throw new RuntimeError('Variable "containerAttributes" does not exist.', 35, $this->source); })()), $this->extensions['craft\web\twig\Extension']->parseAttrFilter((("<div " .             $this->unwrap()->renderBlock("attr", $context, $blocks)) . ">")), true);
        }
        // line 37
        yield "
";
        // line 38
        ob_start();
        // line 39
        yield "  ";
        ob_start();
        // line 46
        $_v0 = ('' === $tmp = \Twig\Extension\CoreExtension::captureOutput((function () use (&$context, $macros, $blocks) {
            // line 47
            yield "      ";
            yield from $this->unwrap()->yieldBlock('chips', $context, $blocks);
            // line 66
            yield "    ";
            yield from [];
        })())) ? '' : new Markup($tmp, $this->env->getCharset());
        // line 46
        yield Twig\Extension\CoreExtension::spaceless($_v0);
        echo craft\helpers\Html::tag("ul", ob_get_clean(), ["class" => $this->extensions['craft\web\twig\Extension']->filterFilter($this->env, ["components", "chips", ((((        // line 43
$context["inline"]) ?? (false))) ? ("inline-chips") : (null))])]);
        // line 68
        yield "
  <div class=\"flex flex-nowrap\">
    ";
        // line 70
        $context["valueIds"] = $this->extensions['craft\web\twig\Extension']->mapFilter($this->env, (isset($context["values"]) || array_key_exists("values", $context) ? $context["values"] : (function () { throw new RuntimeError('Variable "values" does not exist.', 70, $this->source); })()), function ($__component__) use ($context, $macros) { $context["component"] = $__component__; return craft\helpers\Template::attribute($this->env, $this->source, (isset($context["component"]) || array_key_exists("component", $context) ? $context["component"] : (function () { throw new RuntimeError('Variable "component" does not exist.', 70, $this->source); })()), "getId", [], "method", false, false, false, 70); });
        // line 71
        yield "
    ";
        // line 74
        yield "    ";
        yield craft\helpers\Cp::disclosureMenu($this->extensions['craft\web\twig\Extension']->mapFilter($this->env, (isset($context["options"]) || array_key_exists("options", $context) ? $context["options"] : (function () { throw new RuntimeError('Variable "options" does not exist.', 74, $this->source); })()), function ($__component__) use ($context, $macros) { $context["component"] = $__component__; return ["type" => "button", "label" => craft\helpers\Template::attribute($this->env, $this->source,         // line 76
(isset($context["component"]) || array_key_exists("component", $context) ? $context["component"] : (function () { throw new RuntimeError('Variable "component" does not exist.', 76, $this->source); })()), "getUiLabel", [], "method", false, false, false, 76), "handle" => (((        // line 77
(isset($context["showHandles"]) || array_key_exists("showHandles", $context) ? $context["showHandles"] : (function () { throw new RuntimeError('Variable "showHandles" does not exist.', 77, $this->source); })()) && $this->env->getTest('instance of')->getCallable()((isset($context["component"]) || array_key_exists("component", $context) ? $context["component"] : (function () { throw new RuntimeError('Variable "component" does not exist.', 77, $this->source); })()), "craft\\base\\Grippable"))) ? (craft\helpers\Template::attribute($this->env, $this->source, (isset($context["component"]) || array_key_exists("component", $context) ? $context["component"] : (function () { throw new RuntimeError('Variable "component" does not exist.', 77, $this->source); })()), "getHandle", [], "method", false, false, false, 77)) : (null)), "info" => (((        // line 78
(isset($context["showDescription"]) || array_key_exists("showDescription", $context) ? $context["showDescription"] : (function () { throw new RuntimeError('Variable "showDescription" does not exist.', 78, $this->source); })()) && $this->env->getTest('instance of')->getCallable()((isset($context["component"]) || array_key_exists("component", $context) ? $context["component"] : (function () { throw new RuntimeError('Variable "component" does not exist.', 78, $this->source); })()), "craft\\base\\Describable"))) ? (craft\helpers\Template::attribute($this->env, $this->source, (isset($context["component"]) || array_key_exists("component", $context) ? $context["component"] : (function () { throw new RuntimeError('Variable "component" does not exist.', 78, $this->source); })()), "getDescription", [], "method", false, false, false, 78)) : (null)), "icon" => (($this->env->getTest('instance of')->getCallable()(        // line 79
(isset($context["component"]) || array_key_exists("component", $context) ? $context["component"] : (function () { throw new RuntimeError('Variable "component" does not exist.', 79, $this->source); })()), "craft\\base\\Iconic")) ? (craft\helpers\Template::attribute($this->env, $this->source, (isset($context["component"]) || array_key_exists("component", $context) ? $context["component"] : (function () { throw new RuntimeError('Variable "component" does not exist.', 79, $this->source); })()), "getIcon", [], "method", false, false, false, 79)) : (null)), "color" => (($this->env->getTest('instance of')->getCallable()(        // line 80
(isset($context["component"]) || array_key_exists("component", $context) ? $context["component"] : (function () { throw new RuntimeError('Variable "component" does not exist.', 80, $this->source); })()), "craft\\base\\Colorable")) ? (craft\helpers\Template::attribute($this->env, $this->source, (isset($context["component"]) || array_key_exists("component", $context) ? $context["component"] : (function () { throw new RuntimeError('Variable "component" does not exist.', 80, $this->source); })()), "getColor", [], "method", false, false, false, 80)) : (null)), "attributes" => ["data" => ["type" => get_class(        // line 83
(isset($context["component"]) || array_key_exists("component", $context) ? $context["component"] : (function () { throw new RuntimeError('Variable "component" does not exist.', 83, $this->source); })())), "id" => craft\helpers\Template::attribute($this->env, $this->source,         // line 84
(isset($context["component"]) || array_key_exists("component", $context) ? $context["component"] : (function () { throw new RuntimeError('Variable "component" does not exist.', 84, $this->source); })()), "getId", [], "method", false, false, false, 84), "handle" => (((        // line 85
(isset($context["showHandles"]) || array_key_exists("showHandles", $context) ? $context["showHandles"] : (function () { throw new RuntimeError('Variable "showHandles" does not exist.', 85, $this->source); })()) && $this->env->getTest('instance of')->getCallable()((isset($context["component"]) || array_key_exists("component", $context) ? $context["component"] : (function () { throw new RuntimeError('Variable "component" does not exist.', 85, $this->source); })()), "craft\\base\\Grippable"))) ? (craft\helpers\Template::attribute($this->env, $this->source, (isset($context["component"]) || array_key_exists("component", $context) ? $context["component"] : (function () { throw new RuntimeError('Variable "component" does not exist.', 85, $this->source); })()), "getHandle", [], "method", false, false, false, 85)) : (null))]], "liAttributes" => ["class" => Twig\Extension\CoreExtension::keys($this->extensions['craft\web\twig\Extension']->filterFilter($this->env, ["hidden" => CoreExtension::inFilter(craft\helpers\Template::attribute($this->env, $this->source,         // line 90
(isset($context["component"]) || array_key_exists("component", $context) ? $context["component"] : (function () { throw new RuntimeError('Variable "component" does not exist.', 90, $this->source); })()), "getId", [], "method", false, false, false, 90), (isset($context["valueIds"]) || array_key_exists("valueIds", $context) ? $context["valueIds"] : (function () { throw new RuntimeError('Variable "valueIds" does not exist.', 90, $this->source); })()))]))]]; }), ["buttonLabel" => $this->extensions['craft\web\twig\Extension']->translateFilter("Choose", "app"), "buttonAttributes" => ["class" => ["dashed", "add-btn"]], "omitIfEmpty" => false, "withSearchInput" =>         // line 99
(isset($context["withSearchInput"]) || array_key_exists("withSearchInput", $context) ? $context["withSearchInput"] : (function () { throw new RuntimeError('Variable "withSearchInput" does not exist.', 99, $this->source); })()), "disabled" =>         // line 100
(isset($context["disabled"]) || array_key_exists("disabled", $context) ? $context["disabled"] : (function () { throw new RuntimeError('Variable "disabled" does not exist.', 100, $this->source); })())]);
        // line 101
        yield "

    ";
        // line 103
        if (((isset($context["createAction"]) || array_key_exists("createAction", $context) ? $context["createAction"] : (function () { throw new RuntimeError('Variable "createAction" does not exist.', 103, $this->source); })()) &&  !(isset($context["disabled"]) || array_key_exists("disabled", $context) ? $context["disabled"] : (function () { throw new RuntimeError('Variable "disabled" does not exist.', 103, $this->source); })()))) {
            // line 104
            yield "      ";
            yield $macros["forms"]->getTemplateForMacro("macro_button", $context, 104, $this->getSourceContext())->macro_button(...[["class" => ["dashed", "create-btn"], "label" => $this->extensions['craft\web\twig\Extension']->translateFilter("Create", "app"), "icon" => "plus"]]);
            // line 108
            yield "
    ";
        }
        // line 110
        yield "  </div>
";
        echo craft\helpers\Html::tag("div", ob_get_clean(),         // line 38
(isset($context["containerAttributes"]) || array_key_exists("containerAttributes", $context) ? $context["containerAttributes"] : (function () { throw new RuntimeError('Variable "containerAttributes" does not exist.', 38, $this->source); })()));
        // line 112
        yield "
";
        // line 113
        if (( !(isset($context["disabled"]) || array_key_exists("disabled", $context) ? $context["disabled"] : (function () { throw new RuntimeError('Variable "disabled" does not exist.', 113, $this->source); })()) && (isset($context["registerJs"]) || array_key_exists("registerJs", $context) ? $context["registerJs"] : (function () { throw new RuntimeError('Variable "registerJs" does not exist.', 113, $this->source); })()))) {
            // line 114
            yield "  ";
            $context["jsSettings"] = $this->extensions['craft\web\twig\Extension']->mergeFilter(["id" => $this->env->getFilter('namespaceInputId')->getCallable()(            // line 115
(isset($context["id"]) || array_key_exists("id", $context) ? $context["id"] : (function () { throw new RuntimeError('Variable "id" does not exist.', 115, $this->source); })())), "name" => $this->env->getFilter('namespaceInputName')->getCallable()(            // line 116
(isset($context["name"]) || array_key_exists("name", $context) ? $context["name"] : (function () { throw new RuntimeError('Variable "name" does not exist.', 116, $this->source); })())), "limit" =>             // line 117
(isset($context["limit"]) || array_key_exists("limit", $context) ? $context["limit"] : (function () { throw new RuntimeError('Variable "limit" does not exist.', 117, $this->source); })()), "showHandles" =>             // line 118
(isset($context["showHandles"]) || array_key_exists("showHandles", $context) ? $context["showHandles"] : (function () { throw new RuntimeError('Variable "showHandles" does not exist.', 118, $this->source); })()), "showDescription" =>             // line 119
(isset($context["showDescription"]) || array_key_exists("showDescription", $context) ? $context["showDescription"] : (function () { throw new RuntimeError('Variable "showDescription" does not exist.', 119, $this->source); })()), "sortable" =>             // line 120
(isset($context["sortable"]) || array_key_exists("sortable", $context) ? $context["sortable"] : (function () { throw new RuntimeError('Variable "sortable" does not exist.', 120, $this->source); })()), "showActionMenus" =>             // line 121
(isset($context["showActionMenus"]) || array_key_exists("showActionMenus", $context) ? $context["showActionMenus"] : (function () { throw new RuntimeError('Variable "showActionMenus" does not exist.', 121, $this->source); })()), "hyperlinks" =>             // line 122
(isset($context["hyperlinks"]) || array_key_exists("hyperlinks", $context) ? $context["hyperlinks"] : (function () { throw new RuntimeError('Variable "hyperlinks" does not exist.', 122, $this->source); })()), "createAction" =>             // line 123
(isset($context["createAction"]) || array_key_exists("createAction", $context) ? $context["createAction"] : (function () { throw new RuntimeError('Variable "createAction" does not exist.', 123, $this->source); })())], ((            // line 124
$context["jsSettings"]) ?? ([])));
            // line 125
            yield "
  ";
            // line 126
            ob_start();
            // line 127
            yield "    (() => {
      new ";
            // line 128
            yield $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape((isset($context["jsClass"]) || array_key_exists("jsClass", $context) ? $context["jsClass"] : (function () { throw new RuntimeError('Variable "jsClass" does not exist.', 128, $this->source); })()), "html", null, true);
            yield "(";
            yield $this->extensions['craft\web\twig\Extension']->jsonEncodeFilter((isset($context["jsSettings"]) || array_key_exists("jsSettings", $context) ? $context["jsSettings"] : (function () { throw new RuntimeError('Variable "jsSettings" does not exist.', 128, $this->source); })()));
            yield ");
    })();
  ";
            craft\helpers\Template::js(ob_get_clean(), ['position' => 3]);
        }
        craft\helpers\Template::endProfile("template", "_includes/forms/componentSelect.twig");
        yield from [];
    }

    // line 47
    /**
     * @return iterable<null|scalar|\Stringable>
     */
    public function block_chips(array $context, array $blocks = []): iterable
    {
        $macros = $this->macros;
        craft\helpers\Template::beginProfile("block", "chips");
        // line 48
        yield "        ";
        $context['_parent'] = $context;
        $context['_seq'] = CoreExtension::ensureTraversable((isset($context["values"]) || array_key_exists("values", $context) ? $context["values"] : (function () { throw new RuntimeError('Variable "values" does not exist.', 48, $this->source); })()));
        foreach ($context['_seq'] as $context["_key"] => $context["component"]) {
            // line 49
            yield "          <li>
            ";
            // line 50
            $context["chip"] = craft\helpers\Cp::chipHtml($context["component"], ["inputName" => ((            // line 51
$context["inputName"]) ?? ((($context["name"]) ?? (null)))), "checkbox" => ((            // line 52
$context["selectable"]) ?? (false)), "showActionMenu" =>             // line 53
(isset($context["showActionMenus"]) || array_key_exists("showActionMenus", $context) ? $context["showActionMenus"] : (function () { throw new RuntimeError('Variable "showActionMenus" does not exist.', 53, $this->source); })()), "showHandle" =>             // line 54
(isset($context["showHandles"]) || array_key_exists("showHandles", $context) ? $context["showHandles"] : (function () { throw new RuntimeError('Variable "showHandles" does not exist.', 54, $this->source); })()), "showIndicators" =>             // line 55
(isset($context["showIndicators"]) || array_key_exists("showIndicators", $context) ? $context["showIndicators"] : (function () { throw new RuntimeError('Variable "showIndicators" does not exist.', 55, $this->source); })()), "showDescription" =>             // line 56
(isset($context["showDescription"]) || array_key_exists("showDescription", $context) ? $context["showDescription"] : (function () { throw new RuntimeError('Variable "showDescription" does not exist.', 56, $this->source); })()), "hyperlink" =>             // line 57
(isset($context["hyperlinks"]) || array_key_exists("hyperlinks", $context) ? $context["hyperlinks"] : (function () { throw new RuntimeError('Variable "hyperlinks" does not exist.', 57, $this->source); })())]);
            // line 59
            yield "            ";
            if ((isset($context["disabled"]) || array_key_exists("disabled", $context) ? $context["disabled"] : (function () { throw new RuntimeError('Variable "disabled" does not exist.', 59, $this->source); })())) {
                // line 60
                yield "              ";
                $context["chip"] = $this->extensions['craft\web\twig\Extension']->removeClassFilter((isset($context["chip"]) || array_key_exists("chip", $context) ? $context["chip"] : (function () { throw new RuntimeError('Variable "chip" does not exist.', 60, $this->source); })()), "removable");
                // line 61
                yield "            ";
            }
            // line 62
            yield "            ";
            yield (isset($context["chip"]) || array_key_exists("chip", $context) ? $context["chip"] : (function () { throw new RuntimeError('Variable "chip" does not exist.', 62, $this->source); })());
            yield "
          </li>
        ";
        }
        $_parent = $context['_parent'];
        unset($context['_seq'], $context['_key'], $context['component'], $context['_parent']);
        $context = array_intersect_key($context, $_parent) + $_parent;
        // line 65
        yield "      ";
        craft\helpers\Template::endProfile("block", "chips");
        yield from [];
    }

    /**
     * @codeCoverageIgnore
     */
    public function getTemplateName(): string
    {
        return "_includes/forms/componentSelect.twig";
    }

    /**
     * @codeCoverageIgnore
     */
    public function isTraitable(): bool
    {
        return false;
    }

    /**
     * @codeCoverageIgnore
     */
    public function getDebugInfo(): array
    {
        return array (  256 => 65,  246 => 62,  243 => 61,  240 => 60,  237 => 59,  235 => 57,  234 => 56,  233 => 55,  232 => 54,  231 => 53,  230 => 52,  229 => 51,  228 => 50,  225 => 49,  220 => 48,  212 => 47,  199 => 128,  196 => 127,  194 => 126,  191 => 125,  189 => 124,  188 => 123,  187 => 122,  186 => 121,  185 => 120,  184 => 119,  183 => 118,  182 => 117,  181 => 116,  180 => 115,  178 => 114,  176 => 113,  173 => 112,  171 => 38,  168 => 110,  164 => 108,  161 => 104,  159 => 103,  155 => 101,  153 => 100,  152 => 99,  151 => 90,  150 => 85,  149 => 84,  148 => 83,  147 => 80,  146 => 79,  145 => 78,  144 => 77,  143 => 76,  141 => 74,  138 => 71,  136 => 70,  132 => 68,  130 => 43,  128 => 46,  124 => 66,  121 => 47,  119 => 46,  116 => 39,  114 => 38,  111 => 37,  108 => 35,  106 => 34,  104 => 32,  103 => 31,  102 => 30,  101 => 29,  98 => 28,  96 => 27,  92 => 25,  90 => 24,  87 => 22,  85 => 21,  83 => 20,  81 => 19,  79 => 18,  77 => 17,  75 => 16,  73 => 15,  71 => 14,  69 => 13,  67 => 12,  65 => 11,  63 => 10,  61 => 9,  59 => 8,  57 => 7,  51 => 4,  49 => 3,  46 => 2,  44 => 1,);
    }

    public function getSourceContext(): Source
    {
        return new Source("{% import '_includes/forms.twig' as forms %}

{% if (name ?? false) and (renderDefaultInput ?? true) %}
  {{ hiddenInput(name|replace('/\\\\[\\\\]\$/', ''), '') }}
{% endif -%}

{% set id = id ?? \"componentselect#{random()}\" -%}
{% set options = options ?? [] %}
{% set values = values ?? (value ?? false ? [value] : []) -%}
{% set limit = limit ?? null %}
{% set showHandles = showHandles ?? false %}
{% set showIndicators = showIndicators ?? false %}
{% set showDescription = showDescription ?? false %}
{% set sortable = (not limit or limit > 1) and (sortable ?? true) %}
{% set showActionMenus = showActionMenus ?? true %}
{% set hyperlinks = hyperlinks ?? true %}
{% set withSearchInput = withSearchInput ?? (options|length > 5) %}
{% set createAction = createAction ?? null %}
{% set disabled = (disabled ?? false) ? true : false %}
{% set registerJs = registerJs ?? true %}
{% set jsClass = jsClass ?? 'Craft.ComponentSelectInput' %}

{# sort the options by handle, then label #}
{% if showHandles %}
  {% set options = options|sort((a, b) => a is instance of('craft\\\\base\\\\Grippable') ? a.getHandle() <=> b is instance of('craft\\\\base\\\\Grippable') ? b.getHandle()) %}
{% endif %}
{% set options = options|sort((a, b) => a.getUiLabel() <=> b.getUiLabel()) %}

{% set containerAttributes = {
  id: id,
  class: ['componentselect']|merge((class ?? [])|explodeClass),
}|merge(containerAttributes ?? [], recursive=true) %}

{%- if block('attr') is defined %}
  {%- set containerAttributes = containerAttributes|merge(('<div ' ~ block('attr') ~ '>')|parseAttr, recursive=true) %}
{% endif %}

{% tag 'div' with containerAttributes %}
  {% tag 'ul' with {
    class: [
      'components',
      'chips',
      (inline ?? false) ? 'inline-chips' : null,
    ]|filter,
  } %}
    {%- apply spaceless %}
      {% block chips %}
        {% for component in values %}
          <li>
            {% set chip = chip(component, {
              inputName: inputName ?? name ?? null,
              checkbox: selectable ?? false,
              showActionMenu: showActionMenus,
              showHandle: showHandles,
              showIndicators: showIndicators,
              showDescription: showDescription,
              hyperlink: hyperlinks,
            }) %}
            {% if disabled %}
              {% set chip = chip|removeClass('removable') %}
            {% endif %}
            {{ chip|raw }}
          </li>
        {% endfor %}
      {% endblock %}
    {% endapply -%}
  {% endtag %}

  <div class=\"flex flex-nowrap\">
    {% set valueIds = values|map(component => component.getId()) %}

    {# the disclosureMenu already has support for description (shows below the label),
    so the description that goes into the info icon needs to be keyed by something else - 'info' #}
    {{ disclosureMenu(options|map(component => {
      type: 'button',
      label: component.getUiLabel(),
      handle: showHandles and component is instance of('craft\\\\base\\\\Grippable') ? component.getHandle() : null,
      info: showDescription and component is instance of('craft\\\\base\\\\Describable') ? component.getDescription() : null,
      icon: component is instance of('craft\\\\base\\\\Iconic') ? component.getIcon() : null,
      color: component is instance of('craft\\\\base\\\\Colorable') ? component.getColor() : null,
      attributes: {
        data: {
          type: className(component),
          id: component.getId(),
          handle: showHandles and component is instance of('craft\\\\base\\\\Grippable') ? component.getHandle() : null,
        },
      },
      liAttributes: {
        class: {
          hidden: component.getId() in valueIds
        }|filter|keys,
      },
    }), {
      buttonLabel: 'Choose'|t('app'),
      buttonAttributes: {
        class: ['dashed', 'add-btn'],
      },
      omitIfEmpty: false,
      withSearchInput,
      disabled,
    }) }}

    {% if createAction and not disabled %}
      {{ forms.button({
        class: ['dashed', 'create-btn'],
        label: 'Create'|t('app'),
        icon: 'plus',
      }) }}
    {% endif %}
  </div>
{% endtag %}

{% if not disabled and registerJs %}
  {% set jsSettings = {
    id: id|namespaceInputId,
    name: name|namespaceInputName,
    limit,
    showHandles,
    showDescription,
    sortable,
    showActionMenus,
    hyperlinks,
    createAction,
  }|merge(jsSettings ?? {}) %}

  {% js %}
    (() => {
      new {{ jsClass }}({{ jsSettings|json_encode|raw }});
    })();
  {% endjs %}
{% endif %}
", "_includes/forms/componentSelect.twig", "/var/www/html/backend/vendor/craftcms/cms/src/templates/_includes/forms/componentSelect.twig");
    }
}

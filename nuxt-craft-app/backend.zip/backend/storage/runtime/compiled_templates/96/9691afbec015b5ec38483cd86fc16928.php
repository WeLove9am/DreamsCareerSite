<?php

use Twig\Environment;
use Twig\Error\LoaderError;
use Twig\Error\RuntimeError;
use Twig\Extension\CoreExtension;
use Twig\Extension\SandboxExtension;
use Twig\Markup;
use Twig\Sandbox\SecurityError;
use Twig\Sandbox\SecurityNotAllowedTagError;
use Twig\Sandbox\SecurityNotAllowedFilterError;
use Twig\Sandbox\SecurityNotAllowedFunctionError;
use Twig\Source;
use Twig\Template;
use Twig\TemplateWrapper;

/* graphql/tokens/_index.twig */
class __TwigTemplate_038367d26fc8a73d5648d05aeb2e73ec extends Template
{
    private Source $source;
    /**
     * @var array<string, Template>
     */
    private array $macros = [];

    public function __construct(Environment $env)
    {
        parent::__construct($env);

        $this->source = $this->getSourceContext();

        $this->blocks = [
            'actionButton' => [$this, 'block_actionButton'],
            'content' => [$this, 'block_content'],
        ];
    }

    protected function doGetParent(array $context): bool|string|Template|TemplateWrapper
    {
        // line 1
        return "_layouts/cp";
    }

    protected function doDisplay(array $context, array $blocks = []): iterable
    {
        $macros = $this->macros;
        craft\helpers\Template::beginProfile("template", "graphql/tokens/_index.twig");
        // line 2
        $context["title"] = $this->extensions['craft\web\twig\Extension']->translateFilter("GraphQL Tokens", "app");
        // line 4
        $context["selectedSubnavItem"] = "tokens";
        // line 6
        $context["tokens"] = craft\helpers\Template::attribute($this->env, $this->source, craft\helpers\Template::attribute($this->env, $this->source, craft\helpers\Template::attribute($this->env, $this->source, (isset($context["craft"]) || array_key_exists("craft", $context) ? $context["craft"] : (function () { throw new RuntimeError('Variable "craft" does not exist.', 6, $this->source); })()), "app", [], "any", false, false, false, 6), "gql", [], "any", false, false, false, 6), "tokens", [], "any", false, false, false, 6);
        // line 8
        craft\helpers\Template::attribute($this->env, $this->source, (isset($context["view"]) || array_key_exists("view", $context) ? $context["view"] : (function () { throw new RuntimeError('Variable "view" does not exist.', 8, $this->source); })()), "registerAssetBundle", ["craft\\web\\assets\\admintable\\AdminTableAsset"], "method", false, false, false, 8);
        // line 9
        craft\helpers\Template::attribute($this->env, $this->source, (isset($context["view"]) || array_key_exists("view", $context) ? $context["view"] : (function () { throw new RuntimeError('Variable "view" does not exist.', 9, $this->source); })()), "registerTranslations", ["app", ["No GraphQL tokens exist yet.", "Never", "Last Used", "Expires"]], "method", false, false, false, 9);
        // line 24
        $context["tableData"] = [];
        // line 25
        $context['_parent'] = $context;
        $context['_seq'] = CoreExtension::ensureTraversable((isset($context["tokens"]) || array_key_exists("tokens", $context) ? $context["tokens"] : (function () { throw new RuntimeError('Variable "tokens" does not exist.', 25, $this->source); })()));
        foreach ($context['_seq'] as $context["_key"] => $context["token"]) {
            // line 26
            $context["tableData"] = $this->extensions['craft\web\twig\Extension']->mergeFilter((isset($context["tableData"]) || array_key_exists("tableData", $context) ? $context["tableData"] : (function () { throw new RuntimeError('Variable "tableData" does not exist.', 26, $this->source); })()), [["id" => craft\helpers\Template::attribute($this->env, $this->source,             // line 27
$context["token"], "id", [], "any", false, false, false, 27), "title" => $this->extensions['craft\web\twig\Extension']->translateFilter(craft\helpers\Template::attribute($this->env, $this->source,             // line 28
$context["token"], "name", [], "any", false, false, false, 28), "site"), "url" => craft\helpers\UrlHelper::url(("graphql/tokens/" . craft\helpers\Template::attribute($this->env, $this->source,             // line 29
$context["token"], "id", [], "any", false, false, false, 29))), "status" => ((craft\helpers\Template::attribute($this->env, $this->source,             // line 30
$context["token"], "enabled", [], "any", false, false, false, 30)) ? (true) : (false)), "lastUsed" => ["value" => craft\helpers\Template::attribute($this->env, $this->source,             // line 31
$context["token"], "lastUsed", [], "any", false, false, false, 31), "date" => ((craft\helpers\Template::attribute($this->env, $this->source, $context["token"], "lastUsed", [], "any", false, false, false, 31)) ? ($this->extensions['craft\web\twig\Extension']->timestampFilter(craft\helpers\Template::attribute($this->env, $this->source, $context["token"], "lastUsed", [], "any", false, false, false, 31))) : (null))], "expiryDate" => ["value" => craft\helpers\Template::attribute($this->env, $this->source,             // line 32
$context["token"], "expiryDate", [], "any", false, false, false, 32), "date" => ((craft\helpers\Template::attribute($this->env, $this->source, $context["token"], "expiryDate", [], "any", false, false, false, 32)) ? ($this->extensions['craft\web\twig\Extension']->timestampFilter(craft\helpers\Template::attribute($this->env, $this->source, $context["token"], "expiryDate", [], "any", false, false, false, 32))) : (null))]]]);
        }
        $_parent = $context['_parent'];
        unset($context['_seq'], $context['_key'], $context['token'], $context['_parent']);
        $context = array_intersect_key($context, $_parent) + $_parent;
        // line 36
        ob_start();
        // line 37
        yield "    var timestampCallback = function(value) {
        if (value.value) {
            return value.date;
        } else {
            return '<span class=\"light\">'+Craft.escapeHtml(Craft.t('app', 'Never'))+'</span>';
        }
    };

    var columns = [
        { name: '__slot:title', title: Craft.t('app', 'Name') },
        { name: 'lastUsed', title: Craft.t('app', 'Last Used'), callback: timestampCallback },
        { name: 'expiryDate', title: Craft.t('app', 'Expires'), callback: timestampCallback },
    ];

    new Craft.VueAdminTable({
        columns: columns,
        container: '#tokens-vue-admin-table',
        deleteAction: 'graphql/delete-token',
        emptyMessage: Craft.t('app', 'No GraphQL tokens exist yet.'),
        tableData: ";
        // line 56
        yield $this->extensions['craft\web\twig\Extension']->jsonEncodeFilter((isset($context["tableData"]) || array_key_exists("tableData", $context) ? $context["tableData"] : (function () { throw new RuntimeError('Variable "tableData" does not exist.', 56, $this->source); })()));
        yield "
    });
";
        craft\helpers\Template::js(ob_get_clean(), ['position' => 3]);
        // line 1
        $this->parent = $this->loadTemplate("_layouts/cp", "graphql/tokens/_index.twig", 1);
        yield from $this->parent->unwrap()->yield($context, array_merge($this->blocks, $blocks));
        craft\helpers\Template::endProfile("template", "graphql/tokens/_index.twig");
    }

    // line 16
    /**
     * @return iterable<null|scalar|\Stringable>
     */
    public function block_actionButton(array $context, array $blocks = []): iterable
    {
        $macros = $this->macros;
        craft\helpers\Template::beginProfile("block", "actionButton");
        // line 17
        yield "    <a class=\"btn submit add icon\" href=\"";
        yield $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape(craft\helpers\UrlHelper::url("graphql/tokens/new"), "html", null, true);
        yield "\">";
        yield $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($this->extensions['craft\web\twig\Extension']->translateFilter("New token", "app"), "html", null, true);
        yield "</a>
";
        craft\helpers\Template::endProfile("block", "actionButton");
        yield from [];
    }

    // line 20
    /**
     * @return iterable<null|scalar|\Stringable>
     */
    public function block_content(array $context, array $blocks = []): iterable
    {
        $macros = $this->macros;
        craft\helpers\Template::beginProfile("block", "content");
        // line 21
        yield "    <div id=\"tokens-vue-admin-table\"></div>
";
        craft\helpers\Template::endProfile("block", "content");
        yield from [];
    }

    /**
     * @codeCoverageIgnore
     */
    public function getTemplateName(): string
    {
        return "graphql/tokens/_index.twig";
    }

    /**
     * @codeCoverageIgnore
     */
    public function isTraitable(): bool
    {
        return false;
    }

    /**
     * @codeCoverageIgnore
     */
    public function getDebugInfo(): array
    {
        return array (  139 => 21,  131 => 20,  120 => 17,  112 => 16,  106 => 1,  100 => 56,  79 => 37,  77 => 36,  71 => 32,  70 => 31,  69 => 30,  68 => 29,  67 => 28,  66 => 27,  65 => 26,  61 => 25,  59 => 24,  57 => 9,  55 => 8,  53 => 6,  51 => 4,  49 => 2,  41 => 1,);
    }

    public function getSourceContext(): Source
    {
        return new Source("{% extends \"_layouts/cp\" %}
{% set title = \"GraphQL Tokens\"|t('app') %}

{% set selectedSubnavItem = 'tokens' %}

{% set tokens = craft.app.gql.tokens %}

{% do view.registerAssetBundle('craft\\\\web\\\\assets\\\\admintable\\\\AdminTableAsset') -%}
{% do view.registerTranslations('app', [
    'No GraphQL tokens exist yet.',
    'Never',
    'Last Used',
    'Expires',
]) %}

{% block actionButton %}
    <a class=\"btn submit add icon\" href=\"{{ url('graphql/tokens/new') }}\">{{ \"New token\"|t('app') }}</a>
{% endblock %}

{% block content %}
    <div id=\"tokens-vue-admin-table\"></div>
{% endblock %}

{% set tableData = [] %}
{% for token in tokens %}
\t{% set tableData = tableData|merge([{
        id: token.id,
        title: token.name|t('site'),
        url: url('graphql/tokens/' ~ token.id),
        status: token.enabled ? true : false,
        lastUsed: { value: token.lastUsed , date: token.lastUsed ? token.lastUsed|timestamp : null },
        expiryDate: { value: token.expiryDate, date: token.expiryDate ? token.expiryDate|timestamp : null }
    }]) %}
{% endfor %}

{% js %}
    var timestampCallback = function(value) {
        if (value.value) {
            return value.date;
        } else {
            return '<span class=\"light\">'+Craft.escapeHtml(Craft.t('app', 'Never'))+'</span>';
        }
    };

    var columns = [
        { name: '__slot:title', title: Craft.t('app', 'Name') },
        { name: 'lastUsed', title: Craft.t('app', 'Last Used'), callback: timestampCallback },
        { name: 'expiryDate', title: Craft.t('app', 'Expires'), callback: timestampCallback },
    ];

    new Craft.VueAdminTable({
        columns: columns,
        container: '#tokens-vue-admin-table',
        deleteAction: 'graphql/delete-token',
        emptyMessage: Craft.t('app', 'No GraphQL tokens exist yet.'),
        tableData: {{ tableData|json_encode|raw }}
    });
{% endjs %}
", "graphql/tokens/_index.twig", "/var/www/html/backend/vendor/craftcms/cms/src/templates/graphql/tokens/_index.twig");
    }
}

<?php
/**
 * @link http://craftcms.com/
 * @copyright Copyright (c) Pixel & Tonic, Inc.
 * @license http://craftcms.com/license
 */

namespace craft\behaviors;

use yii\base\Behavior;

/**
 * Custom field behavior
 *
 * This class provides attributes for all the unique custom field handles.
 *
 * @method $this address(mixed $value) Sets the [[address]] property
 * @method $this category(mixed $value) Sets the [[category]] property
 * @method $this code(mixed $value) Sets the [[code]] property
 * @method $this description(mixed $value) Sets the [[description]] property
 * @method $this dividerType(mixed $value) Sets the [[dividerType]] property
 * @method $this embedCode(mixed $value) Sets the [[embedCode]] property
 * @method $this image(mixed $value) Sets the [[image]] property
 * @method $this jobDescription(mixed $value) Sets the [[jobDescription]] property
 * @method $this jobId(mixed $value) Sets the [[jobId]] property
 * @method $this jobLink(mixed $value) Sets the [[jobLink]] property
 * @method $this logo(mixed $value) Sets the [[logo]] property
 * @method $this navigation(mixed $value) Sets the [[navigation]] property
 * @method $this page(mixed $value) Sets the [[page]] property
 * @method $this pageContent(mixed $value) Sets the [[pageContent]] property
 * @method $this pageLink(mixed $value) Sets the [[pageLink]] property
 * @method $this pageSubheading(mixed $value) Sets the [[pageSubheading]] property
 * @method $this salary(mixed $value) Sets the [[salary]] property
 * @method $this text(mixed $value) Sets the [[text]] property
 * @method $this textBlock(mixed $value) Sets the [[textBlock]] property
 */
class CustomFieldBehavior extends Behavior
{
    /**
     * @var bool Whether the behavior should provide methods based on the field handles.
     */
    public bool $hasMethods = false;

    /**
     * @var bool Whether properties on the class should be settable directly.
     */
    public bool $canSetProperties = true;

    /**
     * @var array<string,bool> List of supported field handles.
     */
    public static $fieldHandles = [
        'address' => true,
        'category' => true,
        'code' => true,
        'description' => true,
        'dividerType' => true,
        'embedCode' => true,
        'image' => true,
        'jobDescription' => true,
        'jobId' => true,
        'jobLink' => true,
        'logo' => true,
        'navigation' => true,
        'page' => true,
        'pageContent' => true,
        'pageLink' => true,
        'pageSubheading' => true,
        'salary' => true,
        'text' => true,
        'textBlock' => true,
    ];

    /**
     * @var array<string,bool> List of generated field handles.
     */
    public static $generatedFieldHandles = [

    ];

    /**
     * @var \craft\elements\db\AddressQuery|\craft\elements\ElementCollection<\craft\elements\Address> Value for field with the handle “address”.
     */
    public $address;

    /**
     * @var \craft\elements\db\EntryQuery|\craft\elements\ElementCollection<\craft\elements\Entry> Value for field with the handle “category”.
     */
    public $category;

    /**
     * @var string|null Value for field with the handle “code”.
     */
    public $code;

    /**
     * @var string|null Value for field with the handle “description”.
     */
    public $description;

    /**
     * @var \craft\fields\data\SingleOptionFieldData Value for field with the handle “dividerType”.
     */
    public $dividerType;

    /**
     * @var string|null Value for field with the handle “embedCode”.
     */
    public $embedCode;

    /**
     * @var \craft\elements\db\AssetQuery|\craft\elements\ElementCollection<\craft\elements\Asset> Value for field with the handle “image”.
     */
    public $image;

    /**
     * @var string|null Value for field with the handle “jobDescription”.
     */
    public $jobDescription;

    /**
     * @var string|null Value for field with the handle “jobId”.
     */
    public $jobId;

    /**
     * @var string|null Value for field with the handle “jobLink”.
     */
    public $jobLink;

    /**
     * @var \craft\elements\db\AssetQuery|\craft\elements\ElementCollection<\craft\elements\Asset> Value for field with the handle “logo”.
     */
    public $logo;

    /**
     * @var \craft\elements\db\EntryQuery|\craft\elements\ElementCollection<\craft\elements\Entry> Value for field with the handle “navigation”.
     */
    public $navigation;

    /**
     * @var \craft\elements\db\EntryQuery|\craft\elements\ElementCollection<\craft\elements\Entry> Value for field with the handle “page”.
     */
    public $page;

    /**
     * @var \craft\ckeditor\data\FieldData|null Value for field with the handle “pageContent”.
     */
    public $pageContent;

    /**
     * @var string|null Value for field with the handle “pageLink”.
     */
    public $pageLink;

    /**
     * @var string|null Value for field with the handle “pageSubheading”.
     */
    public $pageSubheading;

    /**
     * @var string|null Value for field with the handle “salary”.
     */
    public $salary;

    /**
     * @var string|null Value for field with the handle “text”.
     */
    public $text;

    /**
     * @var string|null Value for field with the handle “textBlock”.
     */
    public $textBlock;

    /**
     * @var array Additional custom field values we don’t know about yet.
     */
    private array $_customFieldValues = [];

    /**
     * @inheritdoc
     */
    public function __call($name, $params)
    {
        if (
            $this->hasMethods &&
            (isset(self::$fieldHandles[$name]) || isset(self::$generatedFieldHandles[$name])) &&
            count($params) === 1
        ) {
            $this->$name = $params[0];
            return $this->owner;
        }
        return parent::__call($name, $params);
    }

    /**
     * @inheritdoc
     */
    public function hasMethod($name): bool
    {
        if ($this->hasMethods && (isset(self::$fieldHandles[$name]) || isset(self::$generatedFieldHandles[$name]))) {
            return true;
        }
        return parent::hasMethod($name);
    }

    /**
     * @inheritdoc
     */
    public function __isset($name): bool
    {
        if (isset(self::$fieldHandles[$name]) || isset(self::$generatedFieldHandles[$name])) {
            return true;
        }
        return parent::__isset($name);
    }

    /**
     * @inheritdoc
     */
    public function __get($name)
    {
        if (isset(self::$fieldHandles[$name]) || isset(self::$generatedFieldHandles[$name])) {
            return $this->_customFieldValues[$name] ?? null;
        }
        return parent::__get($name);
    }

    /**
     * @inheritdoc
     */
    public function __set($name, $value)
    {
        if (isset(self::$fieldHandles[$name]) || isset(self::$generatedFieldHandles[$name])) {
            $this->_customFieldValues[$name] = $value;
            return;
        }
        parent::__set($name, $value);
    }

    /**
     * @inheritdoc
     */
    public function canGetProperty($name, $checkVars = true): bool
    {
        if ($checkVars && (isset(self::$fieldHandles[$name]) || isset(self::$generatedFieldHandles[$name]))) {
            return true;
        }
        return parent::canGetProperty($name, $checkVars);
    }

    /**
     * @inheritdoc
     */
    public function canSetProperty($name, $checkVars = true): bool
    {
        if (!$this->canSetProperties) {
            return false;
        }
        if ($checkVars && (isset(self::$fieldHandles[$name]) || isset(self::$generatedFieldHandles[$name]))) {
            return true;
        }
        return parent::canSetProperty($name, $checkVars);
    }
}

import{_ as T}from"./BS5pnyMs.js";import{_ as $}from"./Bln9op0L.js";import{l as A,m as L,e as N,f as S,c as r,g as l,u as a,a as n,F as y,r as f,t as d,h as B,w as m,i as V,j as q,k,o as s,b as v,d as g}from"./BKiLTqlp.js";import{u as D}from"./Dl7SEZbI.js";import{u as H}from"./DrFXLTk6.js";const j=`
  query PageEntry($uri: [String]!) {
    entry(uri: $uri) {
      ancestors {
        id
        title
        uri
      }
      children {
        id
        title
        uri
      }
      ... on page_Entry {
        id
        title
        uri
        pageSubheading
        pageContent
        image {
          url @transform(handle: "hero")
          alt
        }
      }
    }
  }
`,F={key:0},G=["src","alt"],M={class:"container mx-auto pt-12 pb-6 px-2 text-2xl"},Q={key:0,class:"mb-2 text-base text-slate-400"},R={class:"font-bold text-4xl sm:text-6xl lg:text-9xl"},U={key:1,class:"mt-4"},Y={class:"page__content"},z=["innerHTML"],I={key:1,class:"page__extra"},J={class:"container mx-auto py-12 px-2 text-balance"},te={__name:"[...slug]",async setup(K){let u,h;const w=A(),b=q(),{isPreview:p,previewToken:c,previewTimestamp:C}=D();p.value;const _=L(()=>{const t=w.params.slug;return t?Array.isArray(t)?t.join("/"):t:""}),{data:e,refresh:E}=([u,h]=N(async()=>V(`page-${_.value}`,async()=>{try{const t=await b.query(j,{uri:_.value},{previewToken:c.value});if(!(t!=null&&t.entry))throw k({statusCode:404,message:"Page not found"});return t.entry}catch(t){throw console.error("Error fetching page:",t),k({statusCode:404,message:"Page not found"})}},{watch:[_,c]})),u=await u,h(),u);return S([p,c],()=>{p.value&&c.value&&E()}),H(()=>{var t;return{title:((t=e.value)==null?void 0:t.title)||""}}),(t,i)=>{const x=T,P=$;return a(e)?(s(),r("div",{key:a(C)},[a(e).image&&a(e).image.length>0?(s(),r("figure",F,[n("img",{src:a(e).image[0].url,alt:a(e).image[0].alt},null,8,G)])):l("",!0),n("header",M,[a(e).ancestors.length?(s(),r("ul",Q,[(s(!0),r(y,null,f(a(e).ancestors,o=>(s(),r("li",{key:o.id},[v(x,{to:`/${o.uri}`},{default:m(()=>[g(d(o.title),1)]),_:2},1032,["to"])]))),128))])):l("",!0),n("h1",R,d(a(e).title),1),a(e).pageSubheading?(s(),r("p",U,d(a(e).pageSubheading),1)):l("",!0)]),n("section",Y,[a(e).pageContent?(s(),r("div",{key:0,class:"container mx-auto py-12 px-2 text-balance",innerHTML:a(e).pageContent},null,8,z)):(s(),B(P,{key:1},{default:m(()=>i[0]||(i[0]=[g("This page has no content, but you can add some in the control panel!")])),_:1}))]),a(e).children.length?(s(),r("footer",I,[n("div",J,[i[2]||(i[2]=n("h3",{class:"font-bold text-3xl mb-4"},"Children",-1)),n("ul",null,[(s(!0),r(y,null,f(a(e).children,o=>(s(),r("li",{key:o.id},[i[1]||(i[1]=n("span",{class:"text-slate-400 mr-2","aria-hidden":"true"},"→",-1)),v(x,{to:`/${o.uri}`,class:"text-red-600 hover:underline"},{default:m(()=>[g(d(o.title),1)]),_:2},1032,["to"])]))),128))])])])):l("",!0)])):l("",!0)}}};export{te as default};

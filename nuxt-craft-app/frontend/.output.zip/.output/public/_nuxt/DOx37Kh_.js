import{_ as x}from"./Bln9op0L.js";import{u as y}from"./Dl7SEZbI.js";import{e as f,f as v,c as r,g as m,a,u as e,t as p,h as w,w as k,i as b,j as C,k as E,o as s,d as T}from"./BKiLTqlp.js";const H=`
  query Home {
    entry(section: "home", limit: 1) {
      ... on page_Entry {
        id
        title
        pageSubheading
        pageContent
        image {
          url @transform(handle: "hero")
          alt
        }
      }
    }
  }
`,B={key:0},S=["src","alt"],q={class:"container mx-auto pt-12 pb-6 px-2 text-2xl"},A={class:"font-bold text-4xl sm:text-6xl lg:text-9xl"},D={key:0,class:"mt-4"},L={class:"page__content"},M={class:"container mx-auto py-12 px-2 text-balance"},N=["innerHTML"],F={__name:"index",async setup(P){let o,l;const{isPreview:i,previewToken:n,previewTimestamp:u}=y(),d=C();i.value;const{data:t,refresh:h}=([o,l]=f(async()=>b("home",async()=>{try{return(await d.query(H,{},{previewToken:n.value})).entry}catch(c){throw console.error("Failed to fetch home data:",c),E({statusCode:404,message:"Homepage not found"})}},{watch:[n]})),o=await o,l(),o);return v([i,n],()=>{i.value&&n.value&&h()}),(c,_)=>{const g=x;return s(),r("div",{key:e(u)},[e(t).image&&e(t).image.length>0?(s(),r("figure",B,[a("img",{src:e(t).image[0].url,alt:e(t).image[0].alt},null,8,S)])):m("",!0),a("header",q,[a("h1",A,p(e(t).title),1),e(t).pageSubheading?(s(),r("p",D,p(e(t).pageSubheading),1)):m("",!0)]),a("section",L,[a("div",M,[e(t).pageContent?(s(),r("div",{key:0,innerHTML:e(t).pageContent},null,8,N)):(s(),w(g,{key:1},{default:k(()=>_[0]||(_[0]=[T("Add content to the homepage by visiting Entries → Default Pages in the control panel!")])),_:1}))])])])}}};export{F as default};

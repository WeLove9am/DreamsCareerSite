import{_ as F}from"./BZjzSb2B.js";import{u as L}from"./DrFXLTk6.js";import{l as j,m as c,e as Y,f as $,c as o,g as r,u as p,t as n,F as w,a as l,y as P,d as q,h as D,i as H,j as O,k as T,o as a}from"./BKiLTqlp.js";import{u as V}from"./Dl7SEZbI.js";import"./BS5pnyMs.js";const z=`
  query BlogPosts($slug: [String]) {
    blogPostsEntries(slug: $slug) {
      ... on page_Entry {
        id
        slug
        title
        pageSubheading
        pageContent
        authorName
        authorId
        postDate @formatDateTime(format: "F j, Y")
        image {
          alt
          url @transform(handle: "hero")
        }
        next(section: "blogPosts") {
          id
          slug
          uri
          title
          postDate @formatDateTime(format: "F j, Y")
        }
        prev(section: "blogPosts") {
          id
          slug
          uri
          title
          postDate @formatDateTime(format: "F j, Y")
        }
        category {
          ... on category_Entry {
            id
            title
          }
        }
      }
    }
  }
`,A={key:0,class:"container mx-auto py-12 px-2"},G={key:1,class:"container mx-auto py-12 px-2 text-red-600"},M={key:0,class:"absolute top-0 left-0 w-full h-full"},Q=["src","alt"],R={class:"font-bold text-4xl sm:text-6xl lg:text-9xl"},I={key:0,class:"mt-4"},U={class:"text-xs mt-4"},J={key:0,class:"font-bold"},K=["datetime"],W={key:3,class:"block"},X={class:"page__content"},Z=["innerHTML"],ee={key:3,class:"container mx-auto py-12 px-2"},te={key:4,class:"bg-slate-100"},se={class:"container mx-auto divide-y divide-slate-300 py-12 px-2"},ae={class:"sm:grid sm:grid-cols-2 sm:gap-6"},ce={__name:"[slug]",async setup(oe){let i,v;const g=j(),E=O(),{isPreview:m,previewToken:u,previewTimestamp:B}=V(),d=c(()=>{var s,t;return((s=e.value)==null?void 0:s.image)&&((t=e.value)==null?void 0:t.image.length)>0});m.value;const{data:C,error:_,refresh:N}=([i,v]=Y(async()=>H(`post-${g.params.slug}`,async()=>{var s;try{const t=await E.query(z,{slug:g.params.slug},{previewToken:u.value});if(!((s=t==null?void 0:t.blogPostsEntries)!=null&&s.length))throw T({statusCode:404,message:"Post not found"});return t}catch(t){throw console.error("Error fetching post:",t),T({statusCode:404,message:"Post not found"})}},{watch:[u]})),i=await i,v(),i);$([m,u],()=>{m.value&&u.value&&N()});const e=c(()=>{var s,t;return((t=(s=C.value)==null?void 0:s.blogPostsEntries)==null?void 0:t[0])||null}),h=c(()=>!!e.value),S=c(()=>{var s,t;return h.value&&(((s=e.value)==null?void 0:s.prev)||((t=e.value)==null?void 0:t.next))});return L(()=>{var s;return{title:((s=e.value)==null?void 0:s.title)||""}}),(s,t)=>{var x,f,k,b;const y=F;return a(),o("div",{key:p(B)},[s.pending?(a(),o("div",A," Loading... ")):p(_)?(a(),o("div",G,n(p(_).message),1)):h.value?(a(),o(w,{key:2},[l("header",{class:P(["container mx-auto pt-12 pb-6 px-2 text-2xl relative",d.value?"aspect-video":""])},[d.value?(a(),o("figure",M,[l("img",{src:e.value.image[0].url,alt:e.value.image[0].alt},null,8,Q)])):r("",!0),l("div",{class:P(["z-10",d.value?"text-white bg-black/80 p-4 sm:bottom-0 relative sm:ml-4 sm:max-w-screen-lg sm:absolute sm:rounded":""])},[l("h1",R,n(e.value.title),1),e.value.pageSubheading?(a(),o("p",I,n(e.value.pageSubheading),1)):r("",!0),l("div",U,[l("p",null,[(x=e.value.category)!=null&&x.length?(a(),o("span",J,n(e.value.category[0].title),1)):r("",!0),(f=e.value.category)!=null&&f.length&&e.value.postDate?(a(),o(w,{key:1},[q(" | ")],64)):r("",!0),e.value.postDate?(a(),o("time",{key:2,datetime:e.value.postDate},n(e.value.postDate),9,K)):r("",!0),e.value.authorName?(a(),o("span",W," By "+n(e.value.authorName),1)):r("",!0)])])],2)],2),l("section",X,[l("div",{class:"container mx-auto py-12 px-2 text-balance prose",innerHTML:e.value.pageContent},null,8,Z)])],64)):(a(),o("div",ee," Post not found ")),S.value?(a(),o("section",te,[l("div",se,[t[0]||(t[0]=l("h2",{class:"font-bold text-4xl mb-2"},"Other articles",-1)),l("div",ae,[(k=e.value)!=null&&k.prev?(a(),D(y,{key:e.value.prev.id,entry:e.value.prev},null,8,["entry"])):r("",!0),(b=e.value)!=null&&b.next?(a(),D(y,{key:e.value.next.id,entry:e.value.next},null,8,["entry"])):r("",!0)])])])):r("",!0)])}}};export{ce as default};

import{_ as C}from"./BZjzSb2B.js";import{u as T,_ as D}from"./CjNHRb7m.js";import{f as L,m as h,c as o,u as s,t as d,a as n,g as y,h as x,F as $,r as S,o as a,j as q}from"./BKiLTqlp.js";import{u as F}from"./Dl7SEZbI.js";import{u as H}from"./DrFXLTk6.js";import"./BS5pnyMs.js";const N=`
  query Blog($limit: Int!, $offset: Int!) {
    blogEntries(limit: 1) {
      ... on page_Entry {
        id
        slug
        title
        pageSubheading
        pageContent
      }
    }
    blogPostsEntries(limit: $limit, offset: $offset) {
      ... on page_Entry {
        id
        slug
        title
        uri
        pageSubheading
        pageContent
        postDate @formatDateTime(format: "F j, Y")
        image {
          alt
          url @transform(handle: "wide")
        }
      }
    }
    entryCount(section: "blogPosts")
  }
`,U={key:0},j={key:1},G={key:2},I={class:"container mx-auto pt-12 pb-6 px-2 text-2xl"},M={class:"font-bold text-4xl sm:text-6xl lg:text-9xl"},Q={key:0,class:"mt-4"},V={class:"page__content"},Y=["innerHTML"],O={class:"container mx-auto mb-6 px-2 divide-y divide-slate-300"},R={key:0,class:"sm:grid sm:grid-cols-2 sm:gap-6"},z={key:1},et={__name:"index",setup(A){const P=q(),{isPreview:c,previewToken:u,previewTimestamp:k}=F();c.value;const b=async(e,r)=>{var l;try{const t=await P.query(N,{limit:r,offset:(e-1)*r},{previewToken:u.value});return{content:((l=t==null?void 0:t.blogEntries)==null?void 0:l[0])||{},posts:(t==null?void 0:t.blogPostsEntries)||[],total:(t==null?void 0:t.entryCount)||0}}catch(t){throw t}},{currentPage:g,data:p,totalPages:m,loading:w,error:_,updateCurrentPage:E,fetchPageData:B}=T(b);L([c,u],()=>{c.value&&u.value&&B(g.value)});const f=h(()=>{var e;return((e=p.value)==null?void 0:e.posts)||[]}),i=h(()=>{var e;return((e=p.value)==null?void 0:e.content)||{}});return H(()=>{var e;return{title:((e=i.value)==null?void 0:e.title)||""}}),(e,r)=>{const l=C,t=D;return a(),o("div",{key:s(k)},[s(w)?(a(),o("div",U,"Loading...")):s(_)?(a(),o("div",j,"Error: "+d(s(_).message),1)):(a(),o("div",G,[n("header",I,[n("h1",M,d(i.value.title),1),i.value.pageSubheading?(a(),o("p",Q,d(i.value.pageSubheading),1)):y("",!0)]),n("section",V,[n("div",{class:"container mx-auto py-12 px-2 text-balance",innerHTML:i.value.pageContent},null,8,Y)]),n("section",O,[f.value.length>0?(a(),o("div",R,[(a(!0),o($,null,S(f.value,v=>(a(),x(l,{key:v.id,entry:v,featured:!0},null,8,["entry"]))),128))])):(a(),o("div",z,r[0]||(r[0]=[n("p",null,"No posts yet.",-1)]))),s(m)>1?(a(),x(t,{key:2,currentPage:s(g),totalPages:s(m),"onUpdate:currentPage":s(E)},null,8,["currentPage","totalPages","onUpdate:currentPage"])):y("",!0)])]))])}}};export{et as default};

import{c as r,u as e,o as n,t as f,a as o,h as T,g as x,F as E,r as S,j as b,p as k,m as I,q as C,v as L,s as q,e as M,f as B,b as P,i as D,k as G}from"./BKiLTqlp.js";import{u as N}from"./Dl7SEZbI.js";import{u as U,_ as F}from"./CjNHRb7m.js";import{u as O}from"./D91o7cuI.js";import{u as H}from"./DrFXLTk6.js";const R=`
  query Guestbook {
    guestbookEntries: entries(section: "guestbook", limit: 1) {
      ... on page_Entry {
        id
        title
        pageContent
        pageSubheading
        authorId
      }
    }
  }
`,A=`
  query GuestbookPosts($limit: Int!, $offset: Int!) {
    guestbookPostsEntries(limit: $limit, offset: $offset) {
      ... on text_Entry {
        id
        title
        textBlock @markdown
        postDate @formatDateTime(format: "F j, Y")
      }
    }
    entryCount(section: "guestbookPosts")
  }
`,Q={key:0,class:"py-4"},V={key:1,class:"py-4 text-red-600"},j={key:2},Y={key:0},K={class:"mb-2 divide-y divide-slate-300"},z={class:"text-xl py-6"},J=["innerHTML"],W={class:"text-sm mt-1"},X=["datetime"],Z={key:1,class:"text-2xl"},tt={__name:"postList",props:{previewToken:{type:String,default:null}},setup(y,{expose:u}){const m=y,_=async(a,s)=>{try{const t=await b().query(A,{limit:s,offset:(a-1)*s},{previewToken:m.previewToken});return{posts:(t==null?void 0:t.guestbookPostsEntries)||[],total:(t==null?void 0:t.entryCount)||0}}catch(t){throw console.error("GraphQL Error:",t),t}},{currentPage:i,data:l,totalPages:c,error:d,loading:g,updateCurrentPage:h,refresh:p}=U(_);return u({refresh:p}),(a,s)=>{var $,w;const t=F;return e(g)?(n(),r("div",Q," Loading... ")):e(d)?(n(),r("div",V,f(e(d).message),1)):(n(),r("div",j,[((w=($=e(l))==null?void 0:$.posts)==null?void 0:w.length)>0?(n(),r("div",Y,[o("ol",K,[(n(!0),r(E,null,S(e(l).posts,v=>(n(),r("li",{key:v.id},[o("article",z,[o("div",{innerHTML:v.textBlock},null,8,J),o("p",W,[o("time",{datetime:v.postDate},f(v.postDate),9,X)])])]))),128))]),e(c)>1?(n(),T(t,{key:0,currentPage:e(i),totalPages:e(c),"onUpdate:currentPage":e(h)},null,8,["currentPage","totalPages","onUpdate:currentPage"])):x("",!0)])):(n(),r("p",Z,"No entries yet. Create one using the form."))]))}}},et=`
  mutation createGuestbookPost($title: String!, $message: String, $authorId: ID!) {
    save_guestbookPosts_text_Entry(
      title: $title,
      textBlock: $message,
      authorId: $authorId
    ) {
      title
      textBlock
    }
  }
`,st={class:"mb-6 mt-4"},ot=["disabled"],at={__name:"postForm",props:{authorId:{type:Number,required:!0}},emits:["post-submitted"],setup(y,{emit:u}){const m=b(),{addFlash:_}=O(),i=k(""),l=k(!1),c=u,d=a=>{const s=a.split(" ").slice(0,3).join(" ").trim();return`Post: ${s}${s?"...":""}`},g=y,h=I(()=>d(i.value)),p=async()=>{if(!i.value.trim()){console.error("Message is required");return}l.value=!0;try{console.log("Submitting with:",{title:h.value,message:i.value,authorId:g.authorId});const a=await m.query(et,{title:h.value,message:i.value,authorId:g.authorId.toString()},{private:!0});if(console.log("Mutation result:",a),!(a!=null&&a.save_guestbookPosts_text_Entry))throw new Error("No data returned from the mutation");_("Message posted successfully","success"),i.value="",c("post-submitted")}catch(a){_(`Error posting message: ${a.message}`,"error"),console.error("Error creating post:",a)}finally{l.value=!1}};return(a,s)=>(n(),r("form",{method:"post",onSubmit:q(p,["prevent"])},[o("div",st,[s[1]||(s[1]=o("label",{for:"message",class:"font-bold"},"Message",-1)),C(o("textarea",{name:"message",class:"w-full px-6 py-4",required:"",id:"message","onUpdate:modelValue":s[0]||(s[0]=t=>i.value=t)},null,512),[[L,i.value]])]),o("input",{type:"submit",class:"rounded font-bold bg-red-600 text-slate-50 px-6 py-4",value:"Post entry",disabled:l.value},null,8,ot)],32))}},nt={key:0,class:"container mx-auto py-12 px-2"},rt={key:1,class:"container mx-auto py-12 px-2 text-red-600"},it={class:"container mx-auto pt-12 pb-6 px-2"},lt={class:"font-bold text-4xl sm:text-6xl lg:text-9xl"},ct={key:0,class:"mt-4 text-2xl"},ut={key:0,class:"page__content"},dt=["innerHTML"],pt={class:"container mx-auto px-2 sm:grid gap-6 grid-cols-2"},mt={class:"mb-12"},_t={class:"bg-slate-200 p-6 mb-9 rounded"},xt={__name:"guestbook",async setup(y){let u,m;const _=b(),{isPreview:i,previewToken:l}=N();i.value;const{data:c,error:d,pending:g,refresh:h}=([u,m]=M(async()=>D("guestbook",async()=>{var s;try{const t=await _.query(R,{},{previewToken:l.value});return((s=t==null?void 0:t.guestbookEntries)==null?void 0:s[0])||{}}catch(t){throw G({statusCode:404,message:`Failed to fetch guestbook data: ${t.message}`})}},{watch:[l]})),u=await u,m(),u),p=k(null),a=async()=>{p.value&&await p.value.refresh()};return B([i,l],()=>{i.value&&l.value&&h()}),H(()=>{var s;return{title:((s=c.value)==null?void 0:s.title)||"Guestbook"}}),(s,t)=>(n(),r("div",null,[e(g)?(n(),r("div",nt," Loading... ")):e(d)?(n(),r("div",rt,f(e(d).message),1)):(n(),r(E,{key:2},[o("header",it,[o("h1",lt,f(e(c).title),1),e(c).pageSubheading?(n(),r("p",ct,f(e(c).pageSubheading),1)):x("",!0)]),e(c).pageContent?(n(),r("section",ut,[o("div",{class:"container mx-auto py-12 px-2 text-balance",innerHTML:e(c).pageContent},null,8,dt)])):x("",!0),o("div",pt,[o("section",mt,[P(tt,{ref_key:"postListRef",ref:p,"preview-token":e(l)},null,8,["preview-token"])]),o("section",null,[o("div",_t,[t[0]||(t[0]=o("h2",{class:"font-bold text-3xl mb-4"},"Post an entry",-1)),P(at,{onPostSubmitted:a,"author-id":e(c).authorId},null,8,["author-id"])])])])],64))]))}};export{xt as default};
